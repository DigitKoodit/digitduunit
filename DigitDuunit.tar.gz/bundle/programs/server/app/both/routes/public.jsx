(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// both/routes/public.jsx                                              //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
FlowRouter.route('/', {                                                // 1
  name: "home",                                                        // 2
  action: function () {                                                // 3
    ReactLayout.render(AppRoot, { 'yield': React.createElement(MainComponent, null) });
  }                                                                    //
});                                                                    //
                                                                       //
FlowRouter.route('/new', {                                             // 8
  name: "new_job",                                                     // 9
  action: function () {                                                // 10
    console.log(Meteor.user());                                        // 11
    if (!Meteor.user()) {                                              // 12
      ReactLayout.render(AppRoot, { 'yield': React.createElement(MainComponent, null) });
    } else {                                                           //
      Meteor.user().roles.indexOf('admin') != -1 ? ReactLayout.render(AppRoot, { 'yield': React.createElement(JobEditor, null) }) : ReactLayout.render(AppRoot, { 'yield': React.createElement(ErrorView, { error: 'Kirjaudu sisään lisätäksesi ilmoituksia.' }) });
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
FlowRouter.route('/jobs/:jobId', {                                     // 20
  action: function (params, queryParams) {                             // 21
    console.log("Params:", params);                                    // 22
    console.log("Query Params:", queryParams);                         // 23
    Meteor.user() ? ReactLayout.render(AppRoot, { 'yield': React.createElement(JobPost, { id: params }) }) : ReactLayout.render(AppRoot, { 'yield': React.createElement(ErrorView, { error: 'Kirjaudu sisään nähdäksesi työpaikkailmoituksen' }) });
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=public.jsx.map
