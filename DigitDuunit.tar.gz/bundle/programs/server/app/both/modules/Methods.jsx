(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// both/modules/Methods.jsx                                            //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
if (Meteor.isClient) {                                                 // 1
  Meteor.subscribe("jobs");                                            // 2
  Meteor.subscribe("projects");                                        // 3
}                                                                      //
                                                                       //
Meteor.methods({                                                       // 6
                                                                       //
  //Method to be called to add items to projects list                  //
  addProject: function (item) {                                        // 9
    if (!Meteor.userId()) {                                            // 10
      throw new Meteor.error("User not logged in.");                   // 11
    }                                                                  //
    console.log("Inserting project: " + item);                         // 13
                                                                       //
    Projects.insert({                                                  // 15
      name: item.name,                                                 // 16
      createdAt: new Date(),                                           // 17
      owner: Meteor.userId(),                                          // 18
      projectLead: item.projectLead,                                   // 19
      description: item.description                                    // 20
    });                                                                //
  },                                                                   //
                                                                       //
  //Method to be called to add items to jobs list.                     //
  addJob: function (item) {                                            // 25
    if (!Meteor.userId()) {                                            // 26
      throw new Meteor.error("User not logged in.");                   // 27
    }                                                                  //
    console.log("Inserting: " + item);                                 // 29
                                                                       //
    Jobs.insert({                                                      // 31
      name: item.name,                                                 // 32
      createdAt: new Date(),                                           // 33
      owner: Meteor.userId(),                                          // 34
      location: item.location,                                         // 35
      type: item.type,                                                 // 36
      deadline: item.deadline,                                         // 37
      description: item.description                                    // 38
    });                                                                //
  }                                                                    //
                                                                       //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=Methods.jsx.map
