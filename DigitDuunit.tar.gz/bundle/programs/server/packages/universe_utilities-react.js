(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var React = Package['react-runtime'].React;
var ReactDOM = Package['react-runtime'].ReactDOM;
var ReactDOMServer = Package['react-runtime'].ReactDOMServer;
var ECMAScript = Package.ecmascript.ECMAScript;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var UniverseReactModulesLoader;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/universe_utilities-react/modules/ReactWithAddons.js                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
System.registerDynamic('react', [], false, function (require, exports, module) {                                       // 1
    module.exports = Package['react-runtime'].React;                                                                   // 2
});                                                                                                                    //
                                                                                                                       //
System.registerDynamic('react-dom', [], false, function (require, exports, module) {                                   // 5
    module.exports = Package['react-runtime'].ReactDOM;                                                                // 6
});                                                                                                                    //
                                                                                                                       //
System.config({                                                                                                        // 9
    meta: {                                                                                                            // 10
        'react/*': {                                                                                                   // 11
            format: 'register',                                                                                        // 12
            loader: 'UniverseReactModulesLoader'                                                                       // 13
        },                                                                                                             //
        'react-dom/*': {                                                                                               // 15
            format: 'register',                                                                                        // 16
            loader: 'UniverseReactModulesLoader'                                                                       // 17
        }                                                                                                              //
    }                                                                                                                  //
});                                                                                                                    //
                                                                                                                       //
// Our custom loader for react                                                                                         //
/* globals UniverseReactModulesLoader:true */                                                                          //
UniverseReactModulesLoader = System.newModule({                                                                        // 24
    locate: function (_ref) {                                                                                          // 25
        var name = _ref.name;                                                                                          //
                                                                                                                       //
        return new Promise(function (resolve, reject) {                                                                // 26
            var _name$split = name.split('/');                                                                         //
                                                                                                                       //
            var dir = _name$split[0];                                                                                  //
                                                                                                                       //
            // check if we're in valid namespace                                                                       //
            if (dir !== 'react') {                                                                                     // 29
                reject(new Error('[Universe Modules]: trying to get exported values from invalid package: ' + name));  // 30
                return;                                                                                                // 31
            }                                                                                                          //
            resolve(name);                                                                                             // 33
        });                                                                                                            //
    },                                                                                                                 //
    fetch: function () {                                                                                               // 36
        // we don't need to fetch anything for this to work                                                            //
        return '';                                                                                                     // 38
    },                                                                                                                 //
    instantiate: function (_ref2) {                                                                                    // 40
        var name = _ref2.name;                                                                                         //
                                                                                                                       //
        return React.require(name);                                                                                    // 41
    }                                                                                                                  //
});                                                                                                                    //
                                                                                                                       //
// Register our loader                                                                                                 //
System.set('UniverseReactModulesLoader', UniverseReactModulesLoader);                                                  // 46
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/universe_utilities-react/mixins/autorun.import.jsx                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
System.register('/_modules_/packages/universe/utilities-react/mixins/autorun', [], function (_export) {                //
    var AutorunMixin;                                                                                                  //
    return {                                                                                                           //
        setters: [],                                                                                                   //
        execute: function () {                                                                                         //
            AutorunMixin = {                                                                                           // 1
                componentWillMount: function () {                                                                      // 2
                    var _this = this;                                                                                  //
                                                                                                                       //
                    var _loop = function (method) {                                                                    //
                        if (_this.hasOwnProperty(method) && method.indexOf('autorun', 0) === 0) {                      // 4
                            var methodComputation = method + 'Computation';                                            // 5
                                                                                                                       //
                            if (_this[methodComputation] === undefined) {                                              // 7
                                _this[methodComputation] = Tracker.nonreactive(function () {                           // 8
                                    // we put this inside nonreactive to be sure that it won't be related to any other computation
                                    return Tracker.autorun(_this[method]);                                             // 10
                                });                                                                                    //
                            }                                                                                          //
                        }                                                                                              //
                    };                                                                                                 //
                                                                                                                       //
                    for (var method in this) {                                                                         // 3
                        _loop(method);                                                                                 //
                    }                                                                                                  //
                },                                                                                                     //
                                                                                                                       //
                componentWillUnmount: function () {                                                                    // 17
                    for (var method in this) {                                                                         // 18
                        if (this.hasOwnProperty(method) && method.indexOf('autorun', 0) === 0) {                       // 19
                            var methodComputation = method + 'Computation';                                            // 20
                                                                                                                       //
                            if (this[methodComputation]) {                                                             // 22
                                this[methodComputation].stop();                                                        // 23
                                this[methodComputation] = null;                                                        // 24
                            }                                                                                          //
                        }                                                                                              //
                    }                                                                                                  //
                }                                                                                                      //
            };                                                                                                         //
                                                                                                                       //
            _export('default', AutorunMixin);                                                                          //
        }                                                                                                              //
    };                                                                                                                 //
});                                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/universe_utilities-react/mixins/dualLink.import.jsx                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
System.register('/_modules_/packages/universe/utilities-react/mixins/dualLink', [], function (_export) {               //
    var DualLinkMixin, DualLink;                                                                                       //
    return {                                                                                                           //
        setters: [],                                                                                                   //
        execute: function () {                                                                                         //
            DualLinkMixin = {                                                                                          // 1
                componentWillMount: function () {                                                                      // 2
                    this._dualLinks = {};                                                                              // 3
                },                                                                                                     //
                                                                                                                       //
                dualLink: function () {                                                                                // 6
                    var linkName = arguments.length <= 0 || arguments[0] === undefined ? 'default' : arguments[0];     //
                                                                                                                       //
                    if (this._dualLinks[linkName]) {                                                                   // 7
                        // get DualLink from cache                                                                     //
                        return this._dualLinks[linkName];                                                              // 9
                    }                                                                                                  //
                                                                                                                       //
                    // create new DualLink                                                                             //
                    return this._dualLinks[linkName] = new DualLink(this, linkName);                                   // 13
                }                                                                                                      //
            };                                                                                                         //
                                                                                                                       //
            DualLink = (function () {                                                                                  // 17
                function DualLink(component, name) {                                                                   // 18
                    babelHelpers.classCallCheck(this, DualLink);                                                       //
                                                                                                                       //
                    check(name, String);                                                                               // 19
                                                                                                                       //
                    this.name = name;                                                                                  // 21
                    this.component = component;                                                                        // 22
                                                                                                                       //
                    this._setState('local', {});                                                                       // 24
                    this._setState('remote', {});                                                                      // 25
                }                                                                                                      //
                                                                                                                       //
                DualLink.prototype._getStateName = function _getStateName(type) {                                      // 17
                    return '_dualLink_' + this.name + '_' + type;                                                      // 29
                };                                                                                                     //
                                                                                                                       //
                DualLink.prototype._getState = function _getState(type) {                                              // 17
                    return this.component.state[this._getStateName(type)];                                             // 33
                };                                                                                                     //
                                                                                                                       //
                DualLink.prototype._setState = function _setState(type, field, value) {                                // 17
                    if (typeof field === 'string' && value !== undefined) {                                            // 37
                        var _component$setState;                                                                       //
                                                                                                                       //
                        // set/update only one field                                                                   //
                        this.component.setState((_component$setState = {}, _component$setState[this._getStateName(type)] = UniUtils.set(this._getState(type), field, value), _component$setState));
                    } else if (typeof field === 'object' && value === undefined) {                                     //
                        var _component$setState2;                                                                      //
                                                                                                                       //
                        // set whole object, in this case our value is in field argument                               //
                        this.component.setState((_component$setState2 = {}, _component$setState2[this._getStateName(type)] = field, _component$setState2));
                    } else if (field === undefined && value === undefined) {                                           //
                                                                                                                       //
                        // subscription helper                                                                         //
                                                                                                                       //
                    } else {                                                                                           //
                            console.warn('[DualLinkMixin] Invalid set params', { type: type, field: field, value: value });
                        }                                                                                              //
                };                                                                                                     //
                                                                                                                       //
                DualLink.prototype.getLocal = function getLocal(field) {                                               // 17
                    return field ? UniUtils.get(this._getState('local'), field) : this._getState('local');             // 61
                };                                                                                                     //
                                                                                                                       //
                DualLink.prototype.getRemote = function getRemote(field) {                                             // 17
                    return field ? UniUtils.get(this._getState('remote'), field) : this._getState('remote');           // 65
                };                                                                                                     //
                                                                                                                       //
                DualLink.prototype.get = function get(field) {                                                         // 17
                    if (field) {                                                                                       // 69
                        // return only one field                                                                       //
                                                                                                                       //
                        var local = this.getLocal(field);                                                              // 72
                        if (local !== undefined) {                                                                     // 73
                            // local can be also e.g. empty string                                                     //
                            return local;                                                                              // 75
                        }                                                                                              //
                                                                                                                       //
                        return this.getRemote(field);                                                                  // 78
                    }                                                                                                  //
                                                                                                                       //
                    // return whole object                                                                             //
                    return $.extend(true, {}, this.getRemote(), this.getLocal());                                      // 82
                };                                                                                                     //
                                                                                                                       //
                DualLink.prototype.isEmpty = function isEmpty() {                                                      // 17
                    return _.isEmpty(this.get());                                                                      // 86
                };                                                                                                     //
                                                                                                                       //
                DualLink.prototype.setLocal = function setLocal(field, value) {                                        // 17
                    this._setState('local', field, value);                                                             // 90
                };                                                                                                     //
                                                                                                                       //
                DualLink.prototype.setRemote = function setRemote(field, value) {                                      // 17
                    this._setState('remote', field, value);                                                            // 94
                };                                                                                                     //
                                                                                                                       //
                DualLink.prototype.clear = function clear() {                                                          // 17
                    this.setLocal({});                                                                                 // 98
                };                                                                                                     //
                                                                                                                       //
                DualLink.prototype.valueLink = function valueLink(field) {                                             // 17
                    var _this = this;                                                                                  //
                                                                                                                       //
                    return {                                                                                           // 102
                        value: this.get(field),                                                                        // 103
                        requestChange: function (value) {                                                              // 104
                            return _this.setLocal(field, value);                                                       //
                        }                                                                                              //
                    };                                                                                                 //
                };                                                                                                     //
                                                                                                                       //
                return DualLink;                                                                                       //
            })();                                                                                                      //
                                                                                                                       //
            _export('default', DualLinkMixin);                                                                         //
        }                                                                                                              //
    };                                                                                                                 //
});                                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/universe_utilities-react/mixins/subscription.import.jsx                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
System.register("/_modules_/packages/universe/utilities-react/mixins/subscription", [], function (_export) {           //
    var SubscriptionMixin;                                                                                             //
    return {                                                                                                           //
        setters: [],                                                                                                   //
        execute: function () {                                                                                         //
            SubscriptionMixin = {                                                                                      // 1
                componentWillMount: function () {                                                                      // 2
                    this.subscriptions = {};                                                                           // 3
                },                                                                                                     //
                                                                                                                       //
                componentWillUnmount: function () {                                                                    // 6
                    _.each(this.subscriptions, function (handlers) {                                                   // 7
                        return handlers.forEach(function (handle) {                                                    //
                            return handle.stop();                                                                      //
                        });                                                                                            //
                    });                                                                                                //
                },                                                                                                     //
                                                                                                                       //
                subscribe: function (subscription) {                                                                   // 10
                    var _Meteor,                                                                                       //
                        _this = this;                                                                                  //
                                                                                                                       //
                    this.subscriptions[subscription] = this.subscriptions[subscription] || [];                         // 11
                                                                                                                       //
                    for (var _len = arguments.length, params = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
                        params[_key - 1] = arguments[_key];                                                            // 10
                    }                                                                                                  //
                                                                                                                       //
                    this.subscriptions[subscription].push((_Meteor = Meteor).subscribe.apply(_Meteor, [subscription].concat(params, [function () {
                        var _setState;                                                                                 //
                                                                                                                       //
                        _this.setState((_setState = {}, _setState["__SubscriptionMixin_" + subscription + _this.subscriptions[subscription].length] = true, _setState));
                    }])));                                                                                             //
                },                                                                                                     //
                                                                                                                       //
                subscriptionReady: function (subscription) {                                                           // 19
                    return this.subscriptions[subscription] && this.subscriptions[subscription].every(function (handle) {
                        return handle.ready();                                                                         //
                    });                                                                                                //
                },                                                                                                     //
                                                                                                                       //
                subscriptionsReady: function () {                                                                      // 23
                    return _.all(this.subscriptions, function (handlers) {                                             // 24
                        return handlers.every(function (handle) {                                                      //
                            return handle.ready();                                                                     //
                        });                                                                                            //
                    });                                                                                                //
                }                                                                                                      //
            };                                                                                                         //
                                                                                                                       //
            _export("default", SubscriptionMixin);                                                                     //
        }                                                                                                              //
    };                                                                                                                 //
});                                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/universe_utilities-react/helpers/classnames.import.jsx                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
System.register('/_modules_/packages/universe/utilities-react/helpers/classnames', [], function (_export) {            //
    _export('default', classNames);                                                                                    //
                                                                                                                       //
    function classNames() {                                                                                            // 1
                                                                                                                       //
        var classes = '';                                                                                              // 3
                                                                                                                       //
        for (var i = 0; i < arguments.length; i++) {                                                                   // 5
            var arg = arguments[i];                                                                                    // 6
            if (!arg) continue;                                                                                        // 7
                                                                                                                       //
            var argType = typeof arg;                                                                                  // 9
                                                                                                                       //
            if ('string' === argType || 'number' === argType) {                                                        // 11
                classes += ' ' + arg;                                                                                  // 12
            } else if (Array.isArray(arg)) {                                                                           //
                classes += ' ' + classNames.apply(null, arg);                                                          // 15
            } else if ('object' === argType) {                                                                         //
                for (var key in arg) {                                                                                 // 18
                    if (arg.hasOwnProperty(key) && arg[key]) {                                                         // 19
                        classes += ' ' + key;                                                                          // 20
                    }                                                                                                  //
                }                                                                                                      //
            }                                                                                                          //
        }                                                                                                              //
                                                                                                                       //
        return classes.substr(1);                                                                                      // 26
    }                                                                                                                  //
                                                                                                                       //
    return {                                                                                                           //
        setters: [],                                                                                                   //
        execute: function () {                                                                                         //
            ;                                                                                                          // 27
        }                                                                                                              //
    };                                                                                                                 //
});                                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/universe_utilities-react/helpers/execution-environment.import.jsx                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
System.register('/_modules_/packages/universe/utilities-react/helpers/execution-environment', [], function (_export) {
    var canUseDOM;                                                                                                     //
    return {                                                                                                           //
        setters: [],                                                                                                   //
        execute: function () {                                                                                         //
            canUseDOM = !!(typeof window !== 'undefined' && window.document && window.document.createElement);         // 1
                                                                                                                       //
            _export('default', {                                                                                       //
                                                                                                                       //
                canUseDOM: canUseDOM,                                                                                  // 9
                                                                                                                       //
                canUseWorkers: typeof Worker !== 'undefined',                                                          // 11
                                                                                                                       //
                canUseEventListeners: canUseDOM && !!(window.addEventListener || window.attachEvent),                  // 13
                                                                                                                       //
                canUseViewport: canUseDOM && !!window.screen                                                           // 16
                                                                                                                       //
            });                                                                                                        //
        }                                                                                                              //
    };                                                                                                                 //
});                                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/universe_utilities-react/helpers/object-assign.import.jsx                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
System.register('/_modules_/packages/universe/utilities-react/helpers/object-assign', [], function (_export) {         //
    var hasOwnProperty, propIsEnumerable;                                                                              //
                                                                                                                       //
    function toObject(val) {                                                                                           // 4
        if (val === null || val === undefined) {                                                                       // 5
            throw new TypeError('Object.assign cannot be called with null or undefined');                              // 6
        }                                                                                                              //
                                                                                                                       //
        return Object(val);                                                                                            // 9
    }                                                                                                                  //
                                                                                                                       //
    return {                                                                                                           //
        setters: [],                                                                                                   //
        execute: function () {                                                                                         //
            hasOwnProperty = Object.prototype.hasOwnProperty;                                                          // 1
            propIsEnumerable = Object.prototype.propertyIsEnumerable;                                                  // 2
                                                                                                                       //
            _export('default', Object.assign || function (target, source) {                                            //
                var from;                                                                                              // 13
                var to = toObject(target);                                                                             // 14
                var symbols;                                                                                           // 15
                                                                                                                       //
                for (var s = 1; s < arguments.length; s++) {                                                           // 17
                    from = Object(arguments[s]);                                                                       // 18
                                                                                                                       //
                    for (var key in from) {                                                                            // 20
                        if (hasOwnProperty.call(from, key)) {                                                          // 21
                            to[key] = from[key];                                                                       // 22
                        }                                                                                              //
                    }                                                                                                  //
                                                                                                                       //
                    if (Object.getOwnPropertySymbols) {                                                                // 26
                        symbols = Object.getOwnPropertySymbols(from);                                                  // 27
                        for (var i = 0; i < symbols.length; i++) {                                                     // 28
                            if (propIsEnumerable.call(from, symbols[i])) {                                             // 29
                                to[symbols[i]] = from[symbols[i]];                                                     // 30
                            }                                                                                          //
                        }                                                                                              //
                    }                                                                                                  //
                }                                                                                                      //
                                                                                                                       //
                return to;                                                                                             // 36
            });                                                                                                        //
        }                                                                                                              //
    };                                                                                                                 //
});                                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/universe_utilities-react/helpers/react-clonewithprops.import.jsx                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
System.register('/_modules_/packages/universe/utilities-react/helpers/react-clonewithprops', [], function (_export) {  //
    var hasOwn, version, RESERVED;                                                                                     //
                                                                                                                       //
    _export('default', cloneWithProps);                                                                                //
                                                                                                                       //
    function cloneWithProps(child, props) {                                                                            // 14
        var newProps = mergeProps(props, child.props);                                                                 // 15
                                                                                                                       //
        if (!hasOwn.call(newProps, 'children') && hasOwn.call(child.props, 'children')) newProps.children = child.props.children;
                                                                                                                       //
        // < 0.11                                                                                                      //
        if (version[0] === 0 && version[1] < 11) return child.constructor.ConvenienceConstructor(newProps);            // 21
                                                                                                                       //
        // 0.11                                                                                                        //
        if (version[0] === 0 && version[1] === 11) return child.constructor(newProps);                                 // 25
                                                                                                                       //
        // 0.12                                                                                                        //
        else if (version[0] === 0 && version[1] === 12) {                                                              //
                MockLegacyFactory.isReactLegacyFactory = true;                                                         // 30
                MockLegacyFactory.type = child.type;                                                                   // 31
                return React.createElement(MockLegacyFactory, newProps);                                               // 32
            }                                                                                                          //
                                                                                                                       //
        // 0.13+                                                                                                       //
        return React.createElement(child.type, newProps);                                                              // 36
                                                                                                                       //
        function MockLegacyFactory() {}                                                                                // 38
    }                                                                                                                  //
                                                                                                                       //
    function mergeProps(currentProps, childProps) {                                                                    // 42
        var newProps = extend(currentProps),                                                                           // 43
            key;                                                                                                       //
                                                                                                                       //
        for (key in childProps) {                                                                                      // 45
            if (hasOwn.call(RESERVED, key)) RESERVED[key](newProps, childProps[key], key);else if (!hasOwn.call(newProps, key)) newProps[key] = childProps[key];
        }                                                                                                              //
        return newProps;                                                                                               // 52
    }                                                                                                                  //
                                                                                                                       //
    function resolve(fn) {                                                                                             // 55
        return function (src, value, key) {                                                                            // 56
            if (!hasOwn.call(src, key)) src[key] = value;else src[key] = fn(src[key], value);                          // 57
        };                                                                                                             //
    }                                                                                                                  //
                                                                                                                       //
    function joinClasses(a, b) {                                                                                       // 62
        if (!a) return b || '';                                                                                        // 63
        return a + (b ? ' ' + b : '');                                                                                 // 64
    }                                                                                                                  //
                                                                                                                       //
    function extend() {                                                                                                // 67
        var target = {};                                                                                               // 68
        for (var i = 0; i < arguments.length; i++) for (var key in arguments[i]) if (hasOwn.call(arguments[i], key)) target[key] = arguments[i][key];
        return target;                                                                                                 // 72
    }                                                                                                                  //
    return {                                                                                                           //
        setters: [],                                                                                                   //
        execute: function () {                                                                                         //
            hasOwn = Object.prototype.hasOwnProperty;                                                                  // 1
            version = React.version.split('.').map(parseFloat);                                                        // 2
            RESERVED = {                                                                                               // 3
                className: resolve(joinClasses),                                                                       // 4
                children: function () {},                                                                              // 5
                key: function () {},                                                                                   // 7
                ref: function () {},                                                                                   // 9
                style: resolve(extend)                                                                                 // 11
            };                                                                                                         //
        }                                                                                                              //
    };                                                                                                                 //
});                                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/universe_utilities-react/helpers/deep-equal.import.jsx                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
System.register('/_modules_/packages/universe/utilities-react/helpers/deep-equal', [], function (_export) {            //
    var pSlice, objectKeys, deepEqual;                                                                                 //
                                                                                                                       //
    function isArguments(object) {                                                                                     // 4
        return Object.prototype.toString.call(object) == '[object Arguments]';                                         // 5
    }                                                                                                                  //
                                                                                                                       //
    function isUndefinedOrNull(value) {                                                                                // 33
        return value === null || value === undefined;                                                                  // 34
    }                                                                                                                  //
                                                                                                                       //
    function isBuffer(x) {                                                                                             // 37
        if (!x || typeof x !== 'object' || typeof x.length !== 'number') return false;                                 // 38
        if (typeof x.copy !== 'function' || typeof x.slice !== 'function') {                                           // 39
            return false;                                                                                              // 40
        }                                                                                                              //
        if (x.length > 0 && typeof x[0] !== 'number') return false;                                                    // 42
        return true;                                                                                                   // 43
    }                                                                                                                  //
                                                                                                                       //
    function objEquiv(a, b, opts) {                                                                                    // 46
        var i, key;                                                                                                    // 47
        if (isUndefinedOrNull(a) || isUndefinedOrNull(b)) return false;                                                // 48
        // an identical 'prototype' property.                                                                          //
        if (a.prototype !== b.prototype) return false;                                                                 // 51
        //~~~I've managed to break Object.keys through screwy arguments passing.                                       //
        //   Converting to array solves the problem.                                                                   //
        if (isArguments(a)) {                                                                                          // 54
            if (!isArguments(b)) {                                                                                     // 55
                return false;                                                                                          // 56
            }                                                                                                          //
            a = pSlice.call(a);                                                                                        // 58
            b = pSlice.call(b);                                                                                        // 59
            return deepEqual(a, b, opts);                                                                              // 60
        }                                                                                                              //
        if (isBuffer(a)) {                                                                                             // 62
            if (!isBuffer(b)) {                                                                                        // 63
                return false;                                                                                          // 64
            }                                                                                                          //
            if (a.length !== b.length) return false;                                                                   // 66
            for (i = 0; i < a.length; i++) {                                                                           // 67
                if (a[i] !== b[i]) return false;                                                                       // 68
            }                                                                                                          //
            return true;                                                                                               // 70
        }                                                                                                              //
        try {                                                                                                          // 72
            var ka = objectKeys(a),                                                                                    // 73
                kb = objectKeys(b);                                                                                    //
        } catch (e) {                                                                                                  //
            //happens when one is a string literal and the other isn't                                                 //
            return false;                                                                                              // 76
        }                                                                                                              //
        // having the same number of owned properties (keys incorporates                                               //
        // hasOwnProperty)                                                                                             //
        if (ka.length != kb.length) return false;                                                                      // 80
        //the same set of keys (although not necessarily the same order),                                              //
        ka.sort();                                                                                                     // 83
        kb.sort();                                                                                                     // 84
        //~~~cheap key test                                                                                            //
        for (i = ka.length - 1; i >= 0; i--) {                                                                         // 86
            if (ka[i] != kb[i]) return false;                                                                          // 87
        }                                                                                                              //
        //equivalent values for every corresponding key, and                                                           //
        //~~~possibly expensive deep test                                                                              //
        for (i = ka.length - 1; i >= 0; i--) {                                                                         // 92
            key = ka[i];                                                                                               // 93
            if (!deepEqual(a[key], b[key], opts)) return false;                                                        // 94
        }                                                                                                              //
        return typeof a === typeof b;                                                                                  // 96
    }                                                                                                                  //
                                                                                                                       //
    return {                                                                                                           //
        setters: [],                                                                                                   //
        execute: function () {                                                                                         //
            pSlice = Array.prototype.slice;                                                                            // 1
            objectKeys = Object.keys;                                                                                  // 2
                                                                                                                       //
            deepEqual = function (actual, expected, opts) {                                                            // 8
                if (!opts) opts = {};                                                                                  // 9
                // 7.1. All identical values are equivalent, as determined by ===.                                     //
                if (actual === expected) {                                                                             // 11
                    return true;                                                                                       // 12
                } else if (actual instanceof Date && expected instanceof Date) {                                       //
                    return actual.getTime() === expected.getTime();                                                    // 15
                                                                                                                       //
                    // 7.3. Other pairs that do not both pass typeof value == 'object',                                //
                    // equivalence is determined by ==.                                                                //
                } else if (typeof actual != 'object' && typeof expected != 'object') {                                 //
                        return opts.strict ? actual === expected : actual == expected;                                 // 20
                                                                                                                       //
                        // 7.4. For all other Object pairs, including Array objects, equivalence is                    //
                        // determined by having the same number of owned properties (as verified                       //
                        // with Object.prototype.hasOwnProperty.call), the same set of keys                            //
                        // (although not necessarily the same order), equivalent values for every                      //
                        // corresponding key, and an identical 'prototype' property. Note: this                        //
                        // accounts for both named and indexed properties on Arrays.                                   //
                    } else {                                                                                           //
                            return objEquiv(actual, expected, opts);                                                   // 29
                        }                                                                                              //
            };                                                                                                         //
                                                                                                                       //
            _export('default', deepEqual);                                                                             //
        }                                                                                                              //
    };                                                                                                                 //
});                                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/universe_utilities-react/helpers/deep-extend.import.jsx                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
System.register('/_modules_/packages/universe/utilities-react/helpers/deep-extend', [], function (_export) {           //
	var isBuffer;                                                                                                         //
                                                                                                                       //
	_export('default', deepExtend);                                                                                       //
                                                                                                                       //
	function isSpecificValue(val) {                                                                                       // 30
		return !!(isBuffer && val instanceof Buffer || val instanceof Date || val instanceof RegExp);                        // 31
	}                                                                                                                     //
                                                                                                                       //
	function cloneSpecificValue(val) {                                                                                    // 38
		if (isBuffer && val instanceof Buffer) {                                                                             // 39
			var x = new Buffer(val.length);                                                                                     // 40
			val.copy(x);                                                                                                        // 41
			return x;                                                                                                           // 42
		} else if (val instanceof Date) {                                                                                    //
			return new Date(val.getTime());                                                                                     // 44
		} else if (val instanceof RegExp) {                                                                                  //
			return new RegExp(val);                                                                                             // 46
		} else {                                                                                                             //
			throw new Error('Unexpected situation');                                                                            // 48
		}                                                                                                                    //
	}                                                                                                                     //
                                                                                                                       //
	/**                                                                                                                   //
  * Recursive cloning array.                                                                                           //
  */                                                                                                                   //
	function deepCloneArray(arr) {                                                                                        // 55
		var clone = [];                                                                                                      // 56
		arr.forEach(function (item, index) {                                                                                 // 57
			if (typeof item === 'object' && item !== null) {                                                                    // 58
				if (Array.isArray(item)) {                                                                                         // 59
					clone[index] = deepCloneArray(item);                                                                              // 60
				} else if (isSpecificValue(item)) {                                                                                //
					clone[index] = cloneSpecificValue(item);                                                                          // 62
				} else {                                                                                                           //
					clone[index] = deepExtend({}, item);                                                                              // 64
				}                                                                                                                  //
			} else {                                                                                                            //
				clone[index] = item;                                                                                               // 67
			}                                                                                                                   //
		});                                                                                                                  //
		return clone;                                                                                                        // 70
	}                                                                                                                     //
                                                                                                                       //
	/**                                                                                                                   //
  * Extening object that entered in first argument.                                                                    //
  *                                                                                                                    //
  * Returns extended object or false if have no target object or incorrect type.                                       //
  *                                                                                                                    //
  * If you wish to clone source object (without modify it), just use empty new                                         //
  * object as first argument, like this:                                                                               //
  *   deepExtend({}, yourObj_1, [yourObj_N]);                                                                          //
  */                                                                                                                   //
                                                                                                                       //
	function deepExtend() /*obj_1, [obj_2], [obj_N]*/{                                                                    // 82
		if (arguments.length < 1 || typeof arguments[0] !== 'object') {                                                      // 83
			return false;                                                                                                       // 84
		}                                                                                                                    //
                                                                                                                       //
		if (arguments.length < 2) {                                                                                          // 87
			return arguments[0];                                                                                                // 88
		}                                                                                                                    //
                                                                                                                       //
		var target = arguments[0];                                                                                           // 91
                                                                                                                       //
		// convert arguments to array and cut off target object                                                              //
		var args = Array.prototype.slice.call(arguments, 1);                                                                 // 94
                                                                                                                       //
		var val, src, clone;                                                                                                 // 96
                                                                                                                       //
		args.forEach(function (obj) {                                                                                        // 98
			// skip argument if it is array or isn't object                                                                     //
			if (typeof obj !== 'object' || Array.isArray(obj)) {                                                                // 100
				return;                                                                                                            // 101
			}                                                                                                                   //
                                                                                                                       //
			Object.keys(obj).forEach(function (key) {                                                                           // 104
				src = target[key]; // source value                                                                                 // 105
				val = obj[key]; // new value                                                                                       // 106
                                                                                                                       //
				// recursion prevention                                                                                            //
				if (val === target) {                                                                                              // 109
					return;                                                                                                           // 110
                                                                                                                       //
					/**                                                                                                               //
      * if new value isn't object then just overwrite by new value                                                     //
      * instead of extending.                                                                                          //
      */                                                                                                               //
				} else if (typeof val !== 'object' || val === null) {                                                              //
						target[key] = val;                                                                                               // 117
						return;                                                                                                          // 118
                                                                                                                       //
						// just clone arrays (and recursive clone objects inside)                                                        //
					} else if (Array.isArray(val)) {                                                                                  //
							target[key] = deepCloneArray(val);                                                                              // 122
							return;                                                                                                         // 123
                                                                                                                       //
							// custom cloning and overwrite for specific objects                                                            //
						} else if (isSpecificValue(val)) {                                                                               //
								target[key] = cloneSpecificValue(val);                                                                         // 127
								return;                                                                                                        // 128
                                                                                                                       //
								// overwrite by new value if source isn't object or array                                                      //
							} else if (typeof src !== 'object' || src === null || Array.isArray(src)) {                                     //
									target[key] = deepExtend({}, val);                                                                            // 132
									return;                                                                                                       // 133
                                                                                                                       //
									// source value and new value is objects both, extending...                                                   //
								} else {                                                                                                       //
										target[key] = deepExtend(src, val);                                                                          // 137
										return;                                                                                                      // 138
									}                                                                                                             //
			});                                                                                                                 //
		});                                                                                                                  //
                                                                                                                       //
		return target;                                                                                                       // 143
	}                                                                                                                     //
                                                                                                                       //
	return {                                                                                                              //
		setters: [],                                                                                                         //
		execute: function () {                                                                                               //
			/*!                                                                                                                 //
    * @description Recursive object extending                                                                          //
    * @author Viacheslav Lotsmanov <lotsmanov89@gmail.com>                                                             //
    * @license MIT                                                                                                     //
    *                                                                                                                  //
    * The MIT License (MIT)                                                                                            //
    *                                                                                                                  //
    * Copyright (c) 2013-2015 Viacheslav Lotsmanov                                                                     //
    *                                                                                                                  //
    * Permission is hereby granted, free of charge, to any person obtaining a copy of                                  //
    * this software and associated documentation files (the "Software"), to deal in                                    //
    * the Software without restriction, including without limitation the rights to                                     //
    * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of                                 //
    * the Software, and to permit persons to whom the Software is furnished to do so,                                  //
    * subject to the following conditions:                                                                             //
    *                                                                                                                  //
    * The above copyright notice and this permission notice shall be included in all                                   //
    * copies or substantial portions of the Software.                                                                  //
    *                                                                                                                  //
    * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR                                       //
    * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS                                 //
    * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR                                   //
    * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER                                   //
    * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN                                          //
    * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.                                       //
    */                                                                                                                 //
                                                                                                                       //
			isBuffer = typeof Buffer !== 'undefined';                                                                           // 28
		}                                                                                                                    //
	};                                                                                                                    //
});                                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/universe_utilities-react/index.import.js                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
System.register('/_modules_/packages/universe/utilities-react/index', ['./mixins/autorun', './mixins/dualLink', './mixins/subscription', './helpers/classnames', './helpers/execution-environment', './helpers/object-assign', './helpers/deep-equal', './helpers/deep-extend', './helpers/react-clonewithprops'], function (_export) {
  return {                                                                                                             //
    setters: [function (_mixinsAutorun) {                                                                              //
      _export('AutorunMixin', _mixinsAutorun['default']);                                                              //
    }, function (_mixinsDualLink) {                                                                                    //
      _export('DualLinkMixin', _mixinsDualLink['default']);                                                            //
    }, function (_mixinsSubscription) {                                                                                //
      _export('SubscriptionMixin', _mixinsSubscription['default']);                                                    //
    }, function (_helpersClassnames) {                                                                                 //
      _export('classNames', _helpersClassnames['default']);                                                            //
    }, function (_helpersExecutionEnvironment) {                                                                       //
      _export('executionEnvironment', _helpersExecutionEnvironment['default']);                                        //
    }, function (_helpersObjectAssign) {                                                                               //
      _export('objectAssign', _helpersObjectAssign['default']);                                                        //
    }, function (_helpersDeepEqual) {                                                                                  //
      _export('deepEqual', _helpersDeepEqual['default']);                                                              //
    }, function (_helpersDeepExtend) {                                                                                 //
      _export('deepExtend', _helpersDeepExtend['default']);                                                            //
    }, function (_helpersReactClonewithprops) {                                                                        //
      _export('cloneWithProps', _helpersReactClonewithprops['default']);                                               //
    }],                                                                                                                //
    execute: function () {}                                                                                            //
  };                                                                                                                   //
});                                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['universe:utilities-react'] = {};

})();

//# sourceMappingURL=universe_utilities-react.js.map
