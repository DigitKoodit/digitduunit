(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;
var ECMAScript = Package.ecmascript.ECMAScript;
var Promise = Package.promise.Promise;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;

/* Package-scope variables */
var __UniverseNPMDynamicLoader;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/universe_modules-npm/system/UniverseNPMDynamicLoader.js                                   //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
                                                                                                      //
__UniverseNPMDynamicLoader = function (moduleId, deps, sysCfg, fn, indexes) {                         // 2
    var _meta;                                                                                        //
                                                                                                      //
    System.registerDynamic(moduleId, deps, true, fn);                                                 // 3
    var loaderName = 'UniverseDynamicLoader_' + camelCase(moduleId.replace(/[:\/\\]/g, '_'));         // 4
    var pathAll = moduleId + '/*';                                                                    // 5
    System.config({                                                                                   // 6
        meta: (_meta = {}, _meta[pathAll] = {                                                         // 7
            format: 'register',                                                                       // 9
            loader: loaderName                                                                        // 10
        }, _meta)                                                                                     //
    });                                                                                               //
    if (typeof sysCfg === 'object' && Object.keys(sysCfg).length) {                                   // 14
        System.config(sysCfg);                                                                        // 15
    }                                                                                                 //
                                                                                                      //
    var _loader = {                                                                                   // 18
        locate: (function () {                                                                        // 19
            function locate(params) {                                                                 // 19
                var name = params.name;                                                               // 20
                var metadata = params.metadata;                                                       // 21
                return new Promise(function (resolve, reject) {                                       // 22
                    var names = name.split(moduleId + '/');                                           // 23
                    metadata.submoduleName = names[1];                                                // 24
                    // check if we're in valid namespace                                              //
                    if (names[0] || !metadata.submoduleName) {                                        // 26
                        reject(new Error('[Universe Modules NPM]: trying to get exported values from invalid package: ' + name));
                        return;                                                                       // 28
                    }                                                                                 //
                    resolve(name);                                                                    // 30
                });                                                                                   //
            }                                                                                         //
                                                                                                      //
            return locate;                                                                            //
        })(),                                                                                         //
        fetch: (function () {                                                                         // 33
            function fetch() {                                                                        // 33
                // we don't need to fetch anything for local bundle                                   //
                return '';                                                                            // 35
            }                                                                                         //
                                                                                                      //
            return fetch;                                                                             //
        })(),                                                                                         //
        instantiate: (function () {                                                                   // 37
            function instantiate(params) {                                                            // 37
                var metadata = params.metadata;                                                       // 38
                return System['import'](moduleId).then(function (_ref) {                              // 39
                    var _bundleRequire = _ref._bundleRequire;                                         //
                                                                                                      //
                    return _bundleRequire(indexes[metadata.submoduleName] || metadata.submoduleName);
                });                                                                                   //
            }                                                                                         //
                                                                                                      //
            return instantiate;                                                                       //
        })()                                                                                          //
    };                                                                                                //
    // Register our loader                                                                            //
    System.set(loaderName, System.newModule(_loader));                                                // 45
};                                                                                                    //
                                                                                                      //
var camelCase = function () {                                                                         // 48
    var str = [].map.call(arguments, function (str) {                                                 // 49
        return str.trim();                                                                            // 50
    }).filter(function (str) {                                                                        //
        return str.length;                                                                            // 52
    }).join('-');                                                                                     //
                                                                                                      //
    if (!str.length) {                                                                                // 55
        return '';                                                                                    // 56
    }                                                                                                 //
                                                                                                      //
    if (str.length === 1) {                                                                           // 59
        return str;                                                                                   // 60
    }                                                                                                 //
                                                                                                      //
    if (!/[_.\- ]+/.test(str)) {                                                                      // 63
        if (str === str.toUpperCase()) {                                                              // 64
            return str.toLowerCase();                                                                 // 65
        }                                                                                             //
                                                                                                      //
        if (str[0] !== str[0].toLowerCase()) {                                                        // 68
            return str[0].toLowerCase() + str.slice(1);                                               // 69
        }                                                                                             //
                                                                                                      //
        return str;                                                                                   // 72
    }                                                                                                 //
                                                                                                      //
    return str.replace(/^[_.\- ]+/, '').toLowerCase().replace(/[_.\- ]+(\w|$)/g, function (m, p1) {   // 75
        return p1.toUpperCase();                                                                      // 79
    });                                                                                               //
};                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['universe:modules-npm'] = {
  __UniverseNPMDynamicLoader: __UniverseNPMDynamicLoader
};

})();

//# sourceMappingURL=universe_modules-npm.js.map
