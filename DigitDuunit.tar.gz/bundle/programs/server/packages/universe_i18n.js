(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var ECMAScript = Package.ecmascript.ECMAScript;
var UniUtils = Package['universe:utilities'].UniUtils;
var UniConfig = Package['universe:utilities'].UniConfig;
var React = Package['react-runtime'].React;
var ReactDOM = Package['react-runtime'].ReactDOM;
var ReactDOMServer = Package['react-runtime'].ReactDOMServer;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var locales, _i18n;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/universe_i18n/lib/locales.js                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
locales = {                                                                                                            // 1
  //   key: [code, name, localName, isRTL, numberTypographic, decimal, currency, groupNumberBY]                        //
  "af": ["af", "Afrikaans", "Afrikaans", false, ",.", 2, "R", [3]],                                                    // 3
  "af-za": ["af-ZA", "Afrikaans (South Africa)", "Afrikaans (Suid Afrika)", false, ",.", 2, "R", [3]],                 // 4
  "am": ["am", "Amharic", "አማርኛ", false, ",.", 1, "ETB", [3, 0]],                                                      // 5
  "am-et": ["am-ET", "Amharic (Ethiopia)", "አማርኛ (ኢትዮጵያ)", false, ",.", 1, "ETB", [3, 0]],                             // 6
  "ar": ["ar", "Arabic", "العربية", true, ",.", 2, "ر.س.‏", [3]],                                                      // 7
  "ar-ae": ["ar-AE", "Arabic (U.A.E.)", "العربية (الإمارات العربية المتحدة)", true, ",.", 2, "د.إ.‏", [3]],            // 8
  "ar-bh": ["ar-BH", "Arabic (Bahrain)", "العربية (البحرين)", true, ",.", 3, "د.ب.‏", [3]],                            // 9
  "ar-dz": ["ar-DZ", "Arabic (Algeria)", "العربية (الجزائر)", true, ",.", 2, "د.ج.‏", [3]],                            // 10
  "ar-eg": ["ar-EG", "Arabic (Egypt)", "العربية (مصر)", true, ",.", 3, "ج.م.‏", [3]],                                  // 11
  "ar-iq": ["ar-IQ", "Arabic (Iraq)", "العربية (العراق)", true, ",.", 2, "د.ع.‏", [3]],                                // 12
  "ar-jo": ["ar-JO", "Arabic (Jordan)", "العربية (الأردن)", true, ",.", 3, "د.ا.‏", [3]],                              // 13
  "ar-kw": ["ar-KW", "Arabic (Kuwait)", "العربية (الكويت)", true, ",.", 3, "د.ك.‏", [3]],                              // 14
  "ar-lb": ["ar-LB", "Arabic (Lebanon)", "العربية (لبنان)", true, ",.", 2, "ل.ل.‏", [3]],                              // 15
  "ar-ly": ["ar-LY", "Arabic (Libya)", "العربية (ليبيا)", true, ",.", 3, "د.ل.‏", [3]],                                // 16
  "ar-ma": ["ar-MA", "Arabic (Morocco)", "العربية (المملكة المغربية)", true, ",.", 2, "د.م.‏", [3]],                   // 17
  "ar-om": ["ar-OM", "Arabic (Oman)", "العربية (عمان)", true, ",.", 2, "ر.ع.‏", [3]],                                  // 18
  "ar-qa": ["ar-QA", "Arabic (Qatar)", "العربية (قطر)", true, ",.", 2, "ر.ق.‏", [3]],                                  // 19
  "ar-sa": ["ar-SA", "Arabic (Saudi Arabia)", "العربية (المملكة العربية السعودية)", true, ",.", 2, "ر.س.‏", [3]],      // 20
  "ar-sy": ["ar-SY", "Arabic (Syria)", "العربية (سوريا)", true, ",.", 2, "ل.س.‏", [3]],                                // 21
  "ar-tn": ["ar-TN", "Arabic (Tunisia)", "العربية (تونس)", true, ",.", 3, "د.ت.‏", [3]],                               // 22
  "ar-ye": ["ar-YE", "Arabic (Yemen)", "العربية (اليمن)", true, ",.", 2, "ر.ي.‏", [3]],                                // 23
  "arn": ["arn", "Mapudungun", "Mapudungun", false, ".,", 2, "$", [3]],                                                // 24
  "arn-cl": ["arn-CL", "Mapudungun (Chile)", "Mapudungun (Chile)", false, ".,", 2, "$", [3]],                          // 25
  "as": ["as", "Assamese", "অসমীয়া", false, ",.", 2, "ট", [3, 2]],                                                     // 26
  "as-in": ["as-IN", "Assamese (India)", "অসমীয়া (ভাৰত)", false, ",.", 2, "ট", [3, 2]],                                // 27
  "az": ["az", "Azeri", "Azərbaycan­ılı", false, " ,", 2, "man.", [3]],                                                // 28
  "az-cyrl": ["az-Cyrl", "Azeri (Cyrillic)", "Азәрбајҹан дили", false, " ,", 2, "ман.", [3]],                          // 29
  "az-cyrl-az": ["az-Cyrl-AZ", "Azeri (Cyrillic, Azerbaijan)", "Азәрбајҹан (Азәрбајҹан)", false, " ,", 2, "ман.", [3]],
  "az-latn": ["az-Latn", "Azeri (Latin)", "Azərbaycan­ılı", false, " ,", 2, "man.", [3]],                              // 31
  "az-latn-az": ["az-Latn-AZ", "Azeri (Latin, Azerbaijan)", "Azərbaycan­ılı (Azərbaycan)", false, " ,", 2, "man.", [3]],
  "ba": ["ba", "Bashkir", "Башҡорт", false, " ,", 2, "һ.", [3, 0]],                                                    // 33
  "ba-ru": ["ba-RU", "Bashkir (Russia)", "Башҡорт (Россия)", false, " ,", 2, "һ.", [3, 0]],                            // 34
  "be": ["be", "Belarusian", "Беларускі", false, " ,", 2, "р.", [3]],                                                  // 35
  "be-by": ["be-BY", "Belarusian (Belarus)", "Беларускі (Беларусь)", false, " ,", 2, "р.", [3]],                       // 36
  "bg": ["bg", "Bulgarian", "български", false, " ,", 2, "лв.", [3]],                                                  // 37
  "bg-bg": ["bg-BG", "Bulgarian (Bulgaria)", "български (България)", false, " ,", 2, "лв.", [3]],                      // 38
  "bn": ["bn", "Bengali", "বাংলা", false, ",.", 2, "টা", [3, 2]],                                                      // 39
  "bn-bd": ["bn-BD", "Bengali (Bangladesh)", "বাংলা (বাংলাদেশ)", false, ",.", 2, "৳", [3, 2]],                         // 40
  "bn-in": ["bn-IN", "Bengali (India)", "বাংলা (ভারত)", false, ",.", 2, "টা", [3, 2]],                                 // 41
  "bo": ["bo", "Tibetan", "བོད་ཡིག", false, ",.", 2, "¥", [3, 0]],                                                     // 42
  "bo-cn": ["bo-CN", "Tibetan (PRC)", "བོད་ཡིག (ཀྲུང་ཧྭ་མི་དམངས་སྤྱི་མཐུན་རྒྱལ་ཁབ།)", false, ",.", 2, "¥", [3, 0]],    // 43
  "br": ["br", "Breton", "brezhoneg", false, " ,", 2, "€", [3]],                                                       // 44
  "br-fr": ["br-FR", "Breton (France)", "brezhoneg (Frañs)", false, " ,", 2, "€", [3]],                                // 45
  "bs": ["bs", "Bosnian", "bosanski", false, ".,", 2, "KM", [3]],                                                      // 46
  "bs-cyrl": ["bs-Cyrl", "Bosnian (Cyrillic)", "босански", false, ".,", 2, "КМ", [3]],                                 // 47
  "bs-cyrl-ba": ["bs-Cyrl-BA", "Bosnian (Cyrillic, Bosnia and Herzegovina)", "босански (Босна и Херцеговина)", false, ".,", 2, "КМ", [3]],
  "bs-latn": ["bs-Latn", "Bosnian (Latin)", "bosanski", false, ".,", 2, "KM", [3]],                                    // 49
  "bs-latn-ba": ["bs-Latn-BA", "Bosnian (Latin, Bosnia and Herzegovina)", "bosanski (Bosna i Hercegovina)", false, ".,", 2, "KM", [3]],
  "ca": ["ca", "Catalan", "català", false, ".,", 2, "€", [3]],                                                         // 51
  "ca-es": ["ca-ES", "Catalan (Catalan)", "català (català)", false, ".,", 2, "€", [3]],                                // 52
  "co": ["co", "Corsican", "Corsu", false, " ,", 2, "€", [3]],                                                         // 53
  "co-fr": ["co-FR", "Corsican (France)", "Corsu (France)", false, " ,", 2, "€", [3]],                                 // 54
  "cs": ["cs", "Czech", "čeština", false, " ,", 2, "Kč", [3]],                                                         // 55
  "cs-cz": ["cs-CZ", "Czech (Czech Republic)", "čeština (Česká republika)", false, " ,", 2, "Kč", [3]],                // 56
  "cy": ["cy", "Welsh", "Cymraeg", false, ",.", 2, "£", [3]],                                                          // 57
  "cy-gb": ["cy-GB", "Welsh (United Kingdom)", "Cymraeg (y Deyrnas Unedig)", false, ",.", 2, "£", [3]],                // 58
  "da": ["da", "Danish", "dansk", false, ".,", 2, "kr.", [3]],                                                         // 59
  "da-dk": ["da-DK", "Danish (Denmark)", "dansk (Danmark)", false, ".,", 2, "kr.", [3]],                               // 60
  "de": ["de", "German", "Deutsch", false, ".,", 2, "€", [3]],                                                         // 61
  "de-at": ["de-AT", "German (Austria)", "Deutsch (Österreich)", false, ".,", 2, "€", [3]],                            // 62
  "de-ch": ["de-CH", "German (Switzerland)", "Deutsch (Schweiz)", false, "'.", 2, "Fr.", [3]],                         // 63
  "de-de": ["de-DE", "German (Germany)", "Deutsch (Deutschland)", false, ".,", 2, "€", [3]],                           // 64
  "de-li": ["de-LI", "German (Liechtenstein)", "Deutsch (Liechtenstein)", false, "'.", 2, "CHF", [3]],                 // 65
  "de-lu": ["de-LU", "German (Luxembourg)", "Deutsch (Luxemburg)", false, ".,", 2, "€", [3]],                          // 66
  "dsb": ["dsb", "Lower Sorbian", "dolnoserbšćina", false, ".,", 2, "€", [3]],                                         // 67
  "dsb-de": ["dsb-DE", "Lower Sorbian (Germany)", "dolnoserbšćina (Nimska)", false, ".,", 2, "€", [3]],                // 68
  "dv": ["dv", "Divehi", "ދިވެހިބަސް", true, ",.", 2, "ރ.", [3]],                                                      // 69
  "dv-mv": ["dv-MV", "Divehi (Maldives)", "ދިވެހިބަސް (ދިވެހި ރާއްޖެ)", true, ",.", 2, "ރ.", [3]],                     // 70
  "el": ["el", "Greek", "Ελληνικά", false, ".,", 2, "€", [3]],                                                         // 71
  "el-gr": ["el-GR", "Greek (Greece)", "Ελληνικά (Ελλάδα)", false, ".,", 2, "€", [3]],                                 // 72
  "en": ["en", "English", "English", false, ",.", 2, "$", [3]],                                                        // 73
  "en-029": ["en-029", "English (Caribbean)", "English (Caribbean)", false, ",.", 2, "$", [3]],                        // 74
  "en-au": ["en-AU", "English (Australia)", "English (Australia)", false, ",.", 2, "$", [3]],                          // 75
  "en-bz": ["en-BZ", "English (Belize)", "English (Belize)", false, ",.", 2, "BZ$", [3]],                              // 76
  "en-ca": ["en-CA", "English (Canada)", "English (Canada)", false, ",.", 2, "$", [3]],                                // 77
  "en-gb": ["en-GB", "English (United Kingdom)", "English (United Kingdom)", false, ",.", 2, "£", [3]],                // 78
  "en-ie": ["en-IE", "English (Ireland)", "English (Ireland)", false, ",.", 2, "€", [3]],                              // 79
  "en-in": ["en-IN", "English (India)", "English (India)", false, ",.", 2, "Rs.", [3, 2]],                             // 80
  "en-jm": ["en-JM", "English (Jamaica)", "English (Jamaica)", false, ",.", 2, "J$", [3]],                             // 81
  "en-my": ["en-MY", "English (Malaysia)", "English (Malaysia)", false, ",.", 2, "RM", [3]],                           // 82
  "en-nz": ["en-NZ", "English (New Zealand)", "English (New Zealand)", false, ",.", 2, "$", [3]],                      // 83
  "en-ph": ["en-PH", "English (Republic of the Philippines)", "English (Philippines)", false, ",.", 2, "Php", [3]],    // 84
  "en-sg": ["en-SG", "English (Singapore)", "English (Singapore)", false, ",.", 2, "$", [3]],                          // 85
  "en-tt": ["en-TT", "English (Trinidad and Tobago)", "English (Trinidad y Tobago)", false, ",.", 2, "TT$", [3]],      // 86
  "en-us": ["en-US", "English (United States)", "English", false, ",.", 2, "$", [3]],                                  // 87
  "en-za": ["en-ZA", "English (South Africa)", "English (South Africa)", false, " ,", 2, "R", [3]],                    // 88
  "en-zw": ["en-ZW", "English (Zimbabwe)", "English (Zimbabwe)", false, ",.", 2, "Z$", [3]],                           // 89
  "es": ["es", "Spanish", "español", false, ".,", 2, "€", [3]],                                                        // 90
  "es-ar": ["es-AR", "Spanish (Argentina)", "Español (Argentina)", false, ".,", 2, "$", [3]],                          // 91
  "es-bo": ["es-BO", "Spanish (Bolivia)", "Español (Bolivia)", false, ".,", 2, "$b", [3]],                             // 92
  "es-cl": ["es-CL", "Spanish (Chile)", "Español (Chile)", false, ".,", 2, "$", [3]],                                  // 93
  "es-co": ["es-CO", "Spanish (Colombia)", "Español (Colombia)", false, ".,", 2, "$", [3]],                            // 94
  "es-cr": ["es-CR", "Spanish (Costa Rica)", "Español (Costa Rica)", false, ".,", 2, "₡", [3]],                        // 95
  "es-do": ["es-DO", "Spanish (Dominican Republic)", "Español (República Dominicana)", false, ",.", 2, "RD$", [3]],    // 96
  "es-ec": ["es-EC", "Spanish (Ecuador)", "Español (Ecuador)", false, ".,", 2, "$", [3]],                              // 97
  "es-es": ["es-ES", "Spanish (Spain, International Sort)", "Español (España, alfabetización internacional)", false, ".,", 2, "€", [3]],
  "es-gt": ["es-GT", "Spanish (Guatemala)", "Español (Guatemala)", false, ",.", 2, "Q", [3]],                          // 99
  "es-hn": ["es-HN", "Spanish (Honduras)", "Español (Honduras)", false, ",.", 2, "L.", [3]],                           // 100
  "es-mx": ["es-MX", "Spanish (Mexico)", "Español (México)", false, ",.", 2, "$", [3]],                                // 101
  "es-ni": ["es-NI", "Spanish (Nicaragua)", "Español (Nicaragua)", false, ",.", 2, "C$", [3]],                         // 102
  "es-pa": ["es-PA", "Spanish (Panama)", "Español (Panamá)", false, ",.", 2, "B/.", [3]],                              // 103
  "es-pe": ["es-PE", "Spanish (Peru)", "Español (Perú)", false, ",.", 2, "S/.", [3]],                                  // 104
  "es-pr": ["es-PR", "Spanish (Puerto Rico)", "Español (Puerto Rico)", false, ",.", 2, "$", [3]],                      // 105
  "es-py": ["es-PY", "Spanish (Paraguay)", "Español (Paraguay)", false, ".,", 2, "Gs", [3]],                           // 106
  "es-sv": ["es-SV", "Spanish (El Salvador)", "Español (El Salvador)", false, ",.", 2, "$", [3]],                      // 107
  "es-us": ["es-US", "Spanish (United States)", "Español (Estados Unidos)", false, ",.", 2, "$", [3, 0]],              // 108
  "es-uy": ["es-UY", "Spanish (Uruguay)", "Español (Uruguay)", false, ".,", 2, "$U", [3]],                             // 109
  "es-ve": ["es-VE", "Spanish (Bolivarian Republic of Venezuela)", "Español (Republica Bolivariana de Venezuela)", false, ".,", 2, "Bs. F.", [3]],
  "et": ["et", "Estonian", "eesti", false, " .", 2, "kr", [3]],                                                        // 111
  "et-ee": ["et-EE", "Estonian (Estonia)", "eesti (Eesti)", false, " .", 2, "kr", [3]],                                // 112
  "eu": ["eu", "Basque", "euskara", false, ".,", 2, "€", [3]],                                                         // 113
  "eu-es": ["eu-ES", "Basque (Basque)", "euskara (euskara)", false, ".,", 2, "€", [3]],                                // 114
  "fa": ["fa", "Persian", "فارسى", true, ",/", 2, "ريال", [3]],                                                        // 115
  "fa-ir": ["fa-IR", "Persian", "فارسى (ایران)", true, ",/", 2, "ريال", [3]],                                          // 116
  "fi": ["fi", "Finnish", "suomi", false, " ,", 2, "€", [3]],                                                          // 117
  "fi-fi": ["fi-FI", "Finnish (Finland)", "suomi (Suomi)", false, " ,", 2, "€", [3]],                                  // 118
  "fil": ["fil", "Filipino", "Filipino", false, ",.", 2, "PhP", [3]],                                                  // 119
  "fil-ph": ["fil-PH", "Filipino (Philippines)", "Filipino (Pilipinas)", false, ",.", 2, "PhP", [3]],                  // 120
  "fo": ["fo", "Faroese", "føroyskt", false, ".,", 2, "kr.", [3]],                                                     // 121
  "fo-fo": ["fo-FO", "Faroese (Faroe Islands)", "føroyskt (Føroyar)", false, ".,", 2, "kr.", [3]],                     // 122
  "fr": ["fr", "French", "français", false, " ,", 2, "€", [3]],                                                        // 123
  "fr-be": ["fr-BE", "French (Belgium)", "français (Belgique)", false, ".,", 2, "€", [3]],                             // 124
  "fr-ca": ["fr-CA", "French (Canada)", "français (Canada)", false, " ,", 2, "$", [3]],                                // 125
  "fr-ch": ["fr-CH", "French (Switzerland)", "français (Suisse)", false, "'.", 2, "fr.", [3]],                         // 126
  "fr-fr": ["fr-FR", "French (France)", "français (France)", false, " ,", 2, "€", [3]],                                // 127
  "fr-lu": ["fr-LU", "French (Luxembourg)", "français (Luxembourg)", false, " ,", 2, "€", [3]],                        // 128
  "fr-mc": ["fr-MC", "French (Monaco)", "français (Principauté de Monaco)", false, " ,", 2, "€", [3]],                 // 129
  "fy": ["fy", "Frisian", "Frysk", false, ".,", 2, "€", [3]],                                                          // 130
  "fy-nl": ["fy-NL", "Frisian (Netherlands)", "Frysk (Nederlân)", false, ".,", 2, "€", [3]],                           // 131
  "ga": ["ga", "Irish", "Gaeilge", false, ",.", 2, "€", [3]],                                                          // 132
  "ga-ie": ["ga-IE", "Irish (Ireland)", "Gaeilge (Éire)", false, ",.", 2, "€", [3]],                                   // 133
  "gd": ["gd", "Scottish Gaelic", "Gàidhlig", false, ",.", 2, "£", [3]],                                               // 134
  "gd-gb": ["gd-GB", "Scottish Gaelic (United Kingdom)", "Gàidhlig (An Rìoghachd Aonaichte)", false, ",.", 2, "£", [3]],
  "gl": ["gl", "Galician", "galego", false, ".,", 2, "€", [3]],                                                        // 136
  "gl-es": ["gl-ES", "Galician (Galician)", "galego (galego)", false, ".,", 2, "€", [3]],                              // 137
  "gsw": ["gsw", "Alsatian", "Elsässisch", false, " ,", 2, "€", [3]],                                                  // 138
  "gsw-fr": ["gsw-FR", "Alsatian (France)", "Elsässisch (Frànkrisch)", false, " ,", 2, "€", [3]],                      // 139
  "gu": ["gu", "Gujarati", "ગુજરાતી", false, ",.", 2, "રૂ", [3, 2]],                                                   // 140
  "gu-in": ["gu-IN", "Gujarati (India)", "ગુજરાતી (ભારત)", false, ",.", 2, "રૂ", [3, 2]],                              // 141
  "ha": ["ha", "Hausa", "Hausa", false, ",.", 2, "N", [3]],                                                            // 142
  "ha-latn": ["ha-Latn", "Hausa (Latin)", "Hausa", false, ",.", 2, "N", [3]],                                          // 143
  "ha-latn-ng": ["ha-Latn-NG", "Hausa (Latin, Nigeria)", "Hausa (Nigeria)", false, ",.", 2, "N", [3]],                 // 144
  "he": ["he", "Hebrew", "עברית", true, ",.", 2, "₪", [3]],                                                            // 145
  "he-il": ["he-IL", "Hebrew (Israel)", "עברית (ישראל)", true, ",.", 2, "₪", [3]],                                     // 146
  "hi": ["hi", "Hindi", "हिंदी", false, ",.", 2, "रु", [3, 2]],                                                        // 147
  "hi-in": ["hi-IN", "Hindi (India)", "हिंदी (भारत)", false, ",.", 2, "रु", [3, 2]],                                   // 148
  "hr": ["hr", "Croatian", "hrvatski", false, ".,", 2, "kn", [3]],                                                     // 149
  "hr-ba": ["hr-BA", "Croatian (Latin, Bosnia and Herzegovina)", "hrvatski (Bosna i Hercegovina)", false, ".,", 2, "KM", [3]],
  "hr-hr": ["hr-HR", "Croatian (Croatia)", "hrvatski (Hrvatska)", false, ".,", 2, "kn", [3]],                          // 151
  "hsb": ["hsb", "Upper Sorbian", "hornjoserbšćina", false, ".,", 2, "€", [3]],                                        // 152
  "hsb-de": ["hsb-DE", "Upper Sorbian (Germany)", "hornjoserbšćina (Němska)", false, ".,", 2, "€", [3]],               // 153
  "hu": ["hu", "Hungarian", "magyar", false, " ,", 2, "Ft", [3]],                                                      // 154
  "hu-hu": ["hu-HU", "Hungarian (Hungary)", "magyar (Magyarország)", false, " ,", 2, "Ft", [3]],                       // 155
  "hy": ["hy", "Armenian", "Հայերեն", false, ",.", 2, "դր.", [3]],                                                     // 156
  "hy-am": ["hy-AM", "Armenian (Armenia)", "Հայերեն (Հայաստան)", false, ",.", 2, "դր.", [3]],                          // 157
  "id": ["id", "Indonesian", "Bahasa Indonesia", false, ".,", 2, "Rp", [3]],                                           // 158
  "id-id": ["id-ID", "Indonesian (Indonesia)", "Bahasa Indonesia (Indonesia)", false, ".,", 2, "Rp", [3]],             // 159
  "ig": ["ig", "Igbo", "Igbo", false, ",.", 2, "N", [3]],                                                              // 160
  "ig-ng": ["ig-NG", "Igbo (Nigeria)", "Igbo (Nigeria)", false, ",.", 2, "N", [3]],                                    // 161
  "ii": ["ii", "Yi", "ꆈꌠꁱꂷ", false, ",.", 2, "¥", [3, 0]],                                                             // 162
  "ii-cn": ["ii-CN", "Yi (PRC)", "ꆈꌠꁱꂷ (ꍏꉸꏓꂱꇭꉼꇩ)", false, ",.", 2, "¥", [3, 0]],                                       // 163
  "is": ["is", "Icelandic", "íslenska", false, ".,", 2, "kr.", [3]],                                                   // 164
  "is-is": ["is-IS", "Icelandic (Iceland)", "íslenska (Ísland)", false, ".,", 2, "kr.", [3]],                          // 165
  "it": ["it", "Italian", "italiano", false, ".,", 2, "€", [3]],                                                       // 166
  "it-ch": ["it-CH", "Italian (Switzerland)", "italiano (Svizzera)", false, "'.", 2, "fr.", [3]],                      // 167
  "it-it": ["it-IT", "Italian (Italy)", "italiano (Italia)", false, ".,", 2, "€", [3]],                                // 168
  "iu": ["iu", "Inuktitut", "Inuktitut", false, ",.", 2, "$", [3, 0]],                                                 // 169
  "iu-cans": ["iu-Cans", "Inuktitut (Syllabics)", "ᐃᓄᒃᑎᑐᑦ", false, ",.", 2, "$", [3, 0]],                              // 170
  "iu-cans-ca": ["iu-Cans-CA", "Inuktitut (Syllabics, Canada)", "ᐃᓄᒃᑎᑐᑦ (ᑲᓇᑕᒥ)", false, ",.", 2, "$", [3, 0]],         // 171
  "iu-latn": ["iu-Latn", "Inuktitut (Latin)", "Inuktitut", false, ",.", 2, "$", [3, 0]],                               // 172
  "iu-latn-ca": ["iu-Latn-CA", "Inuktitut (Latin, Canada)", "Inuktitut (Kanatami)", false, ",.", 2, "$", [3, 0]],      // 173
  "ja": ["ja", "Japanese", "日本語", false, ",.", 2, "¥", [3]],                                                           // 174
  "ja-jp": ["ja-JP", "Japanese (Japan)", "日本語 (日本)", false, ",.", 2, "¥", [3]],                                        // 175
  "ka": ["ka", "Georgian", "ქართული", false, " ,", 2, "Lari", [3]],                                                    // 176
  "ka-ge": ["ka-GE", "Georgian (Georgia)", "ქართული (საქართველო)", false, " ,", 2, "Lari", [3]],                       // 177
  "kk": ["kk", "Kazakh", "Қазақ", false, " -", 2, "Т", [3]],                                                           // 178
  "kk-kz": ["kk-KZ", "Kazakh (Kazakhstan)", "Қазақ (Қазақстан)", false, " -", 2, "Т", [3]],                            // 179
  "kl": ["kl", "Greenlandic", "kalaallisut", false, ".,", 2, "kr.", [3, 0]],                                           // 180
  "kl-gl": ["kl-GL", "Greenlandic (Greenland)", "kalaallisut (Kalaallit Nunaat)", false, ".,", 2, "kr.", [3, 0]],      // 181
  "km": ["km", "Khmer", "ខ្មែរ", false, ",.", 2, "៛", [3, 0]],                                                         // 182
  "km-kh": ["km-KH", "Khmer (Cambodia)", "ខ្មែរ (កម្ពុជា)", false, ",.", 2, "៛", [3, 0]],                              // 183
  "kn": ["kn", "Kannada", "ಕನ್ನಡ", false, ",.", 2, "ರೂ", [3, 2]],                                                      // 184
  "kn-in": ["kn-IN", "Kannada (India)", "ಕನ್ನಡ (ಭಾರತ)", false, ",.", 2, "ರೂ", [3, 2]],                                 // 185
  "ko": ["ko", "Korean", "한국어", false, ",.", 2, "₩", [3]],                                                             // 186
  "ko-kr": ["ko-KR", "Korean (Korea)", "한국어 (대한민국)", false, ",.", 2, "₩", [3]],                                        // 187
  "kok": ["kok", "Konkani", "कोंकणी", false, ",.", 2, "रु", [3, 2]],                                                   // 188
  "kok-in": ["kok-IN", "Konkani (India)", "कोंकणी (भारत)", false, ",.", 2, "रु", [3, 2]],                              // 189
  "ky": ["ky", "Kyrgyz", "Кыргыз", false, " -", 2, "сом", [3]],                                                        // 190
  "ky-kg": ["ky-KG", "Kyrgyz (Kyrgyzstan)", "Кыргыз (Кыргызстан)", false, " -", 2, "сом", [3]],                        // 191
  "lb": ["lb", "Luxembourgish", "Lëtzebuergesch", false, " ,", 2, "€", [3]],                                           // 192
  "lb-lu": ["lb-LU", "Luxembourgish (Luxembourg)", "Lëtzebuergesch (Luxembourg)", false, " ,", 2, "€", [3]],           // 193
  "lo": ["lo", "Lao", "ລາວ", false, ",.", 2, "₭", [3, 0]],                                                             // 194
  "lo-la": ["lo-LA", "Lao (Lao P.D.R.)", "ລາວ (ສ.ປ.ປ. ລາວ)", false, ",.", 2, "₭", [3, 0]],                             // 195
  "lt": ["lt", "Lithuanian", "lietuvių", false, ".,", 2, "Lt", [3]],                                                   // 196
  "lt-lt": ["lt-LT", "Lithuanian (Lithuania)", "lietuvių (Lietuva)", false, ".,", 2, "Lt", [3]],                       // 197
  "lv": ["lv", "Latvian", "latviešu", false, " ,", 2, "Ls", [3]],                                                      // 198
  "lv-lv": ["lv-LV", "Latvian (Latvia)", "latviešu (Latvija)", false, " ,", 2, "Ls", [3]],                             // 199
  "mi": ["mi", "Maori", "Reo Māori", false, ",.", 2, "$", [3]],                                                        // 200
  "mi-nz": ["mi-NZ", "Maori (New Zealand)", "Reo Māori (Aotearoa)", false, ",.", 2, "$", [3]],                         // 201
  "mk": ["mk", "Macedonian (FYROM)", "македонски јазик", false, ".,", 2, "ден.", [3]],                                 // 202
  "mk-mk": ["mk-MK", "Macedonian (Former Yugoslav Republic of Macedonia)", "македонски јазик (Македонија)", false, ".,", 2, "ден.", [3]],
  "ml": ["ml", "Malayalam", "മലയാളം", false, ",.", 2, "ക", [3, 2]],                                                    // 204
  "ml-in": ["ml-IN", "Malayalam (India)", "മലയാളം (ഭാരതം)", false, ",.", 2, "ക", [3, 2]],                              // 205
  "mn": ["mn", "Mongolian", "Монгол хэл", false, " ,", 2, "₮", [3]],                                                   // 206
  "mn-cyrl": ["mn-Cyrl", "Mongolian (Cyrillic)", "Монгол хэл", false, " ,", 2, "₮", [3]],                              // 207
  "mn-mn": ["mn-MN", "Mongolian (Cyrillic, Mongolia)", "Монгол хэл (Монгол улс)", false, " ,", 2, "₮", [3]],           // 208
  "mn-mong": ["mn-Mong", "Mongolian (Traditional Mongolian)", "ᠮᠤᠨᠭᠭᠤᠯ ᠬᠡᠯᠡ", false, ",.", 2, "¥", [3, 0]],            // 209
  "mn-mong-cn": ["mn-Mong-CN", "Mongolian (Traditional Mongolian, PRC)", "ᠮᠤᠨᠭᠭᠤᠯ ᠬᠡᠯᠡ (ᠪᠦᠭᠦᠳᠡ ᠨᠠᠢᠷᠠᠮᠳᠠᠬᠤ ᠳᠤᠮᠳᠠᠳᠤ ᠠᠷᠠᠳ ᠣᠯᠣᠰ)", false, ",.", 2, "¥", [3, 0]],
  "moh": ["moh", "Mohawk", "Kanien'kéha", false, ",.", 2, "$", [3, 0]],                                                // 211
  "moh-ca": ["moh-CA", "Mohawk (Mohawk)", "Kanien'kéha", false, ",.", 2, "$", [3, 0]],                                 // 212
  "mr": ["mr", "Marathi", "मराठी", false, ",.", 2, "रु", [3, 2]],                                                      // 213
  "mr-in": ["mr-IN", "Marathi (India)", "मराठी (भारत)", false, ",.", 2, "रु", [3, 2]],                                 // 214
  "ms": ["ms", "Malay", "Bahasa Melayu", false, ",.", 2, "RM", [3]],                                                   // 215
  "ms-bn": ["ms-BN", "Malay (Brunei Darussalam)", "Bahasa Melayu (Brunei Darussalam)", false, ".,", 2, "$", [3]],      // 216
  "ms-my": ["ms-MY", "Malay (Malaysia)", "Bahasa Melayu (Malaysia)", false, ",.", 2, "RM", [3]],                       // 217
  "mt": ["mt", "Maltese", "Malti", false, ",.", 2, "€", [3]],                                                          // 218
  "mt-mt": ["mt-MT", "Maltese (Malta)", "Malti (Malta)", false, ",.", 2, "€", [3]],                                    // 219
  "nb": ["nb", "Norwegian (Bokmål)", "norsk (bokmål)", false, " ,", 2, "kr", [3]],                                     // 220
  "nb-no": ["nb-NO", "Norwegian, Bokmål (Norway)", "norsk, bokmål (Norge)", false, " ,", 2, "kr", [3]],                // 221
  "ne": ["ne", "Nepali", "नेपाली", false, ",.", 2, "रु", [3, 2]],                                                      // 222
  "ne-np": ["ne-NP", "Nepali (Nepal)", "नेपाली (नेपाल)", false, ",.", 2, "रु", [3, 2]],                                // 223
  "nl": ["nl", "Dutch", "Nederlands", false, ".,", 2, "€", [3]],                                                       // 224
  "nl-be": ["nl-BE", "Dutch (Belgium)", "Nederlands (België)", false, ".,", 2, "€", [3]],                              // 225
  "nl-nl": ["nl-NL", "Dutch (Netherlands)", "Nederlands (Nederland)", false, ".,", 2, "€", [3]],                       // 226
  "nn": ["nn", "Norwegian (Nynorsk)", "norsk (nynorsk)", false, " ,", 2, "kr", [3]],                                   // 227
  "nn-no": ["nn-NO", "Norwegian, Nynorsk (Norway)", "norsk, nynorsk (Noreg)", false, " ,", 2, "kr", [3]],              // 228
  "no": ["no", "Norwegian", "norsk", false, " ,", 2, "kr", [3]],                                                       // 229
  "nso": ["nso", "Sesotho sa Leboa", "Sesotho sa Leboa", false, ",.", 2, "R", [3]],                                    // 230
  "nso-za": ["nso-ZA", "Sesotho sa Leboa (South Africa)", "Sesotho sa Leboa (Afrika Borwa)", false, ",.", 2, "R", [3]],
  "oc": ["oc", "Occitan", "Occitan", false, " ,", 2, "€", [3]],                                                        // 232
  "oc-fr": ["oc-FR", "Occitan (France)", "Occitan (França)", false, " ,", 2, "€", [3]],                                // 233
  "or": ["or", "Oriya", "ଓଡ଼ିଆ", false, ",.", 2, "ଟ", [3, 2]],                                                          // 234
  "or-in": ["or-IN", "Oriya (India)", "ଓଡ଼ିଆ (ଭାରତ)", false, ",.", 2, "ଟ", [3, 2]],                                     // 235
  "pa": ["pa", "Punjabi", "ਪੰਜਾਬੀ", false, ",.", 2, "ਰੁ", [3, 2]],                                                     // 236
  "pa-in": ["pa-IN", "Punjabi (India)", "ਪੰਜਾਬੀ (ਭਾਰਤ)", false, ",.", 2, "ਰੁ", [3, 2]],                                // 237
  "pl": ["pl", "Polish", "polski", false, " ,", 2, "zł", [3]],                                                         // 238
  "pl-pl": ["pl-PL", "Polish (Poland)", "polski (Polska)", false, " ,", 2, "zł", [3]],                                 // 239
  "prs": ["prs", "Dari", "درى", true, ",.", 2, "؋", [3]],                                                              // 240
  "prs-af": ["prs-AF", "Dari (Afghanistan)", "درى (افغانستان)", true, ",.", 2, "؋", [3]],                              // 241
  "ps": ["ps", "Pashto", "پښتو", true, "٬٫", 2, "؋", [3]],                                                             // 242
  "ps-af": ["ps-AF", "Pashto (Afghanistan)", "پښتو (افغانستان)", true, "٬٫", 2, "؋", [3]],                             // 243
  "pt": ["pt", "Portuguese", "Português", false, ".,", 2, "R$", [3]],                                                  // 244
  "pt-br": ["pt-BR", "Portuguese (Brazil)", "Português (Brasil)", false, ".,", 2, "R$", [3]],                          // 245
  "pt-pt": ["pt-PT", "Portuguese (Portugal)", "português (Portugal)", false, ".,", 2, "€", [3]],                       // 246
  "qut": ["qut", "K'iche", "K'iche", false, ",.", 2, "Q", [3]],                                                        // 247
  "qut-gt": ["qut-GT", "K'iche (Guatemala)", "K'iche (Guatemala)", false, ",.", 2, "Q", [3]],                          // 248
  "quz": ["quz", "Quechua", "runasimi", false, ".,", 2, "$b", [3]],                                                    // 249
  "quz-bo": ["quz-BO", "Quechua (Bolivia)", "runasimi (Qullasuyu)", false, ".,", 2, "$b", [3]],                        // 250
  "quz-ec": ["quz-EC", "Quechua (Ecuador)", "runasimi (Ecuador)", false, ".,", 2, "$", [3]],                           // 251
  "quz-pe": ["quz-PE", "Quechua (Peru)", "runasimi (Piruw)", false, ",.", 2, "S/.", [3]],                              // 252
  "rm": ["rm", "Romansh", "Rumantsch", false, "'.", 2, "fr.", [3]],                                                    // 253
  "rm-ch": ["rm-CH", "Romansh (Switzerland)", "Rumantsch (Svizra)", false, "'.", 2, "fr.", [3]],                       // 254
  "ro": ["ro", "Romanian", "română", false, ".,", 2, "lei", [3]],                                                      // 255
  "ro-ro": ["ro-RO", "Romanian (Romania)", "română (România)", false, ".,", 2, "lei", [3]],                            // 256
  "ru": ["ru", "Russian", "русский", false, " ,", 2, "р.", [3]],                                                       // 257
  "ru-ru": ["ru-RU", "Russian (Russia)", "русский (Россия)", false, " ,", 2, "р.", [3]],                               // 258
  "rw": ["rw", "Kinyarwanda", "Kinyarwanda", false, " ,", 2, "RWF", [3]],                                              // 259
  "rw-rw": ["rw-RW", "Kinyarwanda (Rwanda)", "Kinyarwanda (Rwanda)", false, " ,", 2, "RWF", [3]],                      // 260
  "sa": ["sa", "Sanskrit", "संस्कृत", false, ",.", 2, "रु", [3, 2]],                                                   // 261
  "sa-in": ["sa-IN", "Sanskrit (India)", "संस्कृत (भारतम्)", false, ",.", 2, "रु", [3, 2]],                            // 262
  "sah": ["sah", "Yakut", "саха", false, " ,", 2, "с.", [3]],                                                          // 263
  "sah-ru": ["sah-RU", "Yakut (Russia)", "саха (Россия)", false, " ,", 2, "с.", [3]],                                  // 264
  "se": ["se", "Sami (Northern)", "davvisámegiella", false, " ,", 2, "kr", [3]],                                       // 265
  "se-fi": ["se-FI", "Sami, Northern (Finland)", "davvisámegiella (Suopma)", false, " ,", 2, "€", [3]],                // 266
  "se-no": ["se-NO", "Sami, Northern (Norway)", "davvisámegiella (Norga)", false, " ,", 2, "kr", [3]],                 // 267
  "se-se": ["se-SE", "Sami, Northern (Sweden)", "davvisámegiella (Ruoŧŧa)", false, ".,", 2, "kr", [3]],                // 268
  "si": ["si", "Sinhala", "සිංහල", false, ",.", 2, "රු.", [3, 2]],                                                     // 269
  "si-lk": ["si-LK", "Sinhala (Sri Lanka)", "සිංහල (ශ්‍රී ලංකා)", false, ",.", 2, "රු.", [3, 2]],                      // 270
  "sk": ["sk", "Slovak", "slovenčina", false, " ,", 2, "€", [3]],                                                      // 271
  "sk-sk": ["sk-SK", "Slovak (Slovakia)", "slovenčina (Slovenská republika)", false, " ,", 2, "€", [3]],               // 272
  "sl": ["sl", "Slovenian", "slovenski", false, ".,", 2, "€", [3]],                                                    // 273
  "sl-si": ["sl-SI", "Slovenian (Slovenia)", "slovenski (Slovenija)", false, ".,", 2, "€", [3]],                       // 274
  "sma": ["sma", "Sami (Southern)", "åarjelsaemiengiele", false, ".,", 2, "kr", [3]],                                  // 275
  "sma-no": ["sma-NO", "Sami, Southern (Norway)", "åarjelsaemiengiele (Nöörje)", false, " ,", 2, "kr", [3]],           // 276
  "sma-se": ["sma-SE", "Sami, Southern (Sweden)", "åarjelsaemiengiele (Sveerje)", false, ".,", 2, "kr", [3]],          // 277
  "smj": ["smj", "Sami (Lule)", "julevusámegiella", false, ".,", 2, "kr", [3]],                                        // 278
  "smj-no": ["smj-NO", "Sami, Lule (Norway)", "julevusámegiella (Vuodna)", false, " ,", 2, "kr", [3]],                 // 279
  "smj-se": ["smj-SE", "Sami, Lule (Sweden)", "julevusámegiella (Svierik)", false, ".,", 2, "kr", [3]],                // 280
  "smn": ["smn", "Sami (Inari)", "sämikielâ", false, " ,", 2, "€", [3]],                                               // 281
  "smn-fi": ["smn-FI", "Sami, Inari (Finland)", "sämikielâ (Suomâ)", false, " ,", 2, "€", [3]],                        // 282
  "sms": ["sms", "Sami (Skolt)", "sääm´ǩiõll", false, " ,", 2, "€", [3]],                                              // 283
  "sms-fi": ["sms-FI", "Sami, Skolt (Finland)", "sääm´ǩiõll (Lää´ddjânnam)", false, " ,", 2, "€", [3]],                // 284
  "sq": ["sq", "Albanian", "shqipe", false, ".,", 2, "Lek", [3]],                                                      // 285
  "sq-al": ["sq-AL", "Albanian (Albania)", "shqipe (Shqipëria)", false, ".,", 2, "Lek", [3]],                          // 286
  "sr": ["sr", "Serbian", "srpski", false, ".,", 2, "Din.", [3]],                                                      // 287
  "sr-cyrl": ["sr-Cyrl", "Serbian (Cyrillic)", "српски", false, ".,", 2, "Дин.", [3]],                                 // 288
  "sr-cyrl-ba": ["sr-Cyrl-BA", "Serbian (Cyrillic, Bosnia and Herzegovina)", "српски (Босна и Херцеговина)", false, ".,", 2, "КМ", [3]],
  "sr-cyrl-cs": ["sr-Cyrl-CS", "Serbian (Cyrillic, Serbia and Montenegro (Former))", "српски (Србија и Црна Гора (Претходно))", false, ".,", 2, "Дин.", [3]],
  "sr-cyrl-me": ["sr-Cyrl-ME", "Serbian (Cyrillic, Montenegro)", "српски (Црна Гора)", false, ".,", 2, "€", [3]],      // 291
  "sr-cyrl-rs": ["sr-Cyrl-RS", "Serbian (Cyrillic, Serbia)", "српски (Србија)", false, ".,", 2, "Дин.", [3]],          // 292
  "sr-latn": ["sr-Latn", "Serbian (Latin)", "srpski", false, ".,", 2, "Din.", [3]],                                    // 293
  "sr-latn-ba": ["sr-Latn-BA", "Serbian (Latin, Bosnia and Herzegovina)", "srpski (Bosna i Hercegovina)", false, ".,", 2, "KM", [3]],
  "sr-latn-cs": ["sr-Latn-CS", "Serbian (Latin, Serbia and Montenegro (Former))", "srpski (Srbija i Crna Gora (Prethodno))", false, ".,", 2, "Din.", [3]],
  "sr-latn-me": ["sr-Latn-ME", "Serbian (Latin, Montenegro)", "srpski (Crna Gora)", false, ".,", 2, "€", [3]],         // 296
  "sr-latn-rs": ["sr-Latn-RS", "Serbian (Latin, Serbia)", "srpski (Srbija)", false, ".,", 2, "Din.", [3]],             // 297
  "sv": ["sv", "Swedish", "svenska", false, ".,", 2, "kr", [3]],                                                       // 298
  "sv-fi": ["sv-FI", "Swedish (Finland)", "svenska (Finland)", false, " ,", 2, "€", [3]],                              // 299
  "sv-se": ["sv-SE", "Swedish (Sweden)", "svenska (Sverige)", false, ".,", 2, "kr", [3]],                              // 300
  "sw": ["sw", "Kiswahili", "Kiswahili", false, ",.", 2, "S", [3]],                                                    // 301
  "sw-ke": ["sw-KE", "Kiswahili (Kenya)", "Kiswahili (Kenya)", false, ",.", 2, "S", [3]],                              // 302
  "syr": ["syr", "Syriac", "ܣܘܪܝܝܐ", true, ",.", 2, "ل.س.‏", [3]],                                                     // 303
  "syr-sy": ["syr-SY", "Syriac (Syria)", "ܣܘܪܝܝܐ (سوريا)", true, ",.", 2, "ل.س.‏", [3]],                               // 304
  "ta": ["ta", "Tamil", "தமிழ்", false, ",.", 2, "ரூ", [3, 2]],                                                        // 305
  "ta-in": ["ta-IN", "Tamil (India)", "தமிழ் (இந்தியா)", false, ",.", 2, "ரூ", [3, 2]],                                // 306
  "te": ["te", "Telugu", "తెలుగు", false, ",.", 2, "రూ", [3, 2]],                                                      // 307
  "te-in": ["te-IN", "Telugu (India)", "తెలుగు (భారత దేశం)", false, ",.", 2, "రూ", [3, 2]],                            // 308
  "tg": ["tg", "Tajik", "Тоҷикӣ", false, " ;", 2, "т.р.", [3, 0]],                                                     // 309
  "tg-cyrl": ["tg-Cyrl", "Tajik (Cyrillic)", "Тоҷикӣ", false, " ;", 2, "т.р.", [3, 0]],                                // 310
  "tg-cyrl-tj": ["tg-Cyrl-TJ", "Tajik (Cyrillic, Tajikistan)", "Тоҷикӣ (Тоҷикистон)", false, " ;", 2, "т.р.", [3, 0]],
  "th": ["th", "Thai", "ไทย", false, ",.", 2, "฿", [3]],                                                               // 312
  "th-th": ["th-TH", "Thai (Thailand)", "ไทย (ไทย)", false, ",.", 2, "฿", [3]],                                        // 313
  "tk": ["tk", "Turkmen", "türkmençe", false, " ,", 2, "m.", [3]],                                                     // 314
  "tk-tm": ["tk-TM", "Turkmen (Turkmenistan)", "türkmençe (Türkmenistan)", false, " ,", 2, "m.", [3]],                 // 315
  "tn": ["tn", "Setswana", "Setswana", false, ",.", 2, "R", [3]],                                                      // 316
  "tn-za": ["tn-ZA", "Setswana (South Africa)", "Setswana (Aforika Borwa)", false, ",.", 2, "R", [3]],                 // 317
  "tr": ["tr", "Turkish", "Türkçe", false, ".,", 2, "TL", [3]],                                                        // 318
  "tr-tr": ["tr-TR", "Turkish (Turkey)", "Türkçe (Türkiye)", false, ".,", 2, "TL", [3]],                               // 319
  "tt": ["tt", "Tatar", "Татар", false, " ,", 2, "р.", [3]],                                                           // 320
  "tt-ru": ["tt-RU", "Tatar (Russia)", "Татар (Россия)", false, " ,", 2, "р.", [3]],                                   // 321
  "tzm": ["tzm", "Tamazight", "Tamazight", false, ",.", 2, "DZD", [3]],                                                // 322
  "tzm-latn": ["tzm-Latn", "Tamazight (Latin)", "Tamazight", false, ",.", 2, "DZD", [3]],                              // 323
  "tzm-latn-dz": ["tzm-Latn-DZ", "Tamazight (Latin, Algeria)", "Tamazight (Djazaïr)", false, ",.", 2, "DZD", [3]],     // 324
  "ug": ["ug", "Uyghur", "ئۇيغۇرچە", true, ",.", 2, "¥", [3]],                                                         // 325
  "ug-cn": ["ug-CN", "Uyghur (PRC)", "ئۇيغۇرچە (جۇڭخۇا خەلق جۇمھۇرىيىتى)", true, ",.", 2, "¥", [3]],                   // 326
  "uk": ["uk", "Ukrainian", "українська", false, " ,", 2, "₴", [3]],                                                   // 327
  "uk-ua": ["uk-UA", "Ukrainian (Ukraine)", "українська (Україна)", false, " ,", 2, "₴", [3]],                         // 328
  "ur": ["ur", "Urdu", "اُردو", true, ",.", 2, "Rs", [3]],                                                             // 329
  "ur-pk": ["ur-PK", "Urdu (Islamic Republic of Pakistan)", "اُردو (پاکستان)", true, ",.", 2, "Rs", [3]],              // 330
  "uz": ["uz", "Uzbek", "U'zbek", false, " ,", 2, "so'm", [3]],                                                        // 331
  "uz-cyrl": ["uz-Cyrl", "Uzbek (Cyrillic)", "Ўзбек", false, " ,", 2, "сўм", [3]],                                     // 332
  "uz-cyrl-uz": ["uz-Cyrl-UZ", "Uzbek (Cyrillic, Uzbekistan)", "Ўзбек (Ўзбекистон)", false, " ,", 2, "сўм", [3]],      // 333
  "uz-latn": ["uz-Latn", "Uzbek (Latin)", "U'zbek", false, " ,", 2, "so'm", [3]],                                      // 334
  "uz-latn-uz": ["uz-Latn-UZ", "Uzbek (Latin, Uzbekistan)", "U'zbek (U'zbekiston Respublikasi)", false, " ,", 2, "so'm", [3]],
  "vi": ["vi", "Vietnamese", "Tiếng Việt", false, ".,", 2, "₫", [3]],                                                 // 336
  "vi-vn": ["vi-VN", "Vietnamese (Vietnam)", "Tiếng Việt (Việt Nam)", false, ".,", 2, "₫", [3]],                      // 337
  "wo": ["wo", "Wolof", "Wolof", false, " ,", 2, "XOF", [3]],                                                          // 338
  "wo-sn": ["wo-SN", "Wolof (Senegal)", "Wolof (Sénégal)", false, " ,", 2, "XOF", [3]],                                // 339
  "xh": ["xh", "isiXhosa", "isiXhosa", false, ",.", 2, "R", [3]],                                                      // 340
  "xh-za": ["xh-ZA", "isiXhosa (South Africa)", "isiXhosa (uMzantsi Afrika)", false, ",.", 2, "R", [3]],               // 341
  "yo": ["yo", "Yoruba", "Yoruba", false, ",.", 2, "N", [3]],                                                          // 342
  "yo-ng": ["yo-NG", "Yoruba (Nigeria)", "Yoruba (Nigeria)", false, ",.", 2, "N", [3]],                                // 343
  "zh": ["zh", "Chinese", "中文", false, ",.", 2, "¥", [3]],                                                             // 344
  "zh-chs": ["zh-CHS", "Chinese (Simplified) Legacy", "中文(简体) 旧版", false, ",.", 2, "¥", [3]],                          // 345
  "zh-cht": ["zh-CHT", "Chinese (Traditional) Legacy", "中文(繁體) 舊版", false, ",.", 2, "HK$", [3]],                       // 346
  "zh-cn": ["zh-CN", "Chinese (Simplified, PRC)", "中文(中华人民共和国)", false, ",.", 2, "¥", [3]],                            // 347
  "zh-hans": ["zh-Hans", "Chinese (Simplified)", "中文(简体)", false, ",.", 2, "¥", [3]],                                  // 348
  "zh-hant": ["zh-Hant", "Chinese (Traditional)", "中文(繁體)", false, ",.", 2, "HK$", [3]],                               // 349
  "zh-hk": ["zh-HK", "Chinese (Traditional, Hong Kong S.A.R.)", "中文(香港特別行政區)", false, ",.", 2, "HK$", [3]],            // 350
  "zh-mo": ["zh-MO", "Chinese (Traditional, Macao S.A.R.)", "中文(澳門特別行政區)", false, ",.", 2, "MOP", [3]],                // 351
  "zh-sg": ["zh-SG", "Chinese (Simplified, Singapore)", "中文(新加坡)", false, ",.", 2, "$", [3]],                          // 352
  "zh-tw": ["zh-TW", "Chinese (Traditional, Taiwan)", "中文(台灣)", false, ",.", 2, "NT$", [3]],                           // 353
  "zu": ["zu", "isiZulu", "isiZulu", false, ",.", 2, "R", [3]],                                                        // 354
  "zu-za": ["zu-ZA", "isiZulu (South Africa)", "isiZulu (iNingizimu Afrika)", false, ",.", 2, "R", [3]]                // 355
};                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/universe_i18n/lib/i18n.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _events = new UniUtils.Emitter();                                                                                  // 1
var i18n = {                                                                                                           // 2
    _defaultLocale: 'en-US',                                                                                           // 3
    setLocale: function (locale) {                                                                                     // 4
        locale = locale.toLowerCase();                                                                                 // 5
        locale = locale.replace('_', '-');                                                                             // 6
        if (!locales[locale]) {                                                                                        // 7
            console.error('Wrong locale:', locale, '[Should be xx-yy or xx]');                                         // 8
            return;                                                                                                    // 9
        }                                                                                                              //
        i18n._locale = locales[locale][0];                                                                             // 11
        _events.emit('changeLocale', i18n._locale);                                                                    // 12
        // Only if is active                                                                                           //
        i18n._deps && i18n._deps.changed();                                                                            // 14
    },                                                                                                                 //
    getLocale: function () {                                                                                           // 16
        return i18n._locale || i18n._defaultLocale;                                                                    // 17
    },                                                                                                                 //
    createComponent: function () {                                                                                     // 19
        var translator = arguments.length <= 0 || arguments[0] === undefined ? i18n.createTranslator() : arguments[0];
                                                                                                                       //
        if (typeof translator === 'string') {                                                                          // 20
            translator = i18n.createTranslator(translator);                                                            // 21
        }                                                                                                              //
        return React.createClass({                                                                                     // 23
            displayName: 'T',                                                                                          // 24
            propTypes: {                                                                                               // 25
                children: React.PropTypes.string                                                                       // 26
            },                                                                                                         //
            getInitialState: function () {                                                                             // 28
                return { systemlocale: '_' };                                                                          // 29
            },                                                                                                         //
            render: function () {                                                                                      // 31
                var _props = this.props;                                                                               //
                var children = _props.children;                                                                        //
                var params = babelHelpers.objectWithoutProperties(_props, ['children']);                               //
                                                                                                                       //
                return React.createElement('span', { dangerouslySetInnerHTML: {                                        // 33
                        __html: translator(children, params)                                                           // 34
                    }, key: this.state.systemlocale });                                                                //
            },                                                                                                         //
            statics: {                                                                                                 // 37
                __: function (translationStr, props) {                                                                 // 38
                    return translator(translationStr, props);                                                          // 39
                }                                                                                                      //
            },                                                                                                         //
            _invalidate: function (locale) {                                                                           // 42
                this.setState({ systemlocale: locale });                                                               // 43
            },                                                                                                         //
            componentWillMount: function () {                                                                          // 45
                _events.on('changeLocale', this._invalidate);                                                          // 46
            },                                                                                                         //
            componentWillUnmount: function () {                                                                        // 48
                _events.off('changeLocale', this._invalidate);                                                         // 49
            }                                                                                                          //
        });                                                                                                            //
    },                                                                                                                 //
                                                                                                                       //
    createTranslator: function (namespace, locale) {                                                                   // 54
        if (typeof locale === 'string' && !locale) {                                                                   // 55
            locale = undefined;                                                                                        // 56
        }                                                                                                              //
        return function () {                                                                                           // 58
            for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {                     //
                args[_key] = arguments[_key];                                                                          // 58
            }                                                                                                          //
                                                                                                                       //
            if (typeof args[args.length - 1] === 'object') {                                                           // 59
                var params = args[args.length - 1];                                                                    // 60
                params._locale = params._locale || locale;                                                             // 61
            } else if (locale) {                                                                                       //
                args.push({ _locale: locale });                                                                        // 63
            }                                                                                                          //
            return i18n.getTranslation.apply(i18n, [namespace].concat(args));                                          // 65
        };                                                                                                             //
    },                                                                                                                 //
                                                                                                                       //
    _translations: {},                                                                                                 // 69
                                                                                                                       //
    options: {                                                                                                         // 71
        open: '{$',                                                                                                    // 72
        close: '}'                                                                                                     // 73
    },                                                                                                                 //
    //For blaze and autoruns                                                                                           //
    createReactiveTranslator: function (namespace, locale) {                                                           // 76
        var translator = i18n.createTranslator(namespace, locale);                                                     // 77
        if (!i18n._deps) {                                                                                             // 78
            i18n._deps = new Tracker.Dependency();                                                                     // 79
        }                                                                                                              //
        return function () {                                                                                           // 81
            i18n._deps.depend();                                                                                       // 82
            return translator.apply(undefined, arguments);                                                             // 83
        };                                                                                                             //
    },                                                                                                                 //
    getTranslation: function () /*namespace, key, params*/{                                                            // 86
        var open = i18n.options.open;                                                                                  // 87
        var close = i18n.options.close;                                                                                // 88
        var args = [].slice.call(arguments);                                                                           // 89
        var keysArr = [];                                                                                              // 90
        args.forEach(function (prop) {                                                                                 // 91
            if (typeof prop === 'string') {                                                                            // 92
                keysArr.push(prop);                                                                                    // 93
            }                                                                                                          //
        });                                                                                                            //
        var key = keysArr.join('.');                                                                                   // 96
        var params = {};                                                                                               // 97
        if (typeof args[args.length - 1] === 'object') {                                                               // 98
            params = args[args.length - 1];                                                                            // 99
        }                                                                                                              //
        var currentLang = params._locale || i18n.getLocale();                                                          // 101
        var token = currentLang + '.' + key;                                                                           // 102
        var string = UniUtils.get(i18n._translations, token);                                                          // 103
        if (!string) {                                                                                                 // 104
            token = currentLang.replace(/-.+$/, '') + '.' + key;                                                       // 105
            string = UniUtils.get(i18n._translations, token);                                                          // 106
                                                                                                                       //
            if (!string) {                                                                                             // 108
                token = i18n._defaultLocale + '.' + key;                                                               // 109
                string = UniUtils.get(i18n._translations, token);                                                      // 110
                                                                                                                       //
                if (!string) {                                                                                         // 112
                    token = i18n._defaultLocale.replace(/-.+$/, '') + '.' + key;                                       // 113
                    string = UniUtils.get(i18n._translations, token, key);                                             // 114
                }                                                                                                      //
            }                                                                                                          //
        }                                                                                                              //
                                                                                                                       //
        Object.keys(params).forEach(function (param) {                                                                 // 119
            string = string.replace(open + param + close, params[param]);                                              // 120
        });                                                                                                            //
                                                                                                                       //
        return string;                                                                                                 // 123
    },                                                                                                                 //
                                                                                                                       //
    getTranslations: function (namespace) {                                                                            // 126
        var locale = arguments.length <= 1 || arguments[1] === undefined ? i18n.getLocale() : arguments[1];            //
                                                                                                                       //
        if (locale) {                                                                                                  // 127
            namespace = locale + '.' + namespace;                                                                      // 128
        }                                                                                                              //
        return UniUtils.get(i18n._translations, namespace, {});                                                        // 130
    },                                                                                                                 //
    addTranslation: function () /*locale, namespace, key, translation*/{                                               // 132
        var args = [].slice.call(arguments);                                                                           // 133
        var translation = args.pop();                                                                                  // 134
        var namespace = args.join('.');                                                                                // 135
        namespace = namespace.replace(/\.\.|\.$/, '');                                                                 // 136
        //backwards compatibility                                                                                      //
        var firstDot = namespace.indexOf('.');                                                                         // 138
        var lang = namespace.slice(0, firstDot);                                                                       // 139
        lang = lang.toLowerCase().replace('_', '-');                                                                   // 140
        if (locales[lang]) {                                                                                           // 141
            lang = locales[lang][0];                                                                                   // 142
            namespace = lang + namespace.slice(firstDot);                                                              // 143
        }                                                                                                              //
        translation = UniUtils.deepExtend(UniUtils.get(i18n._translations, namespace) || {}, translation);             // 145
        UniUtils.set(i18n._translations, namespace, translation);                                                      // 146
    },                                                                                                                 //
    /**                                                                                                                //
     * parseNumber('7013217.715'); // 7,013,217.715                                                                    //
     * parseNumber('16217 and 17217,715'); // 16,217 and 17,217.715                                                    //
     * parseNumber('7013217.715', 'ru-ru'); // 7 013 217,715                                                           //
     */                                                                                                                //
    parseNumber: function (number) {                                                                                   // 153
        var locale = arguments.length <= 1 || arguments[1] === undefined ? i18n.getLocale() : arguments[1];            //
                                                                                                                       //
        number = '' + number;                                                                                          // 154
        var sep = locales[locale];                                                                                     // 155
        if (!sep) return number;                                                                                       // 156
        sep = sep[4];                                                                                                  // 157
        return number.replace(/(\d+)[\.,]*(\d*)/gim, function (match, num, dec) {                                      // 158
            return format(+num, sep.charAt(0)) + (dec ? sep.charAt(1) + dec : '');                                     // 159
        }) || '0';                                                                                                     //
    },                                                                                                                 //
    _locales: locales,                                                                                                 // 162
    getCurrencySymbol: function () {                                                                                   // 163
        var locale = arguments.length <= 0 || arguments[0] === undefined ? i18n.getLocale() : arguments[0];            //
                                                                                                                       //
        locale = locale.toLowerCase().replace('_', '-');                                                               // 164
        return locales[locale] && locales[locale][6];                                                                  // 165
    },                                                                                                                 //
    getLanguageName: function () {                                                                                     // 167
        var locale = arguments.length <= 0 || arguments[0] === undefined ? i18n.getLocale() : arguments[0];            //
                                                                                                                       //
        locale = locale.toLowerCase().replace('_', '-');                                                               // 168
        return locales[locale] && locales[locale][1];                                                                  // 169
    },                                                                                                                 //
    getLanguageNativeName: function () {                                                                               // 171
        var locale = arguments.length <= 0 || arguments[0] === undefined ? i18n.getLocale() : arguments[0];            //
                                                                                                                       //
        locale = locale.toLowerCase().replace('_', '-');                                                               // 172
        return locales[locale] && locales[locale][2];                                                                  // 173
    },                                                                                                                 //
    isRTL: function () {                                                                                               // 175
        var locale = arguments.length <= 0 || arguments[0] === undefined ? i18n.getLocale() : arguments[0];            //
                                                                                                                       //
        locale = locale.toLowerCase().replace('_', '-');                                                               // 176
        return locales[locale] && locales[locale][3];                                                                  // 177
    },                                                                                                                 //
    onChangeLocale: function (fn) {                                                                                    // 179
        if (typeof fn !== 'function') {                                                                                // 180
            return console.error('Handler must be function');                                                          // 181
        }                                                                                                              //
        _events.on('changeLocale', fn);                                                                                // 183
    },                                                                                                                 //
    onceChangeLocale: function (fn) {                                                                                  // 185
        if (typeof fn !== 'function') {                                                                                // 186
            return console.error('Handler must be function');                                                          // 187
        }                                                                                                              //
        _events.once('changeLocale', fn);                                                                              // 189
    },                                                                                                                 //
    offChangeLocale: function (fn) {                                                                                   // 191
        _events.off('changeLocale', fn);                                                                               // 192
    }                                                                                                                  //
};                                                                                                                     //
i18n.__ = i18n.getTranslation;                                                                                         // 195
i18n.addTranslations = i18n.addTranslation;                                                                            // 196
                                                                                                                       //
function format(int, sep) {                                                                                            // 198
    var str = '';                                                                                                      // 199
    var n;                                                                                                             // 200
                                                                                                                       //
    while (int) {                                                                                                      // 202
        n = int % 1e3;                                                                                                 // 203
        int = parseInt(int / 1e3);                                                                                     // 204
        if (int === 0) return n + str;                                                                                 // 205
        str = sep + (n < 10 ? '00' : n < 100 ? '0' : '') + n + str;                                                    // 206
    }                                                                                                                  //
}                                                                                                                      //
//Exports                                                                                                              //
if (typeof System !== 'undefined') {                                                                                   // 210
    System.set(System.normalizeSync('{universe:i18n}'), System.newModule({ i18n: i18n, 'default': i18n }));            // 211
}                                                                                                                      //
_i18n = i18n;                                                                                                          // 213
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['universe:i18n'] = {
  _i18n: _i18n
};

})();

//# sourceMappingURL=universe_i18n.js.map
