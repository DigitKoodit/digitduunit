(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;
var LocalCollection = Package.minimongo.LocalCollection;
var Minimongo = Package.minimongo.Minimongo;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;

/* Package-scope variables */
var UniUtils, UniConfig;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/universe_utilities/UniUtils.js                                                              //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
'use strict';                                                                                           // 1
                                                                                                        // 2
/* global UniUtils: true */                                                                             // 3
                                                                                                        // 4
UniUtils = {                                                                                            // 5
    /**                                                                                                 // 6
     * Creates an empty object inside namespace if not existent.                                        // 7
     * @param object                                                                                    // 8
     * @param {String} key                                                                              // 9
     * @param {*} value in key. default is object if no matches in key                                  // 10
     * @example var obj = {};                                                                           // 11
     * set(obj, 'foo.bar'); // {}                                                                       // 12
     * console.log(obj);  // {foo:{bar:{}}}                                                             // 13
     * @returns {*} it'll return created object or existing object.                                     // 14
     */                                                                                                 // 15
    set: function set (object, key, value) {                                                            // 16
        if (typeof key !== 'string') {                                                                  // 17
            console.warn('Key must be string.');                                                        // 18
            return object;                                                                              // 19
        }                                                                                               // 20
                                                                                                        // 21
        var keys = key.split('.');                                                                      // 22
        var copy = object;                                                                              // 23
                                                                                                        // 24
        while (key = keys.shift()) {                                                                    // 25
            if (copy[key] === undefined) {                                                              // 26
                if (+keys[0] === +keys[0]) {                                                            // 27
                    copy[key] = [];                                                                     // 28
                } else {                                                                                // 29
                    copy[key] = {};                                                                     // 30
                }                                                                                       // 31
            }                                                                                           // 32
                                                                                                        // 33
            if (value !== undefined && keys.length === 0) {                                             // 34
                copy[key] = value;                                                                      // 35
            }                                                                                           // 36
                                                                                                        // 37
            copy = copy[key];                                                                           // 38
        }                                                                                               // 39
                                                                                                        // 40
        return object;                                                                                  // 41
    },                                                                                                  // 42
                                                                                                        // 43
    /**                                                                                                 // 44
     * Returns nested property value.                                                                   // 45
     * @param obj                                                                                       // 46
     * @param key                                                                                       // 47
     * @param defaultValue {*=undefined}                                                                // 48
     * @example var obj = {                                                                             // 49
        foo : {                                                                                         // 50
            bar : 11                                                                                    // 51
        }                                                                                               // 52
    };                                                                                                  // 53
                                                                                                        // 54
     get(obj, 'foo.bar'); // "11"                                                                       // 55
     get(obj, 'ipsum.dolorem.sit');  // undefined                                                       // 56
     * @returns {*} found property or undefined if property doesn't exist.                              // 57
     */                                                                                                 // 58
    get: function get (object, key, defaultValue) {                                                     // 59
        if (typeof object !== 'object' || object === null) {                                            // 60
            return defaultValue;                                                                        // 61
        }                                                                                               // 62
                                                                                                        // 63
        if (typeof key !== 'string') {                                                                  // 64
            throw new Error('Key must be string.');                                                     // 65
        }                                                                                               // 66
                                                                                                        // 67
        var keys = key.split('.');                                                                      // 68
        var last = keys.pop();                                                                          // 69
                                                                                                        // 70
        while (key = keys.shift()) {                                                                    // 71
            object = object[key];                                                                       // 72
                                                                                                        // 73
            if (typeof object !== 'object' || object === null) {                                        // 74
                return defaultValue;                                                                    // 75
            }                                                                                           // 76
        }                                                                                               // 77
                                                                                                        // 78
        return object && object[last] !== undefined ? object[last] : defaultValue;                      // 79
    },                                                                                                  // 80
                                                                                                        // 81
    /**                                                                                                 // 82
     * Checks if object contains a child property.                                                      // 83
     * Useful for cases where you need to check if an object contain a nested property.                 // 84
     * @param obj                                                                                       // 85
     * @param prop                                                                                      // 86
     * @returns {boolean}                                                                               // 87
     */                                                                                                 // 88
    has: function has (obj, prop, hasOwnProperty) {                                                     // 89
        if (!_.isString(prop)) {                                                                        // 90
            throw new Error('Parameter prop must be type of String');                                   // 91
        }                                                                                               // 92
        var parts = prop.split('.');                                                                    // 93
                                                                                                        // 94
        if (_.isArray(parts)) {                                                                         // 95
            var last = parts.pop();                                                                     // 96
            while (prop = parts.shift()) {                                                              // 97
                obj = obj[prop];                                                                        // 98
                if (typeof obj !== 'object' || obj === null) {                                          // 99
                    return false;                                                                       // 100
                }                                                                                       // 101
            }                                                                                           // 102
            if (hasOwnProperty) {                                                                       // 103
                return _.has(obj, last);                                                                // 104
            }                                                                                           // 105
            return !!(obj && obj[last]);                                                                // 106
        } else {                                                                                        // 107
            if (hasOwnProperty) {                                                                       // 108
                return _.has(obj, prop);                                                                // 109
            }                                                                                           // 110
            return !!(obj && obj[prop]);                                                                // 111
        }                                                                                               // 112
    },                                                                                                  // 113
                                                                                                        // 114
                                                                                                        // 115
    /**                                                                                                 // 116
     * Search key in object or array                                                                    // 117
     * @param obj or array                                                                              // 118
     * @param search predicate function or value                                                        // 119
     * @param context                                                                                   // 120
     */                                                                                                 // 121
    findKey: function findKey (obj, search, context) {                                                  // 122
        var result,                                                                                     // 123
            isFunction = _.isFunction(search);                                                          // 124
                                                                                                        // 125
        _.any(obj, function (value, key) {                                                              // 126
            var match = isFunction ? search.call(context, value, key, obj) : (value === search);        // 127
            if (match) {                                                                                // 128
                result = key;                                                                           // 129
                return true;                                                                            // 130
            }                                                                                           // 131
        });                                                                                             // 132
        return result;                                                                                  // 133
    },                                                                                                  // 134
    getIdIfDocument: function getIdIfDocument (docId) {                                                 // 135
        if (_.isObject(docId)) {                                                                        // 136
            return docId._id;                                                                           // 137
        }                                                                                               // 138
        return docId;                                                                                   // 139
    },                                                                                                  // 140
    /**                                                                                                 // 141
     * @deprecated getUniUserObject is deprecated, please use ensureUniUser instead                     // 142
     */                                                                                                 // 143
    getUniUserObject: function getUniUserObject (user, withoutLoggedIn) {                               // 144
        if (!withoutLoggedIn) {                                                                         // 145
            return UniUsers.ensureUniUser(user, Match.Any);                                             // 146
        }                                                                                               // 147
        return UniUsers.ensureUniUser(user || null, Match.Any);                                         // 148
    },                                                                                                  // 149
    /**                                                                                                 // 150
     * Compares documents and returns diff                                                              // 151
     * @param doc1 document will be compared against to document in doc2 parameter.                     // 152
     * @param doc2 against to.                                                                          // 153
     * @returns {{}}                                                                                    // 154
     */                                                                                                 // 155
    docDiff: function docDiff (doc1, doc2) {                                                            // 156
        var diff = {};                                                                                  // 157
        for (var k1 in doc1) {                                                                          // 158
            if (!EJSON.equals(doc1[k1], doc2[k1])) {                                                    // 159
                diff[k1] = doc2[k1];                                                                    // 160
            }                                                                                           // 161
        }                                                                                               // 162
        for (var k2 in doc2) {                                                                          // 163
            if (!doc1[k2]) {                                                                            // 164
                diff[k2] = doc2[k2];                                                                    // 165
            }                                                                                           // 166
        }                                                                                               // 167
        return diff;                                                                                    // 168
    },                                                                                                  // 169
                                                                                                        // 170
    /**                                                                                                 // 171
     * Formatting currency                                                                              // 172
     * @param number{number}                                                                            // 173
     * @param sections{string}                                                                          // 174
     * @param decimals{string}                                                                          // 175
     * @returns {string}                                                                                // 176
     */                                                                                                 // 177
    formatCurrency: function formatCurrency (number, sections, decimals) {                              // 178
        var numberFormatMap = {                                                                         // 179
            'a': '\'',                                                                                  // 180
            'c': ',',                                                                                   // 181
            'd': '.',                                                                                   // 182
            's': ' '                                                                                    // 183
        };                                                                                              // 184
                                                                                                        // 185
        decimals = numberFormatMap[decimals] ? numberFormatMap[decimals] : decimals;                    // 186
        sections = numberFormatMap[sections] ? numberFormatMap[sections] : sections;                    // 187
                                                                                                        // 188
        return number.toFixed(2).replace('.', decimals).replace(/./g, function (digit, index, digits) {
            if (index && digit !== decimals && ((digits.length - index) % 3 === 0)) {                   // 190
                return sections + digit;                                                                // 191
            }                                                                                           // 192
                                                                                                        // 193
            return digit;                                                                               // 194
        });                                                                                             // 195
    },                                                                                                  // 196
    /**                                                                                                 // 197
     * Gets array of top-level fields, which will be changed by modifier (this from update method)      // 198
     * @param updateModifier modifier from update method                                                // 199
     * @returns {Array} list of top-level from doc                                                      // 200
     */                                                                                                 // 201
    getFieldsFromUpdateModifier: function getFieldsFromUpdateModifier (updateModifier) {                // 202
        var fields = [];                                                                                // 203
        Object.keys(updateModifier).forEach(function (op) {                                             // 204
            if (ALLOWED_UPDATE_OPERATIONS[op] === 1) {                                                  // 205
                Object.keys(updateModifier[op]).forEach(function (field) {                              // 206
                    if (field.indexOf('.') !== -1) {                                                    // 207
                        field = field.substring(0, field.indexOf('.'));                                 // 208
                    }                                                                                   // 209
                    if (!_.contains(fields, field)) {                                                   // 210
                        fields.push(field);                                                             // 211
                    }                                                                                   // 212
                });                                                                                     // 213
            } else {                                                                                    // 214
                fields.push(op);                                                                        // 215
            }                                                                                           // 216
        });                                                                                             // 217
        return fields;                                                                                  // 218
    },                                                                                                  // 219
    /**                                                                                                 // 220
     * Gets simulation of new version of document passed as a second argument                           // 221
     * @param updateModifier modifier from update method                                                // 222
     * @param oldDoc default empty object                                                               // 223
     * @returns {*}                                                                                     // 224
     */                                                                                                 // 225
    getPreviewOfDocumentAfterUpdate: function (updateModifier, oldDoc) {                                // 226
        oldDoc = oldDoc || {};                                                                          // 227
        var id = tmpCollection.insert(oldDoc);                                                          // 228
        tmpCollection.update(id, updateModifier);                                                       // 229
        var newDoc = tmpCollection.findOne(id);                                                         // 230
        if (id !== oldDoc._id) {                                                                        // 231
            delete newDoc._id;                                                                          // 232
        }                                                                                               // 233
        tmpCollection.remove(id);                                                                       // 234
        return newDoc;                                                                                  // 235
    }                                                                                                   // 236
};                                                                                                      // 237
                                                                                                        // 238
// piece of code from: meteor/packages/mongo/collection.js                                              // 239
var ALLOWED_UPDATE_OPERATIONS = {                                                                       // 240
    $inc: 1, $set: 1, $unset: 1, $addToSet: 1, $pop: 1, $pullAll: 1, $pull: 1,                          // 241
    $pushAll: 1, $push: 1, $bit: 1                                                                      // 242
};                                                                                                      // 243
                                                                                                        // 244
var tmpCollection = new LocalCollection(null);                                                          // 245
                                                                                                        // 246
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/universe_utilities/object-assign.js                                                         //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
var hasOwnProperty = Object.prototype.hasOwnProperty;                                                   // 1
var propIsEnumerable = Object.prototype.propertyIsEnumerable;                                           // 2
                                                                                                        // 3
function toObject(val) {                                                                                // 4
    if (val === null || val === undefined) {                                                            // 5
        throw new TypeError('Object.assign cannot be called with null or undefined');                   // 6
    }                                                                                                   // 7
                                                                                                        // 8
    return Object(val);                                                                                 // 9
}                                                                                                       // 10
                                                                                                        // 11
UniUtils.assign = Object.assign || function (target, source) {                                          // 12
    var from;                                                                                           // 13
    var to = toObject(target);                                                                          // 14
    var symbols;                                                                                        // 15
                                                                                                        // 16
    for (var s = 1; s < arguments.length; s++) {                                                        // 17
        from = Object(arguments[s]);                                                                    // 18
                                                                                                        // 19
        for (var key in from) {                                                                         // 20
            if (hasOwnProperty.call(from, key)) {                                                       // 21
                to[key] = from[key];                                                                    // 22
            }                                                                                           // 23
        }                                                                                               // 24
                                                                                                        // 25
        if (Object.getOwnPropertySymbols) {                                                             // 26
            symbols = Object.getOwnPropertySymbols(from);                                               // 27
            for (var i = 0; i < symbols.length; i++) {                                                  // 28
                if (propIsEnumerable.call(from, symbols[i])) {                                          // 29
                    to[symbols[i]] = from[symbols[i]];                                                  // 30
                }                                                                                       // 31
            }                                                                                           // 32
        }                                                                                               // 33
    }                                                                                                   // 34
                                                                                                        // 35
    return to;                                                                                          // 36
};                                                                                                      // 37
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/universe_utilities/deep-extend.js                                                           //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
/*!                                                                                                     // 1
 * @description Recursive object extending                                                              // 2
 * @author Viacheslav Lotsmanov <lotsmanov89@gmail.com>                                                 // 3
 * @license MIT                                                                                         // 4
 *                                                                                                      // 5
 * The MIT License (MIT)                                                                                // 6
 *                                                                                                      // 7
 * Copyright (c) 2013-2015 Viacheslav Lotsmanov                                                         // 8
 *                                                                                                      // 9
 * Permission is hereby granted, free of charge, to any person obtaining a copy of                      // 10
 * this software and associated documentation files (the "Software"), to deal in                        // 11
 * the Software without restriction, including without limitation the rights to                         // 12
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of                     // 13
 * the Software, and to permit persons to whom the Software is furnished to do so,                      // 14
 * subject to the following conditions:                                                                 // 15
 *                                                                                                      // 16
 * The above copyright notice and this permission notice shall be included in all                       // 17
 * copies or substantial portions of the Software.                                                      // 18
 *                                                                                                      // 19
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR                           // 20
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS                     // 21
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR                       // 22
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER                       // 23
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN                              // 24
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.                           // 25
 */                                                                                                     // 26
                                                                                                        // 27
var isBuffer = typeof Buffer !== 'undefined';                                                           // 28
                                                                                                        // 29
function isSpecificValue(val) {                                                                         // 30
    return !!(                                                                                          // 31
        (isBuffer && val instanceof Buffer)                                                             // 32
        || val instanceof Date                                                                          // 33
        || val instanceof RegExp                                                                        // 34
    );                                                                                                  // 35
}                                                                                                       // 36
                                                                                                        // 37
function cloneSpecificValue(val) {                                                                      // 38
    if (isBuffer && val instanceof Buffer) {                                                            // 39
        var x = new Buffer(val.length);                                                                 // 40
        val.copy(x);                                                                                    // 41
        return x;                                                                                       // 42
    } else if (val instanceof Date) {                                                                   // 43
        return new Date(val.getTime());                                                                 // 44
    } else if (val instanceof RegExp) {                                                                 // 45
        return new RegExp(val);                                                                         // 46
    } else {                                                                                            // 47
        throw new Error('Unexpected situation');                                                        // 48
    }                                                                                                   // 49
}                                                                                                       // 50
                                                                                                        // 51
/**                                                                                                     // 52
 * Recursive cloning array.                                                                             // 53
 */                                                                                                     // 54
function deepCloneArray(arr) {                                                                          // 55
    var clone = [];                                                                                     // 56
    arr.forEach(function (item, index) {                                                                // 57
        if (typeof item === 'object' && item !== null) {                                                // 58
            if (Array.isArray(item)) {                                                                  // 59
                clone[index] = deepCloneArray(item);                                                    // 60
            } else if (isSpecificValue(item)) {                                                         // 61
                clone[index] = cloneSpecificValue(item);                                                // 62
            } else {                                                                                    // 63
                clone[index] = deepExtend({}, item);                                                    // 64
            }                                                                                           // 65
        } else {                                                                                        // 66
            clone[index] = item;                                                                        // 67
        }                                                                                               // 68
    });                                                                                                 // 69
    return clone;                                                                                       // 70
}                                                                                                       // 71
                                                                                                        // 72
/**                                                                                                     // 73
 * Extening object that entered in first argument.                                                      // 74
 *                                                                                                      // 75
 * Returns extended object or false if have no target object or incorrect type.                         // 76
 *                                                                                                      // 77
 * If you wish to clone source object (without modify it), just use empty new                           // 78
 * object as first argument, like this:                                                                 // 79
 *   deepExtend({}, yourObj_1, [yourObj_N]);                                                            // 80
 */                                                                                                     // 81
function deepExtend (/*obj_1, [obj_2], [obj_N]*/) {                                                     // 82
    if (arguments.length < 1 || typeof arguments[0] !== 'object') {                                     // 83
        return false;                                                                                   // 84
    }                                                                                                   // 85
                                                                                                        // 86
    if (arguments.length < 2) {                                                                         // 87
        return arguments[0];                                                                            // 88
    }                                                                                                   // 89
                                                                                                        // 90
    var target = arguments[0];                                                                          // 91
                                                                                                        // 92
    // convert arguments to array and cut off target object                                             // 93
    var args = Array.prototype.slice.call(arguments, 1);                                                // 94
                                                                                                        // 95
    var val, src, clone;                                                                                // 96
                                                                                                        // 97
    args.forEach(function (obj) {                                                                       // 98
        // skip argument if it is array or isn't object                                                 // 99
        if (typeof obj !== 'object' || Array.isArray(obj)) {                                            // 100
            return;                                                                                     // 101
        }                                                                                               // 102
                                                                                                        // 103
        Object.keys(obj).forEach(function (key) {                                                       // 104
            src = target[key]; // source value                                                          // 105
            val = obj[key]; // new value                                                                // 106
                                                                                                        // 107
            // recursion prevention                                                                     // 108
            if (val === target) {                                                                       // 109
                return;                                                                                 // 110
                                                                                                        // 111
                /**                                                                                     // 112
                 * if new value isn't object then just overwrite by new value                           // 113
                 * instead of extending.                                                                // 114
                 */                                                                                     // 115
            } else if (typeof val !== 'object' || val === null) {                                       // 116
                target[key] = val;                                                                      // 117
                return;                                                                                 // 118
                                                                                                        // 119
                // just clone arrays (and recursive clone objects inside)                               // 120
            } else if (Array.isArray(val)) {                                                            // 121
                target[key] = deepCloneArray(val);                                                      // 122
                return;                                                                                 // 123
                                                                                                        // 124
                // custom cloning and overwrite for specific objects                                    // 125
            } else if (isSpecificValue(val)) {                                                          // 126
                target[key] = cloneSpecificValue(val);                                                  // 127
                return;                                                                                 // 128
                                                                                                        // 129
                // overwrite by new value if source isn't object or array                               // 130
            } else if (typeof src !== 'object' || src === null || Array.isArray(src)) {                 // 131
                target[key] = deepExtend({}, val);                                                      // 132
                return;                                                                                 // 133
                                                                                                        // 134
                // source value and new value is objects both, extending...                             // 135
            } else {                                                                                    // 136
                target[key] = deepExtend(src, val);                                                     // 137
                return;                                                                                 // 138
            }                                                                                           // 139
        });                                                                                             // 140
    });                                                                                                 // 141
                                                                                                        // 142
    return target;                                                                                      // 143
}                                                                                                       // 144
                                                                                                        // 145
UniUtils.deepExtend = deepExtend;                                                                       // 146
                                                                                                        // 147
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/universe_utilities/deep-equal.js                                                            //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
var pSlice = Array.prototype.slice;                                                                     // 1
var objectKeys = Object.keys;                                                                           // 2
                                                                                                        // 3
function isArguments (object) {                                                                         // 4
    return Object.prototype.toString.call(object) == '[object Arguments]';                              // 5
}                                                                                                       // 6
                                                                                                        // 7
var deepEqual = function (actual, expected, opts) {                                                     // 8
    if (!opts) opts = {};                                                                               // 9
    // 7.1. All identical values are equivalent, as determined by ===.                                  // 10
    if (actual === expected) {                                                                          // 11
        return true;                                                                                    // 12
                                                                                                        // 13
    } else if (actual instanceof Date && expected instanceof Date) {                                    // 14
        return actual.getTime() === expected.getTime();                                                 // 15
                                                                                                        // 16
        // 7.3. Other pairs that do not both pass typeof value == 'object',                             // 17
        // equivalence is determined by ==.                                                             // 18
    } else if (typeof actual != 'object' && typeof expected != 'object') {                              // 19
        return opts.strict ? actual === expected : actual == expected;                                  // 20
                                                                                                        // 21
        // 7.4. For all other Object pairs, including Array objects, equivalence is                     // 22
        // determined by having the same number of owned properties (as verified                        // 23
        // with Object.prototype.hasOwnProperty.call), the same set of keys                             // 24
        // (although not necessarily the same order), equivalent values for every                       // 25
        // corresponding key, and an identical 'prototype' property. Note: this                         // 26
        // accounts for both named and indexed properties on Arrays.                                    // 27
    } else {                                                                                            // 28
        return objEquiv(actual, expected, opts);                                                        // 29
    }                                                                                                   // 30
};                                                                                                      // 31
                                                                                                        // 32
function isUndefinedOrNull (value) {                                                                    // 33
    return value === null || value === undefined;                                                       // 34
}                                                                                                       // 35
                                                                                                        // 36
function isBuffer (x) {                                                                                 // 37
    if (!x || typeof x !== 'object' || typeof x.length !== 'number') return false;                      // 38
    if (typeof x.copy !== 'function' || typeof x.slice !== 'function') {                                // 39
        return false;                                                                                   // 40
    }                                                                                                   // 41
    if (x.length > 0 && typeof x[0] !== 'number') return false;                                         // 42
    return true;                                                                                        // 43
}                                                                                                       // 44
                                                                                                        // 45
function objEquiv (a, b, opts) {                                                                        // 46
    var i, key;                                                                                         // 47
    if (isUndefinedOrNull(a) || isUndefinedOrNull(b))                                                   // 48
        return false;                                                                                   // 49
    // an identical 'prototype' property.                                                               // 50
    if (a.prototype !== b.prototype) return false;                                                      // 51
    //~~~I've managed to break Object.keys through screwy arguments passing.                            // 52
    //   Converting to array solves the problem.                                                        // 53
    if (isArguments(a)) {                                                                               // 54
        if (!isArguments(b)) {                                                                          // 55
            return false;                                                                               // 56
        }                                                                                               // 57
        a = pSlice.call(a);                                                                             // 58
        b = pSlice.call(b);                                                                             // 59
        return deepEqual(a, b, opts);                                                                   // 60
    }                                                                                                   // 61
    if (isBuffer(a)) {                                                                                  // 62
        if (!isBuffer(b)) {                                                                             // 63
            return false;                                                                               // 64
        }                                                                                               // 65
        if (a.length !== b.length) return false;                                                        // 66
        for (i = 0; i < a.length; i++) {                                                                // 67
            if (a[i] !== b[i]) return false;                                                            // 68
        }                                                                                               // 69
        return true;                                                                                    // 70
    }                                                                                                   // 71
    try {                                                                                               // 72
        var ka = objectKeys(a),                                                                         // 73
            kb = objectKeys(b);                                                                         // 74
    } catch (e) {//happens when one is a string literal and the other isn't                             // 75
        return false;                                                                                   // 76
    }                                                                                                   // 77
    // having the same number of owned properties (keys incorporates                                    // 78
    // hasOwnProperty)                                                                                  // 79
    if (ka.length != kb.length)                                                                         // 80
        return false;                                                                                   // 81
    //the same set of keys (although not necessarily the same order),                                   // 82
    ka.sort();                                                                                          // 83
    kb.sort();                                                                                          // 84
    //~~~cheap key test                                                                                 // 85
    for (i = ka.length - 1; i >= 0; i--) {                                                              // 86
        if (ka[i] != kb[i])                                                                             // 87
            return false;                                                                               // 88
    }                                                                                                   // 89
    //equivalent values for every corresponding key, and                                                // 90
    //~~~possibly expensive deep test                                                                   // 91
    for (i = ka.length - 1; i >= 0; i--) {                                                              // 92
        key = ka[i];                                                                                    // 93
        if (!deepEqual(a[key], b[key], opts)) return false;                                             // 94
    }                                                                                                   // 95
    return typeof a === typeof b;                                                                       // 96
}                                                                                                       // 97
                                                                                                        // 98
                                                                                                        // 99
UniUtils.deepEqual = deepEqual;                                                                         // 100
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/universe_utilities/UniUtilsStrings.js                                                       //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
'use strict';                                                                                           // 1
                                                                                                        // 2
                                                                                                        // 3
/**                                                                                                     // 4
 * Capitalize a string                                                                                  // 5
 * @alias Vazco.capitalize                                                                              // 6
 * @param {string} string String to capitalize                                                          // 7
 * @returns {string}                                                                                    // 8
 */                                                                                                     // 9
UniUtils.capitalize = function (string) {                                                               // 10
    return string.charAt(0).toUpperCase() + string.substring(1).toLowerCase();                          // 11
};                                                                                                      // 12
                                                                                                        // 13
                                                                                                        // 14
/**                                                                                                     // 15
 * Capitalize a first letter                                                                            // 16
 * @alias Vazco.capitalizeFirst                                                                         // 17
 * @param {string} string String to capitalize first letter                                             // 18
 * @returns {string}                                                                                    // 19
 */                                                                                                     // 20
UniUtils.capitalizeFirst = function (string) {                                                          // 21
    return string.charAt(0).toUpperCase() + string.slice(1);                                            // 22
};                                                                                                      // 23
                                                                                                        // 24
/**                                                                                                     // 25
 * Transform string into insensitive Regexp without flag i                                              // 26
 * This can help you with searching in minimongo                                                        // 27
 * @param term {String}                                                                                 // 28
 * @returns {RegExp}                                                                                    // 29
 */                                                                                                     // 30
UniUtils.getInSensitiveRegExpForTerm = function(term){                                                  // 31
    check(term, String);                                                                                // 32
    term = _.map(term, function (v) {                                                                   // 33
        var n = v.toLowerCase();                                                                        // 34
        n += v.toUpperCase();                                                                           // 35
        return '[' + n + ']';                                                                           // 36
    });                                                                                                 // 37
    term = term.join('');                                                                               // 38
    return new RegExp(term);                                                                            // 39
};                                                                                                      // 40
                                                                                                        // 41
                                                                                                        // 42
/**                                                                                                     // 43
 * Generates random string hash                                                                         // 44
 * @alias Vazco.randomString                                                                            // 45
 * @param {number} length length of generated hash @default 5                                           // 46
 * @param {number} base @default 36                                                                     // 47
 * @returns {string}                                                                                    // 48
 */                                                                                                     // 49
UniUtils.randomString = function (length, base) {                                                       // 50
    return (Math.random() + 1).toString(base || 36).substr(2, length || 5);                             // 51
};                                                                                                      // 52
                                                                                                        // 53
                                                                                                        // 54
/**                                                                                                     // 55
 * camelCase a string                                                                                   // 56
 * @alias Vazco.camelCase                                                                               // 57
 * @param {string} string String to camelCase                                                           // 58
 * @returns {string}                                                                                    // 59
 */                                                                                                     // 60
UniUtils.camelCase = function (string) {                                                                // 61
    return string.toLowerCase().replace(/ (.)/g, function(match, group1) {                              // 62
        return group1.toUpperCase();                                                                    // 63
    });                                                                                                 // 64
};                                                                                                      // 65
                                                                                                        // 66
                                                                                                        // 67
/**                                                                                                     // 68
 * remove international special characters - replaceSpecialChars a string                               // 69
 * @alias Vazco.replaceSpecialChars                                                                     // 70
 * @param {string} string String                                                                        // 71
 * @returns {string}                                                                                    // 72
 */                                                                                                     // 73
UniUtils.replaceSpecialChars =function (string) {                                                       // 74
    var _specialChars = {                                                                               // 75
        'á': 'a',                                                                                       // 76
        'Á': 'A',                                                                                       // 77
        'é': 'e',                                                                                       // 78
        'É': 'E',                                                                                       // 79
        'í': 'i',                                                                                       // 80
        'Í': 'I',                                                                                       // 81
        'ö': 'o',                                                                                       // 82
        'Ö': 'O',                                                                                       // 83
        'ő': 'o',                                                                                       // 84
        'Ő': 'O',                                                                                       // 85
        'ó': 'o',                                                                                       // 86
        'Ó': 'O',                                                                                       // 87
        'ü': 'u',                                                                                       // 88
        'Ü': 'U',                                                                                       // 89
        'ű': 'u',                                                                                       // 90
        'Ű': 'U',                                                                                       // 91
        'ú': 'u',                                                                                       // 92
        'Ú': 'U',                                                                                       // 93
                                                                                                        // 94
        'à':'a',                                                                                        // 95
        'è':'e',                                                                                        // 96
        'ì':'i',                                                                                        // 97
                                                                                                        // 98
        'ò':'o',                                                                                        // 99
        'ù':'u',                                                                                        // 100
        'À':'A',                                                                                        // 101
        'È':'E',                                                                                        // 102
        'Ì':'I',                                                                                        // 103
                                                                                                        // 104
        'Ò':'O',                                                                                        // 105
        'Ù':'U',                                                                                        // 106
        'â':'a',                                                                                        // 107
        'ê':'e',                                                                                        // 108
        'î':'i',                                                                                        // 109
        'ô':'o',                                                                                        // 110
        'û':'u',                                                                                        // 111
                                                                                                        // 112
        'Â':'A',                                                                                        // 113
        'Ê':'E',                                                                                        // 114
        'Î':'I',                                                                                        // 115
        'Ô':'O',                                                                                        // 116
        'Û':'U',                                                                                        // 117
                                                                                                        // 118
        'ã':'a',                                                                                        // 119
        'ñ':'n',                                                                                        // 120
        'õ':'o',                                                                                        // 121
        'Ã':'A',                                                                                        // 122
        'Ñ':'N',                                                                                        // 123
        'Õ':'O',                                                                                        // 124
                                                                                                        // 125
        'ä':'a',                                                                                        // 126
        'ë':'e',                                                                                        // 127
        'ï':'i',                                                                                        // 128
        'ÿ':'y',                                                                                        // 129
                                                                                                        // 130
        'Ä':'A',                                                                                        // 131
        'Ë':'E',                                                                                        // 132
        'Ï':'I',                                                                                        // 133
        'Ÿ':'Y',                                                                                        // 134
                                                                                                        // 135
        'ą':'a',                                                                                        // 136
        'Ą':'A',                                                                                        // 137
        'ę':'e',                                                                                        // 138
        'Ę':'E',                                                                                        // 139
        'ł':'l',                                                                                        // 140
        'Ł':'L',                                                                                        // 141
        'ś':'s',                                                                                        // 142
        'Ś':'S',                                                                                        // 143
        'ń':'n',                                                                                        // 144
        'Ń':'N',                                                                                        // 145
        'ż':'z',                                                                                        // 146
        'Ż':'Z',                                                                                        // 147
        'ź':'z',                                                                                        // 148
        'Ź':'Z',                                                                                        // 149
                                                                                                        // 150
        'å':'a',                                                                                        // 151
        'Å':'A',                                                                                        // 152
        'ß':'ss'                                                                                        // 153
    };                                                                                                  // 154
    return string.replace(                                                                              // 155
        /[áÁéÉíÍöÖőŐóÓüÜűŰúÚàèìòùÀÈÌÒÙâêîôûÂÊÎÔÛãñõÃÑÕäëïÿÄËÏŸąĄęĘłŁśŚńŃżŻźŹåÅ]/g,                      // 156
        function(c) { return _specialChars[c]; }                                                        // 157
    );                                                                                                  // 158
};                                                                                                      // 159
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/universe_utilities/UniConfig.js                                                             //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
'use strict';                                                                                           // 1
/* global UniConfig: true */                                                                            // 2
var _configCollection = new Meteor.Collection('universe_configs');                                      // 3
UniConfig = {                                                                                           // 4
    public:{                                                                                            // 5
        set: function(name, value, isServerWriteOnly){                                                  // 6
            var row = {name: name, value:value, access: 'public', lastModified: new Date()};            // 7
            if(isServerWriteOnly){                                                                      // 8
                row.isServerWriteOnly = isServerWriteOnly;                                              // 9
            }                                                                                           // 10
                                                                                                        // 11
            if(Meteor.isClient){                                                                        // 12
                return _set(row);                                                                       // 13
            }                                                                                           // 14
                                                                                                        // 15
            return !!_configCollection.upsert(                                                          // 16
                {name: name, access: 'public'},                                                         // 17
                row                                                                                     // 18
            );                                                                                          // 19
        },                                                                                              // 20
        get: function(name, defaultValue){                                                              // 21
            var obj = _configCollection.findOne({name: name, access: 'public'});                        // 22
            if(_.isUndefined(obj)) {                                                                    // 23
                return defaultValue;                                                                    // 24
            }                                                                                           // 25
            return obj.value;                                                                           // 26
        },                                                                                              // 27
        getRow: function(name){                                                                         // 28
           return _configCollection.findOne({name: name, access: 'public'});                            // 29
        }                                                                                               // 30
    },                                                                                                  // 31
    users: {                                                                                            // 32
        set: function(name, value, userId){                                                             // 33
            if(!userId){                                                                                // 34
                userId = Meteor.userId();                                                               // 35
            }                                                                                           // 36
            userId = UniUtils.getIdIfDocument(userId);                                                  // 37
            if(!userId){                                                                                // 38
                throw Meteor.Error(404, 'Missing userId');                                              // 39
            }                                                                                           // 40
            var row =  {name: name, value:value, access: userId, lastModified: new Date()};             // 41
            if(Meteor.isClient) {                                                                       // 42
                return _set(row);                                                                       // 43
            }                                                                                           // 44
                                                                                                        // 45
            if(_.isUndefined(value)){                                                                   // 46
                return !!_configCollection.remove({name: name, access: userId});                        // 47
            }                                                                                           // 48
                                                                                                        // 49
            return !!_configCollection.upsert(                                                          // 50
                {name: name, access: userId},                                                           // 51
                row                                                                                     // 52
            );                                                                                          // 53
        },                                                                                              // 54
        get: function(name, defaultValue, userId){                                                      // 55
            if(!userId){                                                                                // 56
                userId = Meteor.userId();                                                               // 57
            }                                                                                           // 58
            userId = UniUtils.getIdIfDocument(userId);                                                  // 59
            if(!userId){                                                                                // 60
                throw Meteor.Error(404, 'Missing userId');                                              // 61
            }                                                                                           // 62
            var obj = _configCollection.findOne({name: name, access: userId});                          // 63
            if(_.isUndefined(obj)) {                                                                    // 64
                return defaultValue;                                                                    // 65
            }                                                                                           // 66
            return obj.value;                                                                           // 67
        },                                                                                              // 68
        getRow: function(name, userId){                                                                 // 69
            return _configCollection.findOne({name: name, access: userId});                             // 70
        }                                                                                               // 71
    },                                                                                                  // 72
    onReady: function(cb){                                                                              // 73
        if(!_.isFunction(cb)){                                                                          // 74
            throw new Meteor.Error(500, 'Function was expected but gets: '+ typeof cb);                 // 75
        }                                                                                               // 76
        if(Meteor.isServer){                                                                            // 77
            cb.call(this);                                                                              // 78
        } else{                                                                                         // 79
            var self = this;                                                                            // 80
            Tracker.autorun(function(c){                                                                // 81
                if(UniConfig.ready()){                                                                  // 82
                    cb.call(self);                                                                      // 83
                    c.stop();                                                                           // 84
                }                                                                                       // 85
            });                                                                                         // 86
        }                                                                                               // 87
    }                                                                                                   // 88
};                                                                                                      // 89
                                                                                                        // 90
var _set = function(row){                                                                               // 91
    UniConfig.onReady(function(){                                                                       // 92
        var doc = _configCollection.findOne({name: row.name, access: row.access});                      // 93
        if(doc){                                                                                        // 94
            if(_.isUndefined(row.value)){                                                               // 95
                return !!_configCollection.remove({name: row.name, access: row.access});                // 96
            }                                                                                           // 97
            _configCollection.update(                                                                   // 98
                {_id: doc._id},                                                                         // 99
                {$set: row}                                                                             // 100
            );                                                                                          // 101
        } else {                                                                                        // 102
            _configCollection.insert(row);                                                              // 103
        }                                                                                               // 104
    });                                                                                                 // 105
    return true;                                                                                        // 106
};                                                                                                      // 107
                                                                                                        // 108
if(Meteor.isServer){                                                                                    // 109
    UniConfig.ready = function(){                                                                       // 110
        return true;                                                                                    // 111
    };                                                                                                  // 112
    UniConfig.private = {                                                                               // 113
        set: function (name, value) {                                                                   // 114
            if (_.isUndefined(value)) {                                                                 // 115
                return !!_configCollection.remove({name: name, access: 'private'});                     // 116
            }                                                                                           // 117
            return !!_configCollection.upsert(                                                          // 118
                {name: name, access: 'private'},                                                        // 119
                {name: name, value: value, access: 'private', lastModified: new Date()}                 // 120
            );                                                                                          // 121
        },                                                                                              // 122
        get: function (name, defaultValue) {                                                            // 123
            var obj = _configCollection.findOne({name: name, access: 'private'});                       // 124
            if (_.isUndefined(obj)) {                                                                   // 125
                return defaultValue;                                                                    // 126
            }                                                                                           // 127
            return obj.value;                                                                           // 128
        },                                                                                              // 129
        getRow: function (name) {                                                                       // 130
            return _configCollection.findOne({name: name, access: 'private'});                          // 131
        },                                                                                              // 132
        runOnce: function (name, callback) {                                                            // 133
            if (!UniConfig.private.get('runOne_' + name)) {                                             // 134
                var result;                                                                             // 135
                try {                                                                                   // 136
                    result = callback();                                                                // 137
                } catch (e) {                                                                           // 138
                    console.error(e);                                                                   // 139
                    result = false;                                                                     // 140
                }                                                                                       // 141
                if (result !== false) {                                                                 // 142
                    UniConfig.private.set('runOne_' + name, new Date());                                // 143
                }                                                                                       // 144
                console.log('Running once:', name, 'status: '+((result !== false)?'ok':'failed'));      // 145
            }                                                                                           // 146
        }                                                                                               // 147
    };                                                                                                  // 148
                                                                                                        // 149
    Meteor.publish('UniConfig', function () {                                                           // 150
        var query = {access: 'public'};                                                                 // 151
        if(_.isString(this.userId) && this.userId !== 'private'){                                       // 152
            query = {$or:[query, {access: this.userId}]};                                               // 153
        }                                                                                               // 154
        return _configCollection.find(query);                                                           // 155
    });                                                                                                 // 156
                                                                                                        // 157
    _configCollection._ensureIndex({name:1, access:1}, {unique: 1});                                    // 158
                                                                                                        // 159
    var _checkRights = function(userId, doc){                                                           // 160
        if(doc.isServerWriteOnly){                                                                      // 161
            return false;                                                                               // 162
        }                                                                                               // 163
        switch(doc.access){                                                                             // 164
            case 'public':                                                                              // 165
                return true;                                                                            // 166
            case 'private':                                                                             // 167
                return false;                                                                           // 168
        }                                                                                               // 169
        return doc.access === userId;                                                                   // 170
    };                                                                                                  // 171
                                                                                                        // 172
    _configCollection.allow({                                                                           // 173
        insert: _checkRights,                                                                           // 174
        update: _checkRights,                                                                           // 175
        remove: _checkRights                                                                            // 176
    });                                                                                                 // 177
} else{                                                                                                 // 178
    var _handleSub = Meteor.subscribe('UniConfig');                                                     // 179
    UniConfig.ready = _handleSub.ready;                                                                 // 180
}                                                                                                       // 181
                                                                                                        // 182
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/universe_utilities/UniEmitter.js                                                            //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
UniUtils.Emitter = function UniEmitter() {                                                              // 1
    this._listeners = {};                                                                               // 2
};                                                                                                      // 3
                                                                                                        // 4
UniUtils.Emitter.prototype.emit = function emit(eventType) {                                            // 5
    if (!Array.isArray(this._listeners[eventType])) {                                                   // 6
        return this;                                                                                    // 7
    }                                                                                                   // 8
    var args = Array.prototype.slice.call(arguments, 1);                                                // 9
    this._listeners[eventType].forEach(function _emit(listener) {                                       // 10
        listener.apply(this, args);                                                                     // 11
    }, this);                                                                                           // 12
                                                                                                        // 13
    return this;                                                                                        // 14
};                                                                                                      // 15
                                                                                                        // 16
UniUtils.Emitter.prototype.on = function on(eventType, listener) {                                      // 17
    if (!Array.isArray(this._listeners[eventType])) {                                                   // 18
        this._listeners[eventType] = [];                                                                // 19
    }                                                                                                   // 20
                                                                                                        // 21
    if (this._listeners[eventType].indexOf(listener) === -1) {                                          // 22
        this._listeners[eventType].push(listener);                                                      // 23
    }                                                                                                   // 24
                                                                                                        // 25
    return this;                                                                                        // 26
};                                                                                                      // 27
                                                                                                        // 28
UniUtils.Emitter.prototype.once = function once(eventType, listener) {                                  // 29
    var self = this;                                                                                    // 30
    function _once() {                                                                                  // 31
        var args = Array.prototype.slice.call(arguments, 0);                                            // 32
        self.off(eventType, _once);                                                                     // 33
        listener.apply(self, args);                                                                     // 34
    }                                                                                                   // 35
    _once.listener = listener;                                                                          // 36
    return this.on(eventType, _once);                                                                   // 37
};                                                                                                      // 38
                                                                                                        // 39
UniUtils.Emitter.prototype.off = function off(eventType, listener) {                                    // 40
    if (!Array.isArray(this._listeners[eventType])) {                                                   // 41
        return this;                                                                                    // 42
    }                                                                                                   // 43
    if (typeof listener === 'undefined') {                                                              // 44
        this._listeners[eventType] = [];                                                                // 45
        return this;                                                                                    // 46
    }                                                                                                   // 47
    var index = this._listeners[eventType].indexOf(listener);                                           // 48
    if (index === -1) {                                                                                 // 49
        for (var i = 0; i < this._listeners[eventType].length; i += 1) {                                // 50
            if (this._listeners[eventType][i].listener === listener) {                                  // 51
                index = i;                                                                              // 52
                break;                                                                                  // 53
            }                                                                                           // 54
        }                                                                                               // 55
    }                                                                                                   // 56
    this._listeners[eventType].splice(index, 1);                                                        // 57
    return this;                                                                                        // 58
};                                                                                                      // 59
                                                                                                        // 60
                                                                                                        // 61
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/universe_utilities/settings.js                                                              //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
if (process) {                                                                                          // 1
    var mode = UniUtils.get(process, 'env.NODE_ENV');                                                   // 2
    var cfgMode = UniConfig.public.get('universeRunningMode');                                          // 3
    if(!cfgMode && mode) {                                                                              // 4
        UniConfig.public.set('universeRunningMode', mode, true);                                        // 5
    } else if (cfgMode && cfgMode !== mode) {                                                           // 6
        console.log('## Forced ' + cfgMode + ' mode ##');                                               // 7
    }                                                                                                   // 8
}                                                                                                       // 9
                                                                                                        // 10
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['universe:utilities'] = {
  UniUtils: UniUtils,
  UniConfig: UniConfig
};

})();

//# sourceMappingURL=universe_utilities.js.map
