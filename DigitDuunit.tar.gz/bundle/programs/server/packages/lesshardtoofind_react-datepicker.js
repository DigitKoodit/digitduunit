(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var ECMAScript = Package.ecmascript.ECMAScript;
var moment = Package['momentjs:moment'].moment;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var Promise = Package.promise.Promise;
var React = Package['react-runtime'].React;
var ReactDOM = Package['react-runtime'].ReactDOM;
var ReactDOMServer = Package['react-runtime'].ReactDOMServer;
var ReactMeteorData = Package['react-meteor-data'].ReactMeteorData;

/* Package-scope variables */
var Tiny, DatePicker;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/lesshardtoofind_react-datepicker/tiny.js                                                                //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
// TinyDatePicker was written as an experiment to see how small a functional date picker                            //
// utility could be. Procedural is a minification optimization.                                                     //
function TinyDatePicker(input, options) {                                                                           // 3
  'use strict';                                                                                                     // 4
                                                                                                                    //
  /////////////////////////////////////////////////////////                                                         //
  // Initialization and state variables                                                                             //
  var opts = initializeOptions(options);                                                                            // 8
  var currentDate = opts.parse(input.value);                                                                        // 9
  var el = buildCalendarElement(currentDate, opts);                                                                 // 10
  var isHiding = false; // Used to prevent the calendar from showing when transitioning to hidden                   // 11
  var focusCatcher = htmlToElement('<button style="position:absolute;border:0;background:transparent;"></button>');
  var body = document.body;                                                                                         // 13
  input.readOnly = true;                                                                                            // 14
                                                                                                                    //
  /////////////////////////////////////////////////////////                                                         //
  // Event handling/state management                                                                                //
  on(input, 'focus', show);                                                                                         // 18
  on(input, 'click', show);                                                                                         // 19
                                                                                                                    //
  on(el, 'keydown', mapKeys({                                                                                       // 21
    '37': shiftDay(-1), // Left                                                                                     // 22
    '38': shiftDay(-7), // Up                                                                                       // 23
    '39': shiftDay(1), // Right                                                                                     // 24
    '40': shiftDay(7), // Down                                                                                      // 25
    '13': function () {                                                                                             // 26
      pickDate(currentDate);                                                                                        // 26
    }, // Enter,                                                                                                    //
    '27': hide // Esc                                                                                               // 27
  }));                                                                                                              //
                                                                                                                    //
  on(el, 'click', mapClick({                                                                                        // 30
    'dp-clear': function () {                                                                                       // 31
      pickDate();                                                                                                   // 31
    },                                                                                                              //
    'dp-close': hide,                                                                                               // 32
    'dp-wrapper': hide,                                                                                             // 33
    'dp-prev': shiftMonth(-1),                                                                                      // 34
    'dp-next': shiftMonth(1),                                                                                       // 35
    'dp-today': function () {                                                                                       // 36
      pickDate(new Date());                                                                                         // 36
    },                                                                                                              //
    'dp-day': function (e) {                                                                                        // 37
      var time = e.target.getAttribute('data-dp');                                                                  // 38
      time && pickDate(new Date(parseInt(time)));                                                                   // 39
    }                                                                                                               //
  }));                                                                                                              //
                                                                                                                    //
  on(el, 'mousedown', function (e) {                                                                                // 43
    if (! ~['A', 'BUTTON'].indexOf(e.target.tagName)) {                                                             // 44
      e.preventDefault(); // Prevent loss of focus                                                                  // 45
    }                                                                                                               //
  });                                                                                                               //
                                                                                                                    //
  on(el, 'blur', function (e) {                                                                                     // 49
    setTimeout(function () {                                                                                        // 50
      el.contains(document.activeElement) || hide();                                                                // 51
    }, 1);                                                                                                          //
  });                                                                                                               //
                                                                                                                    //
  /////////////////////////////////////////////////////////                                                         //
  // UI manipulation functions                                                                                      //
  function show() {                                                                                                 // 60
    if (isHiding) return;                                                                                           // 61
    setDate(opts.parse(input.value));                                                                               // 62
    body.appendChild(el);                                                                                           // 63
    body.appendChild(focusCatcher);                                                                                 // 64
    setTimeout(function () {                                                                                        // 65
      el.className += ' dp-visible';                                                                                // 66
      focus();                                                                                                      // 67
    }, 1);                                                                                                          //
  }                                                                                                                 //
                                                                                                                    //
  function hide() {                                                                                                 // 71
    if (!body.contains(el)) return;                                                                                 // 72
    isHiding = 1;                                                                                                   // 73
    input.focus();                                                                                                  // 74
    input.selectionEnd = input.selectionStart;                                                                      // 75
    body.removeChild(el);                                                                                           // 76
    body.removeChild(focusCatcher);                                                                                 // 77
    el.className = el.className.replace(' dp-visible', '');                                                         // 78
    setTimeout(function () {                                                                                        // 79
      isHiding = 0;                                                                                                 // 79
    }, 1);                                                                                                          //
  }                                                                                                                 //
                                                                                                                    //
  function redraw() {                                                                                               // 82
    el.innerHTML = buildCalendarElement(currentDate, opts).innerHTML;                                               // 83
    focus();                                                                                                        // 84
  }                                                                                                                 //
                                                                                                                    //
  function focus() {                                                                                                // 87
    el.querySelector('.dp-selected').focus();                                                                       // 88
  }                                                                                                                 //
                                                                                                                    //
  /////////////////////////////////////////////////////////                                                         //
  // Date manipulation functions                                                                                    //
  function pickDate(date) {                                                                                         // 96
    input.value = date ? opts.format(date) : '';                                                                    // 97
    setDate(date);                                                                                                  // 98
    hide();                                                                                                         // 99
  }                                                                                                                 //
                                                                                                                    //
  function setDate(date) {                                                                                          // 102
    if (date) {                                                                                                     // 103
      currentDate = date;                                                                                           // 104
      redraw();                                                                                                     // 105
    }                                                                                                               //
  }                                                                                                                 //
                                                                                                                    //
  function shiftDay(amount) {                                                                                       // 109
    return function () {                                                                                            // 110
      currentDate.setDate(currentDate.getDate() + amount);                                                          // 111
      setDate(currentDate);                                                                                         // 112
    };                                                                                                              //
  }                                                                                                                 //
                                                                                                                    //
  function shiftMonth(direction) {                                                                                  // 116
    return function () {                                                                                            // 117
      var dt = new Date(currentDate);                                                                               // 118
      dt.setDate(1);                                                                                                // 119
                                                                                                                    //
      if (direction > 0) {                                                                                          // 121
        dt.setMonth(dt.getMonth() + 2);                                                                             // 122
      }                                                                                                             //
                                                                                                                    //
      dt.setDate(dt.getDate() - 1);                                                                                 // 125
                                                                                                                    //
      if (currentDate.getDate() < dt.getDate()) {                                                                   // 127
        dt.setDate(currentDate.getDate());                                                                          // 128
      }                                                                                                             //
                                                                                                                    //
      setDate(dt);                                                                                                  // 131
    };                                                                                                              //
  }                                                                                                                 //
                                                                                                                    //
  /////////////////////////////////////////////////////////                                                         //
  // Event mapping helpers                                                                                          //
  function mapKeys(map) {                                                                                           // 140
    return function (e) {                                                                                           // 141
      var action = map[e.which];                                                                                    // 142
                                                                                                                    //
      if (action && /dp-selected/.test(e.target.className)) {                                                       // 144
        e.preventDefault();                                                                                         // 145
        action();                                                                                                   // 146
      }                                                                                                             //
    };                                                                                                              //
  }                                                                                                                 //
                                                                                                                    //
  function mapClick(map) {                                                                                          // 151
    return function (e) {                                                                                           // 152
      e.target.className.split(/[\s]+/g).forEach(function (key) {                                                   // 153
        map[key] && map[key](e);                                                                                    // 154
      });                                                                                                           //
    };                                                                                                              //
  }                                                                                                                 //
                                                                                                                    //
  /////////////////////////////////////////////////////////                                                         //
  // Default options                                                                                                //
  function initializeOptions(opts) {                                                                                // 164
    return mergeObj({                                                                                               // 165
      format: function (date) {                                                                                     // 166
        return date.getMonth() + 1 + '/' + date.getDate() + '/' + date.getFullYear();                               // 167
      },                                                                                                            //
                                                                                                                    //
      parse: function (str) {                                                                                       // 170
        var date = new Date(str);                                                                                   // 171
        return isNaN(date) ? new Date() : date;                                                                     // 172
      },                                                                                                            //
                                                                                                                    //
      days: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],                                                      // 175
      months: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
      today: 'Today',                                                                                               // 177
      clear: 'Clear',                                                                                               // 178
      close: 'Close'                                                                                                // 179
    }, opts);                                                                                                       //
  }                                                                                                                 //
                                                                                                                    //
  /////////////////////////////////////////////////////////                                                         //
  // Helper rendering functions                                                                                     //
  function buildCalendarElement(date, opts) {                                                                       // 188
    return htmlToElement('<div class="dp-wrapper">' + '<div class="dp">' + '<header class="dp-header">' + '<button class="dp-prev"></button>' + '<span class="dp-month-year">' + '<span class="dp-month">' + opts.months[date.getMonth()] + '</span>' + '<span class="dp-year">' + date.getFullYear() + '</span>' + '</span>' + '<button class="dp-next"></button>' + '</header>' + '<div class="dp-body">' + renderDateHeadings() + renderDaysOfMonth() + '</div>' + '<footer class="dp-footer">' + '<button class="dp-today">' + opts.today + '</button>' + '<button class="dp-clear">' + opts.clear + '</button>' + '<button class="dp-close">' + opts.close + '</button>' + '</footer>' + '</div>' + '</div>');
                                                                                                                    //
    // Render the column headings                                                                                   //
    function renderDateHeadings() {                                                                                 // 216
      var html = '';                                                                                                // 217
                                                                                                                    //
      // Generate headings...                                                                                       //
      for (var i = 0; i < 7; ++i) {                                                                                 // 220
        html += '<span class="dp-day-of-week">' + opts.days[i] + '</span>';                                         // 221
      }                                                                                                             //
                                                                                                                    //
      return html;                                                                                                  // 224
    }                                                                                                               //
                                                                                                                    //
    // Render the list of days in the calendar month                                                                //
    function renderDaysOfMonth() {                                                                                  // 228
      var iter = new Date(date);                                                                                    // 229
      var html = '';                                                                                                // 230
                                                                                                                    //
      iter.setDate(1); // First of the month                                                                        // 232
      iter.setDate(iter.getDate() - iter.getDay()); // Back to Sunday                                               // 233
                                                                                                                    //
      // We are going to have 6 weeks always displayed to keep a consistent calendar size                           //
      for (var day = 0; day < 6 * 7; ++day) {                                                                       // 236
        var dayOfMonth = iter.getDate();                                                                            // 237
        var classes = 'dp-day';                                                                                     // 238
        var isSelected = iter.toDateString() == date.toDateString();                                                // 239
        var isToday = iter.toDateString() === new Date().toDateString();                                            // 240
        var isNotInMonth = iter.getMonth() !== date.getMonth();                                                     // 241
        var tagName = isSelected ? 'a' : 'span';                                                                    // 242
                                                                                                                    //
        isSelected && (classes += ' dp-selected');                                                                  // 244
        isNotInMonth && (classes += ' dp-edge-day');                                                                // 245
        isToday && (classes += ' dp-day-today');                                                                    // 246
                                                                                                                    //
        html += '<' + tagName + ' href="#" class="' + classes + '" data-dp="' + iter.getTime() + '">' + dayOfMonth + '</' + tagName + '>';
                                                                                                                    //
        iter.setDate(dayOfMonth + 1);                                                                               // 252
      }                                                                                                             //
                                                                                                                    //
      return html;                                                                                                  // 255
    }                                                                                                               //
  }                                                                                                                 //
                                                                                                                    //
  /////////////////////////////////////////////////////////                                                         //
  // Helper functions                                                                                               //
                                                                                                                    //
  // Shorthand for addEventListener                                                                                 //
  function on(el, name, fn) {                                                                                       // 266
    el.addEventListener(name, fn, true);                                                                            // 267
  }                                                                                                                 //
                                                                                                                    //
  // Merge two objects, with the last object overwriting the first                                                  //
  // Has side-effects (overwrites o1), but don't care...                                                            //
  function mergeObj(o1, o2) {                                                                                       // 272
    for (var key in babelHelpers.sanitizeForInObject(o2)) {                                                         // 273
      o1[key] = o2[key];                                                                                            // 274
    }                                                                                                               //
                                                                                                                    //
    return o1;                                                                                                      // 277
  }                                                                                                                 //
                                                                                                                    //
  function htmlToElement(htm) {                                                                                     // 280
    var div = document.createElement('div');                                                                        // 281
    div.innerHTML = htm;                                                                                            // 282
    return div.firstChild;                                                                                          // 283
  }                                                                                                                 //
}                                                                                                                   //
                                                                                                                    //
/////////////////////////////////////////////////////////                                                           //
// Commonjs support                                                                                                 //
if (typeof module !== 'undefined' && module.exports) {                                                              // 290
  module.exports = TinyDatePicker;                                                                                  // 291
}                                                                                                                   //
                                                                                                                    //
Tiny = TinyDatePicker;                                                                                              // 294
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/lesshardtoofind_react-datepicker/react-datepicker.jsx                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
DatePicker = React.createClass({                                                                                    // 1
  displayName: 'DatePicker',                                                                                        //
                                                                                                                    //
  propTypes: {                                                                                                      // 2
    defaultDate: React.PropTypes.string                                                                             // 3
  },                                                                                                                //
                                                                                                                    //
  getInitialState: function () {                                                                                    // 6
    this.id = Meteor.uuid();                                                                                        // 7
    return null;                                                                                                    // 8
  },                                                                                                                //
                                                                                                                    //
  componentDidMount: function () {                                                                                  // 11
    Tiny(document.getElementById(this.id));                                                                         // 12
  },                                                                                                                //
                                                                                                                    //
  getDate: function () {                                                                                            // 15
    return document.getElementById(this.id).value;                                                                  // 16
  },                                                                                                                //
                                                                                                                    //
  getCurrentDate: function () {                                                                                     // 19
    return this.props.defaultDate || moment().format('MM/DD/YYYY');                                                 // 20
  },                                                                                                                //
                                                                                                                    //
  render: function () {                                                                                             // 23
    return React.createElement(                                                                                     // 24
      'div',                                                                                                        //
      null,                                                                                                         //
      React.createElement('input', { id: this.id, value: this.getCurrentDate() })                                   //
    );                                                                                                              //
  }                                                                                                                 //
});                                                                                                                 //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['lesshardtoofind:react-datepicker'] = {
  DatePicker: DatePicker
};

})();

//# sourceMappingURL=lesshardtoofind_react-datepicker.js.map
