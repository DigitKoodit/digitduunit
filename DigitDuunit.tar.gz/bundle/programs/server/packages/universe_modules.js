(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var ECMAScript = Package.ecmascript.ECMAScript;
var Promise = Package.promise.Promise;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;

/* Package-scope variables */
var require, $__curScript, UniverseModulesLoader;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/universe_modules/polyfills/require.js                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// Package level variable required for SystemJS                                                                        //
require = Npm.require;                                                                                                 // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/universe_modules/polyfills/URLPolyfill.js                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// from https://gist.github.com/Yaffle/1088850                                                                         //
(function (global) {                                                                                                   // 2
    "use strict";                                                                                                      // 3
                                                                                                                       //
    function URLUtils(url, baseURL) {                                                                                  // 5
        var m = String(url).replace(/^\s+|\s+$/g, "").match(/^([^:\/?#]+:)?(?:\/\/(?:([^:@\/?#]*)(?::([^:@\/?#]*))?@)?(([^:\/?#]*)(?::(\d*))?))?([^?#]*)(\?[^#]*)?(#[\s\S]*)?/);
        if (!m) {                                                                                                      // 7
            throw new RangeError();                                                                                    // 8
        }                                                                                                              //
        var protocol = m[1] || "";                                                                                     // 10
        var username = m[2] || "";                                                                                     // 11
        var password = m[3] || "";                                                                                     // 12
        var host = m[4] || "";                                                                                         // 13
        var hostname = m[5] || "";                                                                                     // 14
        var port = m[6] || "";                                                                                         // 15
        var pathname = m[7] || "";                                                                                     // 16
        var search = m[8] || "";                                                                                       // 17
        var hash = m[9] || "";                                                                                         // 18
        if (baseURL !== undefined) {                                                                                   // 19
            var base = new URLUtils(baseURL);                                                                          // 20
            var flag = protocol === "" && host === "" && username === "";                                              // 21
            if (flag && pathname === "" && search === "") {                                                            // 22
                search = base.search;                                                                                  // 23
            }                                                                                                          //
            if (flag && pathname.charAt(0) !== "/") {                                                                  // 25
                pathname = pathname !== "" ? ((base.host !== "" || base.username !== "") && base.pathname === "" ? "/" : "") + base.pathname.slice(0, base.pathname.lastIndexOf("/") + 1) + pathname : base.pathname;
            }                                                                                                          //
            // dot segments removal                                                                                    //
            var output = [];                                                                                           // 29
            pathname.replace(/^(\.\.?(\/|$))+/, "").replace(/\/(\.(\/|$))+/g, "/").replace(/\/\.\.$/, "/../").replace(/\/?[^\/]*/g, function (p) {
                if (p === "/..") {                                                                                     // 34
                    output.pop();                                                                                      // 35
                } else {                                                                                               //
                    output.push(p);                                                                                    // 37
                }                                                                                                      //
            });                                                                                                        //
            pathname = output.join("").replace(/^\//, pathname.charAt(0) === "/" ? "/" : "");                          // 40
            if (flag) {                                                                                                // 41
                port = base.port;                                                                                      // 42
                hostname = base.hostname;                                                                              // 43
                host = base.host;                                                                                      // 44
                password = base.password;                                                                              // 45
                username = base.username;                                                                              // 46
            }                                                                                                          //
            if (protocol === "") {                                                                                     // 48
                protocol = base.protocol;                                                                              // 49
            }                                                                                                          //
        }                                                                                                              //
        this.origin = protocol + (protocol !== "" || host !== "" ? "//" : "") + host;                                  // 52
        this.href = protocol + (protocol !== "" || host !== "" ? "//" : "") + (username !== "" ? username + (password !== "" ? ":" + password : "") + "@" : "") + host + pathname + search + hash;
        this.protocol = protocol;                                                                                      // 54
        this.username = username;                                                                                      // 55
        this.password = password;                                                                                      // 56
        this.host = host;                                                                                              // 57
        this.hostname = hostname;                                                                                      // 58
        this.port = port;                                                                                              // 59
        this.pathname = pathname;                                                                                      // 60
        this.search = search;                                                                                          // 61
        this.hash = hash;                                                                                              // 62
    }                                                                                                                  //
                                                                                                                       //
    global.URLPolyfill = URLUtils;                                                                                     // 65
})(this);                                                                                                              //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/universe_modules/vendor/system.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/*                                                                                                                     //
 * SystemJS v0.19.0                                                                                                    //
 */                                                                                                                    //
(function () {                                                                                                         // 4
    function bootstrap() {                                                                                             // 5
        (function (__global) {                                                                                         // 5
                                                                                                                       //
            var isWorker = typeof window == 'undefined' && typeof self != 'undefined' && typeof importScripts != 'undefined';
            var isBrowser = typeof window != 'undefined' && typeof document != 'undefined';                            // 8
            var isWindows = typeof process != 'undefined' && typeof process.platform != 'undefined' && !!process.platform.match(/^win/);
                                                                                                                       //
            if (!__global.console) __global.console = { assert: function () {} };                                      // 11
                                                                                                                       //
            // IE8 support                                                                                             //
            var indexOf = Array.prototype.indexOf || function (item) {                                                 // 15
                for (var i = 0, thisLen = this.length; i < thisLen; i++) {                                             // 16
                    if (this[i] === item) {                                                                            // 17
                        return i;                                                                                      // 18
                    }                                                                                                  //
                }                                                                                                      //
                return -1;                                                                                             // 21
            };                                                                                                         //
                                                                                                                       //
            var defineProperty;                                                                                        // 24
            (function () {                                                                                             // 25
                try {                                                                                                  // 26
                    if (!!Object.defineProperty({}, 'a', {})) defineProperty = Object.defineProperty;                  // 27
                } catch (e) {                                                                                          //
                    defineProperty = function (obj, prop, opt) {                                                       // 31
                        try {                                                                                          // 32
                            obj[prop] = opt.value || opt.get.call(obj);                                                // 33
                        } catch (e) {}                                                                                 //
                    };                                                                                                 //
                }                                                                                                      //
            })();                                                                                                      //
                                                                                                                       //
            function addToError(err, msg) {                                                                            // 40
                var newErr;                                                                                            // 41
                if (err instanceof Error) {                                                                            // 42
                    var newErr = new Error(err.message, err.fileName, err.lineNumber);                                 // 43
                    if (isBrowser) {                                                                                   // 44
                        newErr.message = err.message + '\n\t' + msg;                                                   // 45
                        newErr.stack = err.stack;                                                                      // 46
                    } else {                                                                                           //
                        // node errors only look correct with the stack modified                                       //
                        newErr.message = err.message;                                                                  // 50
                        newErr.stack = err.stack + '\n\t' + msg;                                                       // 51
                    }                                                                                                  //
                } else {                                                                                               //
                    newErr = err + '\n\t' + msg;                                                                       // 55
                }                                                                                                      //
                                                                                                                       //
                return newErr;                                                                                         // 58
            }                                                                                                          //
                                                                                                                       //
            function __eval(source, debugName, context) {                                                              // 61
                try {                                                                                                  // 62
                    new Function(source).call(context);                                                                // 63
                } catch (e) {                                                                                          //
                    throw addToError(e, 'Evaluating ' + debugName);                                                    // 66
                }                                                                                                      //
            }                                                                                                          //
                                                                                                                       //
            var baseURI;                                                                                               // 70
            // environent baseURI detection                                                                            //
            if (typeof document != 'undefined' && document.getElementsByTagName) {                                     // 72
                baseURI = document.baseURI;                                                                            // 73
                                                                                                                       //
                if (!baseURI) {                                                                                        // 75
                    var bases = document.getElementsByTagName('base');                                                 // 76
                    baseURI = bases[0] && bases[0].href || window.location.href;                                       // 77
                }                                                                                                      //
                                                                                                                       //
                // sanitize out the hash and querystring                                                               //
                baseURI = baseURI.split('#')[0].split('?')[0];                                                         // 81
                baseURI = baseURI.substr(0, baseURI.lastIndexOf('/') + 1);                                             // 82
            } else if (typeof process != 'undefined' && process.cwd) {                                                 //
                baseURI = 'file://' + (isWindows ? '/' : '') + process.cwd() + '/';                                    // 85
                if (isWindows) baseURI = baseURI.replace(/\\/g, '/');                                                  // 86
            } else if (typeof location != 'undefined') {                                                               //
                baseURI = __global.location.href;                                                                      // 90
            } else {                                                                                                   //
                throw new TypeError('No environment baseURI');                                                         // 93
            }                                                                                                          //
                                                                                                                       //
            var URL = __global.URLPolyfill || __global.URL;                                                            // 96
            /*                                                                                                         //
             *********************************************************************************************             //
              Dynamic Module Loader Polyfill                                                                           //
              - Implemented exactly to the former 2014-08-24 ES6 Specification Draft Rev 27, Section 15                //
             http://wiki.ecmascript.org/doku.php?id=harmony:specification_drafts#august_24_2014_draft_rev_27           //
              - Functions are commented with their spec numbers, with spec differences commented.                      //
              - Spec bugs are commented in this code with links.                                                       //
              - Abstract functions have been combined where possible, and their associated functions                   //
             commented.                                                                                                //
              - Realm implementation is entirely omitted.                                                              //
              *********************************************************************************************            //
             */                                                                                                        //
                                                                                                                       //
            function Module() {}                                                                                       // 117
            // http://www.ecma-international.org/ecma-262/6.0/#sec-@@tostringtag                                       //
            defineProperty(Module.prototype, 'toString', {                                                             // 119
                value: function () {                                                                                   // 120
                    return 'Module';                                                                                   // 121
                }                                                                                                      //
            });                                                                                                        //
            function Loader(options) {                                                                                 // 124
                this._loader = {                                                                                       // 125
                    loaderObj: this,                                                                                   // 126
                    loads: [],                                                                                         // 127
                    modules: {},                                                                                       // 128
                    importPromises: {},                                                                                // 129
                    moduleRecords: {}                                                                                  // 130
                };                                                                                                     //
                                                                                                                       //
                // 26.3.3.6                                                                                            //
                defineProperty(this, 'global', {                                                                       // 134
                    get: function () {                                                                                 // 135
                        return __global;                                                                               // 136
                    }                                                                                                  //
                });                                                                                                    //
                                                                                                                       //
                // 26.3.3.13 realm not implemented                                                                     //
            }                                                                                                          //
                                                                                                                       //
            (function () {                                                                                             // 143
                                                                                                                       //
                // Some Helpers                                                                                        //
                                                                                                                       //
                // logs a linkset snapshot for debugging                                                               //
                /* function snapshot(loader) {                                                                         //
                 console.log('---Snapshot---');                                                                        //
                 for (var i = 0; i < loader.loads.length; i++) {                                                       //
                 var load = loader.loads[i];                                                                           //
                 var linkSetLog = '  ' + load.name + ' (' + load.status + '): ';                                       //
                  for (var j = 0; j < load.linkSets.length; j++) {                                                     //
                 linkSetLog += '{' + logloads(load.linkSets[j].loads) + '} ';                                          //
                 }                                                                                                     //
                 console.log(linkSetLog);                                                                              //
                 }                                                                                                     //
                 console.log('');                                                                                      //
                 }                                                                                                     //
                 function logloads(loads) {                                                                            //
                 var log = '';                                                                                         //
                 for (var k = 0; k < loads.length; k++)                                                                //
                 log += loads[k].name + (k != loads.length - 1 ? ' ' : '');                                            //
                 return log;                                                                                           //
                 } */                                                                                                  //
                                                                                                                       //
                /* function checkInvariants() {                                                                        //
                 // see https://bugs.ecmascript.org/show_bug.cgi?id=2603#c1                                            //
                  var loads = System._loader.loads;                                                                    //
                 var linkSets = [];                                                                                    //
                  for (var i = 0; i < loads.length; i++) {                                                             //
                 var load = loads[i];                                                                                  //
                 console.assert(load.status == 'loading' || load.status == 'loaded', 'Each load is loading or loaded');
                  for (var j = 0; j < load.linkSets.length; j++) {                                                     //
                 var linkSet = load.linkSets[j];                                                                       //
                  for (var k = 0; k < linkSet.loads.length; k++)                                                       //
                 console.assert(loads.indexOf(linkSet.loads[k]) != -1, 'linkSet loads are a subset of loader loads');  //
                  if (linkSets.indexOf(linkSet) == -1)                                                                 //
                 linkSets.push(linkSet);                                                                               //
                 }                                                                                                     //
                 }                                                                                                     //
                  for (var i = 0; i < loads.length; i++) {                                                             //
                 var load = loads[i];                                                                                  //
                 for (var j = 0; j < linkSets.length; j++) {                                                           //
                 var linkSet = linkSets[j];                                                                            //
                  if (linkSet.loads.indexOf(load) != -1)                                                               //
                 console.assert(load.linkSets.indexOf(linkSet) != -1, 'linkSet contains load -> load contains linkSet');
                  if (load.linkSets.indexOf(linkSet) != -1)                                                            //
                 console.assert(linkSet.loads.indexOf(load) != -1, 'load contains linkSet -> linkSet contains load');  //
                 }                                                                                                     //
                 }                                                                                                     //
                  for (var i = 0; i < linkSets.length; i++) {                                                          //
                 var linkSet = linkSets[i];                                                                            //
                 for (var j = 0; j < linkSet.loads.length; j++) {                                                      //
                 var load = linkSet.loads[j];                                                                          //
                  for (var k = 0; k < load.dependencies.length; k++) {                                                 //
                 var depName = load.dependencies[k].value;                                                             //
                 var depLoad;                                                                                          //
                 for (var l = 0; l < loads.length; l++) {                                                              //
                 if (loads[l].name != depName)                                                                         //
                 continue;                                                                                             //
                 depLoad = loads[l];                                                                                   //
                 break;                                                                                                //
                 }                                                                                                     //
                  // loading records are allowed not to have their dependencies yet                                    //
                 // if (load.status != 'loading')                                                                      //
                 //  console.assert(depLoad, 'depLoad found');                                                         //
                  // console.assert(linkSet.loads.indexOf(depLoad) != -1, 'linkset contains all dependencies');        //
                 }                                                                                                     //
                 }                                                                                                     //
                 }                                                                                                     //
                 } */                                                                                                  //
                                                                                                                       //
                // 15.2.3 - Runtime Semantics: Loader State                                                            //
                                                                                                                       //
                // 15.2.3.11                                                                                           //
                function createLoaderLoad(object) {                                                                    // 231
                    return {                                                                                           // 232
                        // modules is an object for ES5 implementation                                                 //
                        modules: {},                                                                                   // 234
                        loads: [],                                                                                     // 235
                        loaderObj: object                                                                              // 236
                    };                                                                                                 //
                }                                                                                                      //
                                                                                                                       //
                // 15.2.3.2 Load Records and LoadRequest Objects                                                       //
                                                                                                                       //
                // 15.2.3.2.1                                                                                          //
                function createLoad(name) {                                                                            // 243
                    return {                                                                                           // 244
                        status: 'loading',                                                                             // 245
                        name: name,                                                                                    // 246
                        linkSets: [],                                                                                  // 247
                        dependencies: [],                                                                              // 248
                        metadata: {}                                                                                   // 249
                    };                                                                                                 //
                }                                                                                                      //
                                                                                                                       //
                // 15.2.3.2.2 createLoadRequestObject, absorbed into calling functions                                 //
                                                                                                                       //
                // 15.2.4                                                                                              //
                                                                                                                       //
                // 15.2.4.1                                                                                            //
                function loadModule(loader, name, options) {                                                           // 258
                    return new Promise(asyncStartLoadPartwayThrough({                                                  // 259
                        step: options.address ? 'fetch' : 'locate',                                                    // 260
                        loader: loader,                                                                                // 261
                        moduleName: name,                                                                              // 262
                        // allow metadata for import https://bugs.ecmascript.org/show_bug.cgi?id=3091                  //
                        moduleMetadata: options && options.metadata || {},                                             // 264
                        moduleSource: options.source,                                                                  // 265
                        moduleAddress: options.address                                                                 // 266
                    }));                                                                                               //
                }                                                                                                      //
                                                                                                                       //
                // 15.2.4.2                                                                                            //
                function requestLoad(loader, request, refererName, refererAddress) {                                   // 271
                    // 15.2.4.2.1 CallNormalize                                                                        //
                    return new Promise(function (resolve, reject) {                                                    // 273
                        resolve(loader.loaderObj.normalize(request, refererName, refererAddress));                     // 274
                    })                                                                                                 //
                    // 15.2.4.2.2 GetOrCreateLoad                                                                      //
                    .then(function (name) {                                                                            //
                        var load;                                                                                      // 278
                        if (loader.modules[name]) {                                                                    // 279
                            load = createLoad(name);                                                                   // 280
                            load.status = 'linked';                                                                    // 281
                            // https://bugs.ecmascript.org/show_bug.cgi?id=2795                                        //
                            load.module = loader.modules[name];                                                        // 283
                            return load;                                                                               // 284
                        }                                                                                              //
                                                                                                                       //
                        for (var i = 0, l = loader.loads.length; i < l; i++) {                                         // 287
                            load = loader.loads[i];                                                                    // 288
                            if (load.name != name) continue;                                                           // 289
                            console.assert(load.status == 'loading' || load.status == 'loaded', 'loading or loaded');  // 291
                            return load;                                                                               // 292
                        }                                                                                              //
                                                                                                                       //
                        load = createLoad(name);                                                                       // 295
                        loader.loads.push(load);                                                                       // 296
                                                                                                                       //
                        proceedToLocate(loader, load);                                                                 // 298
                                                                                                                       //
                        return load;                                                                                   // 300
                    });                                                                                                //
                }                                                                                                      //
                                                                                                                       //
                // 15.2.4.3                                                                                            //
                function proceedToLocate(loader, load) {                                                               // 305
                    proceedToFetch(loader, load, Promise.resolve()                                                     // 306
                    // 15.2.4.3.1 CallLocate                                                                           //
                    .then(function () {                                                                                //
                        return loader.loaderObj.locate({ name: load.name, metadata: load.metadata });                  // 310
                    }));                                                                                               //
                }                                                                                                      //
                                                                                                                       //
                // 15.2.4.4                                                                                            //
                function proceedToFetch(loader, load, p) {                                                             // 316
                    proceedToTranslate(loader, load, p                                                                 // 317
                    // 15.2.4.4.1 CallFetch                                                                            //
                    .then(function (address) {                                                                         //
                        // adjusted, see https://bugs.ecmascript.org/show_bug.cgi?id=2602                              //
                        if (load.status != 'loading') return;                                                          // 322
                        load.address = address;                                                                        // 324
                                                                                                                       //
                        return loader.loaderObj.fetch({ name: load.name, metadata: load.metadata, address: address });
                    }));                                                                                               //
                }                                                                                                      //
                                                                                                                       //
                var anonCnt = 0;                                                                                       // 331
                                                                                                                       //
                // 15.2.4.5                                                                                            //
                function proceedToTranslate(loader, load, p) {                                                         // 334
                    p                                                                                                  // 335
                    // 15.2.4.5.1 CallTranslate                                                                        //
                    .then(function (source) {                                                                          //
                        if (load.status != 'loading') return;                                                          // 338
                                                                                                                       //
                        return Promise.resolve(loader.loaderObj.translate({ name: load.name, metadata: load.metadata, address: load.address, source: source }))
                                                                                                                       //
                        // 15.2.4.5.2 CallInstantiate                                                                  //
                        .then(function (source) {                                                                      //
                            load.source = source;                                                                      // 345
                            return loader.loaderObj.instantiate({ name: load.name, metadata: load.metadata, address: load.address, source: source });
                        })                                                                                             //
                                                                                                                       //
                        // 15.2.4.5.3 InstantiateSucceeded                                                             //
                        .then(function (instantiateResult) {                                                           //
                            if (instantiateResult === undefined) {                                                     // 351
                                load.address = load.address || '<Anonymous Module ' + ++anonCnt + '>';                 // 352
                                                                                                                       //
                                // instead of load.kind, use load.isDeclarative                                        //
                                load.isDeclarative = true;                                                             // 355
                                return transpile.call(loader.loaderObj, load).then(function (transpiled) {             // 356
                                    // Hijack System.register to set declare function                                  //
                                    var curSystem = __global.System;                                                   // 359
                                    var curRegister = curSystem.register;                                              // 360
                                    curSystem.register = function (name, deps, declare) {                              // 361
                                        if (typeof name != 'string') {                                                 // 362
                                            declare = deps;                                                            // 363
                                            deps = name;                                                               // 364
                                        }                                                                              //
                                        // store the registered declaration as load.declare                            //
                                        // store the deps as load.deps                                                 //
                                        load.declare = declare;                                                        // 368
                                        load.depsList = deps;                                                          // 369
                                    };                                                                                 //
                                    // empty {} context is closest to undefined 'this' we can get                      //
                                    __eval(transpiled, load.address, {});                                              // 372
                                    curSystem.register = curRegister;                                                  // 373
                                });                                                                                    //
                            } else if (typeof instantiateResult == 'object') {                                         //
                                load.depsList = instantiateResult.deps || [];                                          // 377
                                load.execute = instantiateResult.execute;                                              // 378
                                load.isDeclarative = false;                                                            // 379
                            } else throw TypeError('Invalid instantiate return value');                                //
                        })                                                                                             //
                        // 15.2.4.6 ProcessLoadDependencies                                                            //
                        .then(function () {                                                                            //
                            load.dependencies = [];                                                                    // 386
                            var depsList = load.depsList;                                                              // 387
                                                                                                                       //
                            var loadPromises = [];                                                                     // 389
                            for (var i = 0, l = depsList.length; i < l; i++) (function (request, index) {              // 390
                                loadPromises.push(requestLoad(loader, request, load.name, load.address)                // 391
                                                                                                                       //
                                // 15.2.4.6.1 AddDependencyLoad (load is parentLoad)                                   //
                                .then(function (depLoad) {                                                             //
                                                                                                                       //
                                    // adjusted from spec to maintain dependency order                                 //
                                    // this is due to the System.register internal implementation needs                //
                                    load.dependencies[index] = {                                                       // 399
                                        key: request,                                                                  // 400
                                        value: depLoad.name                                                            // 401
                                    };                                                                                 //
                                                                                                                       //
                                    if (depLoad.status != 'linked') {                                                  // 404
                                        var linkSets = load.linkSets.concat([]);                                       // 405
                                        for (var i = 0, l = linkSets.length; i < l; i++) addLoadToLinkSet(linkSets[i], depLoad);
                                    }                                                                                  //
                                                                                                                       //
                                    // console.log('AddDependencyLoad ' + depLoad.name + ' for ' + load.name);         //
                                    // snapshot(loader);                                                               //
                                }));                                                                                   //
                            })(depsList[i], i);                                                                        //
                                                                                                                       //
                            return Promise.all(loadPromises);                                                          // 416
                        })                                                                                             //
                                                                                                                       //
                        // 15.2.4.6.2 LoadSucceeded                                                                    //
                        .then(function () {                                                                            //
                            // console.log('LoadSucceeded ' + load.name);                                              //
                            // snapshot(loader);                                                                       //
                                                                                                                       //
                            console.assert(load.status == 'loading', 'is loading');                                    // 424
                                                                                                                       //
                            load.status = 'loaded';                                                                    // 426
                                                                                                                       //
                            var linkSets = load.linkSets.concat([]);                                                   // 428
                            for (var i = 0, l = linkSets.length; i < l; i++) updateLinkSetOnLoad(linkSets[i], load);   // 429
                        });                                                                                            //
                    })                                                                                                 //
                    // 15.2.4.5.4 LoadFailed                                                                           //
                    ['catch'](function (exc) {                                                                         //
                        load.status = 'failed';                                                                        // 435
                        load.exception = exc;                                                                          // 436
                                                                                                                       //
                        var linkSets = load.linkSets.concat([]);                                                       // 438
                        for (var i = 0, l = linkSets.length; i < l; i++) {                                             // 439
                            linkSetFailed(linkSets[i], load, exc);                                                     // 440
                        }                                                                                              //
                                                                                                                       //
                        console.assert(load.linkSets.length == 0, 'linkSets not removed');                             // 443
                    });                                                                                                //
                }                                                                                                      //
                                                                                                                       //
                // 15.2.4.7 PromiseOfStartLoadPartwayThrough absorbed into calling functions                           //
                                                                                                                       //
                // 15.2.4.7.1                                                                                          //
                function asyncStartLoadPartwayThrough(stepState) {                                                     // 450
                    return function (resolve, reject) {                                                                // 451
                        var loader = stepState.loader;                                                                 // 452
                        var name = stepState.moduleName;                                                               // 453
                        var step = stepState.step;                                                                     // 454
                                                                                                                       //
                        if (loader.modules[name]) throw new TypeError('"' + name + '" already exists in the module table');
                                                                                                                       //
                        // adjusted to pick up existing loads                                                          //
                        var existingLoad;                                                                              // 460
                        for (var i = 0, l = loader.loads.length; i < l; i++) {                                         // 461
                            if (loader.loads[i].name == name) {                                                        // 462
                                existingLoad = loader.loads[i];                                                        // 463
                                                                                                                       //
                                if (step == 'translate' && !existingLoad.source) {                                     // 465
                                    existingLoad.address = stepState.moduleAddress;                                    // 466
                                    proceedToTranslate(loader, existingLoad, Promise.resolve(stepState.moduleSource));
                                }                                                                                      //
                                                                                                                       //
                                // a primary load -> use that existing linkset                                         //
                                if (existingLoad.linkSets.length) return existingLoad.linkSets[0].done.then(function () {
                                    resolve(existingLoad);                                                             // 473
                                });                                                                                    //
                            }                                                                                          //
                        }                                                                                              //
                                                                                                                       //
                        var load = existingLoad || createLoad(name);                                                   // 478
                                                                                                                       //
                        load.metadata = stepState.moduleMetadata;                                                      // 480
                                                                                                                       //
                        var linkSet = createLinkSet(loader, load);                                                     // 482
                                                                                                                       //
                        loader.loads.push(load);                                                                       // 484
                                                                                                                       //
                        resolve(linkSet.done);                                                                         // 486
                                                                                                                       //
                        if (step == 'locate') proceedToLocate(loader, load);else if (step == 'fetch') proceedToFetch(loader, load, Promise.resolve(stepState.moduleAddress));else {
                            console.assert(step == 'translate', 'translate step');                                     // 495
                            load.address = stepState.moduleAddress;                                                    // 496
                            proceedToTranslate(loader, load, Promise.resolve(stepState.moduleSource));                 // 497
                        }                                                                                              //
                    };                                                                                                 //
                }                                                                                                      //
                                                                                                                       //
                // Declarative linking functions run through alternative implementation:                               //
                // 15.2.5.1.1 CreateModuleLinkageRecord not implemented                                                //
                // 15.2.5.1.2 LookupExport not implemented                                                             //
                // 15.2.5.1.3 LookupModuleDependency not implemented                                                   //
                                                                                                                       //
                // 15.2.5.2.1                                                                                          //
                function createLinkSet(loader, startingLoad) {                                                         // 508
                    var linkSet = {                                                                                    // 509
                        loader: loader,                                                                                // 510
                        loads: [],                                                                                     // 511
                        startingLoad: startingLoad, // added see spec bug https://bugs.ecmascript.org/show_bug.cgi?id=2995
                        loadingCount: 0                                                                                // 513
                    };                                                                                                 //
                    linkSet.done = new Promise(function (resolve, reject) {                                            // 515
                        linkSet.resolve = resolve;                                                                     // 516
                        linkSet.reject = reject;                                                                       // 517
                    });                                                                                                //
                    addLoadToLinkSet(linkSet, startingLoad);                                                           // 519
                    return linkSet;                                                                                    // 520
                }                                                                                                      //
                // 15.2.5.2.2                                                                                          //
                function addLoadToLinkSet(linkSet, load) {                                                             // 523
                    if (load.status == 'failed') return;                                                               // 524
                                                                                                                       //
                    console.assert(load.status == 'loading' || load.status == 'loaded', 'loading or loaded on link set');
                                                                                                                       //
                    for (var i = 0, l = linkSet.loads.length; i < l; i++) if (linkSet.loads[i] == load) return;        // 529
                                                                                                                       //
                    linkSet.loads.push(load);                                                                          // 533
                    load.linkSets.push(linkSet);                                                                       // 534
                                                                                                                       //
                    // adjustment, see https://bugs.ecmascript.org/show_bug.cgi?id=2603                                //
                    if (load.status != 'loaded') {                                                                     // 537
                        linkSet.loadingCount++;                                                                        // 538
                    }                                                                                                  //
                                                                                                                       //
                    var loader = linkSet.loader;                                                                       // 541
                                                                                                                       //
                    for (var i = 0, l = load.dependencies.length; i < l; i++) {                                        // 543
                        if (!load.dependencies[i]) continue;                                                           // 544
                                                                                                                       //
                        var name = load.dependencies[i].value;                                                         // 547
                                                                                                                       //
                        if (loader.modules[name]) continue;                                                            // 549
                                                                                                                       //
                        for (var j = 0, d = loader.loads.length; j < d; j++) {                                         // 552
                            if (loader.loads[j].name != name) continue;                                                // 553
                                                                                                                       //
                            addLoadToLinkSet(linkSet, loader.loads[j]);                                                // 556
                            break;                                                                                     // 557
                        }                                                                                              //
                    }                                                                                                  //
                    // console.log('add to linkset ' + load.name);                                                     //
                    // snapshot(linkSet.loader);                                                                       //
                }                                                                                                      //
                                                                                                                       //
                // linking errors can be generic or load-specific                                                      //
                // this is necessary for debugging info                                                                //
                function doLink(linkSet) {                                                                             // 566
                    var error = false;                                                                                 // 567
                    try {                                                                                              // 568
                        link(linkSet, function (load, exc) {                                                           // 569
                            linkSetFailed(linkSet, load, exc);                                                         // 570
                            error = true;                                                                              // 571
                        });                                                                                            //
                    } catch (e) {                                                                                      //
                        linkSetFailed(linkSet, null, e);                                                               // 575
                        error = true;                                                                                  // 576
                    }                                                                                                  //
                    return error;                                                                                      // 578
                }                                                                                                      //
                                                                                                                       //
                // 15.2.5.2.3                                                                                          //
                function updateLinkSetOnLoad(linkSet, load) {                                                          // 582
                    // console.log('update linkset on load ' + load.name);                                             //
                    // snapshot(linkSet.loader);                                                                       //
                                                                                                                       //
                    console.assert(load.status == 'loaded' || load.status == 'linked', 'loaded or linked');            // 586
                                                                                                                       //
                    linkSet.loadingCount--;                                                                            // 588
                                                                                                                       //
                    if (linkSet.loadingCount > 0) return;                                                              // 590
                                                                                                                       //
                    // adjusted for spec bug https://bugs.ecmascript.org/show_bug.cgi?id=2995                          //
                    var startingLoad = linkSet.startingLoad;                                                           // 594
                                                                                                                       //
                    // non-executing link variation for loader tracing                                                 //
                    // on the server. Not in spec.                                                                     //
                    /***/                                                                                              //
                    if (linkSet.loader.loaderObj.execute === false) {                                                  // 599
                        var loads = [].concat(linkSet.loads);                                                          // 600
                        for (var i = 0, l = loads.length; i < l; i++) {                                                // 601
                            var load = loads[i];                                                                       // 602
                            load.module = !load.isDeclarative ? {                                                      // 603
                                module: _newModule({})                                                                 // 604
                            } : {                                                                                      //
                                name: load.name,                                                                       // 606
                                module: _newModule({}),                                                                // 607
                                evaluated: true                                                                        // 608
                            };                                                                                         //
                            load.status = 'linked';                                                                    // 610
                            finishLoad(linkSet.loader, load);                                                          // 611
                        }                                                                                              //
                        return linkSet.resolve(startingLoad);                                                          // 613
                    }                                                                                                  //
                    /***/                                                                                              //
                                                                                                                       //
                    var abrupt = doLink(linkSet);                                                                      // 617
                                                                                                                       //
                    if (abrupt) return;                                                                                // 619
                                                                                                                       //
                    console.assert(linkSet.loads.length == 0, 'loads cleared');                                        // 622
                                                                                                                       //
                    linkSet.resolve(startingLoad);                                                                     // 624
                }                                                                                                      //
                                                                                                                       //
                // 15.2.5.2.4                                                                                          //
                function linkSetFailed(linkSet, load, exc) {                                                           // 628
                    var loader = linkSet.loader;                                                                       // 629
                    var requests;                                                                                      // 630
                                                                                                                       //
                    checkError: if (load) {                                                                            // 632
                        if (linkSet.loads[0].name == load.name) {                                                      // 634
                            exc = addToError(exc, 'Error loading ' + load.name);                                       // 635
                        } else {                                                                                       //
                            for (var i = 0; i < linkSet.loads.length; i++) {                                           // 638
                                var pLoad = linkSet.loads[i];                                                          // 639
                                for (var j = 0; j < pLoad.dependencies.length; j++) {                                  // 640
                                    var dep = pLoad.dependencies[j];                                                   // 641
                                    if (dep.value == load.name) {                                                      // 642
                                        exc = addToError(exc, 'Error loading ' + load.name + ' as "' + dep.key + '" from ' + pLoad.name);
                                        break checkError;                                                              // 644
                                    }                                                                                  //
                                }                                                                                      //
                            }                                                                                          //
                            exc = addToError(exc, 'Error loading ' + load.name + ' from ' + linkSet.loads[0].name);    // 648
                        }                                                                                              //
                    } else {                                                                                           //
                        exc = addToError(exc, 'Error linking ' + linkSet.loads[0].name);                               // 652
                    }                                                                                                  //
                                                                                                                       //
                    var loads = linkSet.loads.concat([]);                                                              // 656
                    for (var i = 0, l = loads.length; i < l; i++) {                                                    // 657
                        var load = loads[i];                                                                           // 658
                                                                                                                       //
                        // store all failed load records                                                               //
                        loader.loaderObj.failed = loader.loaderObj.failed || [];                                       // 661
                        if (indexOf.call(loader.loaderObj.failed, load) == -1) loader.loaderObj.failed.push(load);     // 662
                                                                                                                       //
                        var linkIndex = indexOf.call(load.linkSets, linkSet);                                          // 665
                        console.assert(linkIndex != -1, 'link not present');                                           // 666
                        load.linkSets.splice(linkIndex, 1);                                                            // 667
                        if (load.linkSets.length == 0) {                                                               // 668
                            var globalLoadsIndex = indexOf.call(linkSet.loader.loads, load);                           // 669
                            if (globalLoadsIndex != -1) linkSet.loader.loads.splice(globalLoadsIndex, 1);              // 670
                        }                                                                                              //
                    }                                                                                                  //
                    linkSet.reject(exc);                                                                               // 674
                }                                                                                                      //
                                                                                                                       //
                // 15.2.5.2.5                                                                                          //
                function finishLoad(loader, load) {                                                                    // 678
                    // add to global trace if tracing                                                                  //
                    if (loader.loaderObj.trace) {                                                                      // 680
                        if (!loader.loaderObj.loads) loader.loaderObj.loads = {};                                      // 681
                        var depMap = {};                                                                               // 683
                        load.dependencies.forEach(function (dep) {                                                     // 684
                            depMap[dep.key] = dep.value;                                                               // 685
                        });                                                                                            //
                        loader.loaderObj.loads[load.name] = {                                                          // 687
                            name: load.name,                                                                           // 688
                            deps: load.dependencies.map(function (dep) {                                               // 689
                                return dep.key;                                                                        // 689
                            }),                                                                                        //
                            depMap: depMap,                                                                            // 690
                            address: load.address,                                                                     // 691
                            metadata: load.metadata,                                                                   // 692
                            source: load.source,                                                                       // 693
                            kind: load.isDeclarative ? 'declarative' : 'dynamic'                                       // 694
                        };                                                                                             //
                    }                                                                                                  //
                    // if not anonymous, add to the module table                                                       //
                    if (load.name) {                                                                                   // 698
                        console.assert(!loader.modules[load.name], 'load not in module table');                        // 699
                        loader.modules[load.name] = load.module;                                                       // 700
                    }                                                                                                  //
                    var loadIndex = indexOf.call(loader.loads, load);                                                  // 702
                    if (loadIndex != -1) loader.loads.splice(loadIndex, 1);                                            // 703
                    for (var i = 0, l = load.linkSets.length; i < l; i++) {                                            // 705
                        loadIndex = indexOf.call(load.linkSets[i].loads, load);                                        // 706
                        if (loadIndex != -1) load.linkSets[i].loads.splice(loadIndex, 1);                              // 707
                    }                                                                                                  //
                    load.linkSets.splice(0, load.linkSets.length);                                                     // 710
                }                                                                                                      //
                                                                                                                       //
                function doDynamicExecute(linkSet, load, linkError) {                                                  // 713
                    try {                                                                                              // 714
                        var module = load.execute();                                                                   // 715
                    } catch (e) {                                                                                      //
                        linkError(load, e);                                                                            // 718
                        return;                                                                                        // 719
                    }                                                                                                  //
                    if (!module || !(module instanceof Module)) linkError(load, new TypeError('Execution must define a Module instance'));else return module;
                }                                                                                                      //
                                                                                                                       //
                // 26.3 Loader                                                                                         //
                                                                                                                       //
                // 26.3.1.1                                                                                            //
                // defined at top                                                                                      //
                                                                                                                       //
                // importPromises adds ability to import a module twice without error - https://bugs.ecmascript.org/show_bug.cgi?id=2601
                function createImportPromise(loader, name, promise) {                                                  // 733
                    var importPromises = loader._loader.importPromises;                                                // 734
                    return importPromises[name] = promise.then(function (m) {                                          // 735
                        importPromises[name] = undefined;                                                              // 736
                        return m;                                                                                      // 737
                    }, function (e) {                                                                                  //
                        importPromises[name] = undefined;                                                              // 739
                        throw e;                                                                                       // 740
                    });                                                                                                //
                }                                                                                                      //
                                                                                                                       //
                Loader.prototype = {                                                                                   // 744
                    // 26.3.3.1                                                                                        //
                    constructor: Loader,                                                                               // 746
                    // 26.3.3.2                                                                                        //
                    define: function (name, source, options) {                                                         // 748
                        // check if already defined                                                                    //
                        if (this._loader.importPromises[name]) throw new TypeError('Module is already loading.');      // 750
                        return createImportPromise(this, name, new Promise(asyncStartLoadPartwayThrough({              // 752
                            step: 'translate',                                                                         // 753
                            loader: this._loader,                                                                      // 754
                            moduleName: name,                                                                          // 755
                            moduleMetadata: options && options.metadata || {},                                         // 756
                            moduleSource: source,                                                                      // 757
                            moduleAddress: options && options.address                                                  // 758
                        })));                                                                                          //
                    },                                                                                                 //
                    // 26.3.3.3                                                                                        //
                    'delete': function (name) {                                                                        // 762
                        var loader = this._loader;                                                                     // 763
                        delete loader.importPromises[name];                                                            // 764
                        delete loader.moduleRecords[name];                                                             // 765
                        return loader.modules[name] ? delete loader.modules[name] : false;                             // 766
                    },                                                                                                 //
                    // 26.3.3.4 entries not implemented                                                                //
                    // 26.3.3.5                                                                                        //
                    get: function (key) {                                                                              // 770
                        if (!this._loader.modules[key]) return;                                                        // 771
                        doEnsureEvaluated(this._loader.modules[key], [], this);                                        // 773
                        return this._loader.modules[key].module;                                                       // 774
                    },                                                                                                 //
                    // 26.3.3.7                                                                                        //
                    has: function (name) {                                                                             // 777
                        return !!this._loader.modules[name];                                                           // 778
                    },                                                                                                 //
                    // 26.3.3.8                                                                                        //
                    'import': function (name, parentName, parentAddress) {                                             // 781
                        if (typeof parentName == 'object') parentName = parentName.name;                               // 782
                                                                                                                       //
                        // run normalize first                                                                         //
                        var loaderObj = this;                                                                          // 786
                                                                                                                       //
                        // added, see https://bugs.ecmascript.org/show_bug.cgi?id=2659                                 //
                        return Promise.resolve(loaderObj.normalize(name, parentName)).then(function (name) {           // 789
                            var loader = loaderObj._loader;                                                            // 791
                                                                                                                       //
                            if (loader.modules[name]) {                                                                // 793
                                doEnsureEvaluated(loader.modules[name], [], loader._loader);                           // 794
                                return loader.modules[name].module;                                                    // 795
                            }                                                                                          //
                                                                                                                       //
                            return loader.importPromises[name] || createImportPromise(loaderObj, name, loadModule(loader, name, {}).then(function (load) {
                                delete loader.importPromises[name];                                                    // 801
                                return evaluateLoadedModule(loader, load);                                             // 802
                            }));                                                                                       //
                        });                                                                                            //
                    },                                                                                                 //
                    // 26.3.3.9 keys not implemented                                                                   //
                    // 26.3.3.10                                                                                       //
                    load: function (name, options) {                                                                   // 808
                        var loader = this._loader;                                                                     // 809
                        if (loader.modules[name]) {                                                                    // 810
                            doEnsureEvaluated(loader.modules[name], [], loader);                                       // 811
                            return Promise.resolve(loader.modules[name].module);                                       // 812
                        }                                                                                              //
                        return loader.importPromises[name] || createImportPromise(this, name, loadModule(loader, name, {}).then(function (load) {
                            delete loader.importPromises[name];                                                        // 817
                            return evaluateLoadedModule(loader, load);                                                 // 818
                        }));                                                                                           //
                    },                                                                                                 //
                    // 26.3.3.11                                                                                       //
                    module: function (source, options) {                                                               // 822
                        var load = createLoad();                                                                       // 823
                        load.address = options && options.address;                                                     // 824
                        var linkSet = createLinkSet(this._loader, load);                                               // 825
                        var sourcePromise = Promise.resolve(source);                                                   // 826
                        var loader = this._loader;                                                                     // 827
                        var p = linkSet.done.then(function () {                                                        // 828
                            return evaluateLoadedModule(loader, load);                                                 // 829
                        });                                                                                            //
                        proceedToTranslate(loader, load, sourcePromise);                                               // 831
                        return p;                                                                                      // 832
                    },                                                                                                 //
                    // 26.3.3.12                                                                                       //
                    newModule: function (obj) {                                                                        // 835
                        if (typeof obj != 'object') throw new TypeError('Expected object');                            // 836
                                                                                                                       //
                        // we do this to be able to tell if a module is a module privately in ES5                      //
                        // by doing m instanceof Module                                                                //
                        var m = new Module();                                                                          // 841
                                                                                                                       //
                        var pNames;                                                                                    // 843
                        if (Object.getOwnPropertyNames && obj != null) {                                               // 844
                            pNames = Object.getOwnPropertyNames(obj);                                                  // 845
                        } else {                                                                                       //
                            pNames = [];                                                                               // 848
                            for (var key in babelHelpers.sanitizeForInObject(obj)) pNames.push(key);                   // 849
                        }                                                                                              //
                                                                                                                       //
                        for (var i = 0; i < pNames.length; i++) (function (key) {                                      // 853
                            defineProperty(m, key, {                                                                   // 854
                                configurable: false,                                                                   // 855
                                enumerable: true,                                                                      // 856
                                get: function () {                                                                     // 857
                                    return obj[key];                                                                   // 858
                                }                                                                                      //
                            });                                                                                        //
                        })(pNames[i]);                                                                                 //
                                                                                                                       //
                        if (Object.preventExtensions) Object.preventExtensions(m);                                     // 863
                                                                                                                       //
                        return m;                                                                                      // 866
                    },                                                                                                 //
                    // 26.3.3.14                                                                                       //
                    set: function (name, module) {                                                                     // 869
                        if (!(module instanceof Module)) throw new TypeError('Loader.set(' + name + ', module) must be a module');
                        this._loader.modules[name] = {                                                                 // 872
                            module: module                                                                             // 873
                        };                                                                                             //
                    },                                                                                                 //
                    // 26.3.3.15 values not implemented                                                                //
                    // 26.3.3.16 @@iterator not implemented                                                            //
                    // 26.3.3.17 @@toStringTag not implemented                                                         //
                                                                                                                       //
                    // 26.3.3.18.1                                                                                     //
                    normalize: function (name, referrerName, referrerAddress) {                                        // 881
                        return name;                                                                                   // 882
                    },                                                                                                 //
                    // 26.3.3.18.2                                                                                     //
                    locate: function (load) {                                                                          // 885
                        return load.name;                                                                              // 886
                    },                                                                                                 //
                    // 26.3.3.18.3                                                                                     //
                    fetch: function (load) {},                                                                         // 889
                    // 26.3.3.18.4                                                                                     //
                    translate: function (load) {                                                                       // 892
                        return load.source;                                                                            // 893
                    },                                                                                                 //
                    // 26.3.3.18.5                                                                                     //
                    instantiate: function (load) {}                                                                    // 896
                };                                                                                                     //
                                                                                                                       //
                var _newModule = Loader.prototype.newModule;                                                           // 900
                /*                                                                                                     //
                 * ES6 Module Declarative Linking Code - Dev Build Only                                                //
                 */                                                                                                    //
                function link(linkSet, linkError) {                                                                    // 904
                                                                                                                       //
                    var loader = linkSet.loader;                                                                       // 906
                                                                                                                       //
                    if (!linkSet.loads.length) return;                                                                 // 908
                                                                                                                       //
                    var loads = linkSet.loads.concat([]);                                                              // 911
                                                                                                                       //
                    for (var i = 0; i < loads.length; i++) {                                                           // 913
                        var load = loads[i];                                                                           // 914
                                                                                                                       //
                        var module = doDynamicExecute(linkSet, load, linkError);                                       // 916
                        if (!module) return;                                                                           // 917
                        load.module = {                                                                                // 919
                            name: load.name,                                                                           // 920
                            module: module                                                                             // 921
                        };                                                                                             //
                        load.status = 'linked';                                                                        // 923
                                                                                                                       //
                        finishLoad(loader, load);                                                                      // 925
                    }                                                                                                  //
                }                                                                                                      //
                                                                                                                       //
                function evaluateLoadedModule(loader, load) {                                                          // 929
                    console.assert(load.status == 'linked', 'is linked ' + load.name);                                 // 930
                    return load.module.module;                                                                         // 931
                }                                                                                                      //
                                                                                                                       //
                function doEnsureEvaluated() {}                                                                        // 934
                                                                                                                       //
                function transpile() {                                                                                 // 936
                    throw new TypeError('ES6 transpilation is only provided in the dev module loader build.');         // 937
                }                                                                                                      //
            })(); /*                                                                                                   //
                  *********************************************************************************************        //
                  System Loader Implementation                                                                         //
                  - Implemented to https://github.com/jorendorff/js-loaders/blob/master/browser-loader.js              //
                  - <script type="module"> supported                                                                   //
                  *********************************************************************************************        //
                  */                                                                                                   //
                                                                                                                       //
            var System;                                                                                                // 951
                                                                                                                       //
            function SystemLoader() {                                                                                  // 953
                Loader.call(this);                                                                                     // 954
                this.paths = {};                                                                                       // 955
            }                                                                                                          //
                                                                                                                       //
            // NB no specification provided for System.paths, used ideas discussed in https://github.com/jorendorff/js-loaders/issues/25
            function applyPaths(paths, name) {                                                                         // 959
                // most specific (most number of slashes in path) match wins                                           //
                var pathMatch = '',                                                                                    // 961
                    wildcard,                                                                                          //
                    maxSlashCount = 0;                                                                                 //
                                                                                                                       //
                // check to see if we have a paths entry                                                               //
                for (var p in babelHelpers.sanitizeForInObject(paths)) {                                               // 964
                    var pathParts = p.split('*');                                                                      // 965
                    if (pathParts.length > 2) throw new TypeError('Only one wildcard in a path is permitted');         // 966
                                                                                                                       //
                    // exact path match                                                                                //
                    if (pathParts.length == 1) {                                                                       // 970
                        if (name == p) {                                                                               // 971
                            pathMatch = p;                                                                             // 972
                            break;                                                                                     // 973
                        }                                                                                              //
                    }                                                                                                  //
                    // wildcard path match                                                                             //
                    else {                                                                                             //
                            var slashCount = p.split('/').length;                                                      // 978
                            if (slashCount >= maxSlashCount && name.substr(0, pathParts[0].length) == pathParts[0] && name.substr(name.length - pathParts[1].length) == pathParts[1]) {
                                maxSlashCount = slashCount;                                                            // 982
                                pathMatch = p;                                                                         // 983
                                wildcard = name.substr(pathParts[0].length, name.length - pathParts[1].length - pathParts[0].length);
                            }                                                                                          //
                        }                                                                                              //
                }                                                                                                      //
                                                                                                                       //
                var outPath = paths[pathMatch] || name;                                                                // 989
                if (typeof wildcard == 'string') outPath = outPath.replace('*', wildcard);                             // 990
                                                                                                                       //
                return outPath;                                                                                        // 993
            }                                                                                                          //
                                                                                                                       //
            // inline Object.create-style class extension                                                              //
            function LoaderProto() {}                                                                                  // 997
            LoaderProto.prototype = Loader.prototype;                                                                  // 998
            SystemLoader.prototype = new LoaderProto();                                                                // 999
            var fetchTextFromURL;                                                                                      // 1000
            if (typeof XMLHttpRequest != 'undefined') {                                                                // 1001
                fetchTextFromURL = function (url, authorization, fulfill, reject) {                                    // 1002
                    var xhr = new XMLHttpRequest();                                                                    // 1003
                    var sameDomain = true;                                                                             // 1004
                    var doTimeout = false;                                                                             // 1005
                    if (!('withCredentials' in xhr)) {                                                                 // 1006
                        // check if same domain                                                                        //
                        var domainCheck = /^(\w+:)?\/\/([^\/]+)/.exec(url);                                            // 1008
                        if (domainCheck) {                                                                             // 1009
                            sameDomain = domainCheck[2] === window.location.host;                                      // 1010
                            if (domainCheck[1]) sameDomain &= domainCheck[1] === window.location.protocol;             // 1011
                        }                                                                                              //
                    }                                                                                                  //
                    if (!sameDomain && typeof XDomainRequest != 'undefined') {                                         // 1015
                        xhr = new XDomainRequest();                                                                    // 1016
                        xhr.onload = load;                                                                             // 1017
                        xhr.onerror = error;                                                                           // 1018
                        xhr.ontimeout = error;                                                                         // 1019
                        xhr.onprogress = function () {};                                                               // 1020
                        xhr.timeout = 0;                                                                               // 1021
                        doTimeout = true;                                                                              // 1022
                    }                                                                                                  //
                    function load() {                                                                                  // 1024
                        fulfill(xhr.responseText);                                                                     // 1025
                    }                                                                                                  //
                    function error() {                                                                                 // 1027
                        reject(new Error('XHR error' + (xhr.status ? ' (' + xhr.status + (xhr.statusText ? ' ' + xhr.statusText : '') + ')' : '') + ' loading ' + url));
                    }                                                                                                  //
                                                                                                                       //
                    xhr.onreadystatechange = function () {                                                             // 1031
                        if (xhr.readyState === 4) {                                                                    // 1032
                            if (xhr.status === 200 || xhr.status == 0 && xhr.responseText) {                           // 1033
                                load();                                                                                // 1034
                            } else {                                                                                   //
                                error();                                                                               // 1036
                            }                                                                                          //
                        }                                                                                              //
                    };                                                                                                 //
                    xhr.open("GET", url, true);                                                                        // 1040
                                                                                                                       //
                    if (xhr.setRequestHeader) {                                                                        // 1042
                        xhr.setRequestHeader('Accept', 'application/x-es-module, */*');                                // 1043
                        // can set "authorization: true" to enable withCredentials only                                //
                        if (authorization) {                                                                           // 1045
                            if (typeof authorization == 'string') xhr.setRequestHeader('Authorization', authorization);
                            xhr.withCredentials = true;                                                                // 1048
                        }                                                                                              //
                    }                                                                                                  //
                                                                                                                       //
                    if (doTimeout) setTimeout(function () {                                                            // 1052
                        xhr.send();                                                                                    // 1054
                    }, 0);                                                                                             //
                                                                                                                       //
                    xhr.send(null);                                                                                    // 1057
                };                                                                                                     //
            } else if (typeof require != 'undefined') {                                                                //
                var fs;                                                                                                // 1061
                fetchTextFromURL = function (url, authorization, fulfill, reject) {                                    // 1062
                    if (url.substr(0, 8) != 'file:///') throw new Error('Unable to fetch "' + url + '". Only file URLs of the form file:/// allowed running in Node.');
                    fs = fs || require('fs');                                                                          // 1065
                    if (isWindows) url = url.replace(/\//g, '\\').substr(8);else url = url.substr(7);                  // 1066
                    return fs.readFile(url, function (err, data) {                                                     // 1070
                        if (err) {                                                                                     // 1071
                            return reject(err);                                                                        // 1072
                        } else {                                                                                       //
                            // Strip Byte Order Mark out if it's the leading char                                      //
                            var dataString = data + '';                                                                // 1076
                            if (dataString[0] === '﻿') dataString = dataString.substr(1);                              // 1077
                                                                                                                       //
                            fulfill(dataString);                                                                       // 1080
                        }                                                                                              //
                    });                                                                                                //
                };                                                                                                     //
            } else {                                                                                                   //
                throw new TypeError('No environment fetch API available.');                                            // 1086
            }                                                                                                          //
                                                                                                                       //
            SystemLoader.prototype.fetch = function (load) {                                                           // 1089
                return new Promise(function (resolve, reject) {                                                        // 1090
                    fetchTextFromURL(load.address, undefined, resolve, reject);                                        // 1091
                });                                                                                                    //
            };                                                                                                         //
            /*                                                                                                         //
             * Traceur, Babel and TypeScript transpile hook for Loader                                                 //
             */                                                                                                        //
            var transpile = (function () {                                                                             // 1097
                                                                                                                       //
                // use Traceur by default                                                                              //
                Loader.prototype.transpiler = 'traceur';                                                               // 1100
                                                                                                                       //
                function transpile(load) {                                                                             // 1102
                    var self = this;                                                                                   // 1103
                                                                                                                       //
                    return Promise.resolve(__global[self.transpiler == 'typescript' ? 'ts' : self.transpiler] || (self.pluginLoader || self)['import'](self.transpiler)).then(function (transpiler) {
                        if (transpiler.__useDefault) transpiler = transpiler['default'];                               // 1108
                                                                                                                       //
                        var transpileFunction;                                                                         // 1111
                        if (transpiler.Compiler) transpileFunction = traceurTranspile;else if (transpiler.createLanguageService) transpileFunction = typescriptTranspile;else transpileFunction = babelTranspile;
                                                                                                                       //
                        // note __moduleName will be part of the transformer meta in future when we have the spec for this
                        return '(function(__moduleName){' + transpileFunction.call(self, load, transpiler) + '\n})("' + load.name + '");\n//# sourceURL=' + load.address + '!transpiled';
                    });                                                                                                //
                };                                                                                                     //
                                                                                                                       //
                function traceurTranspile(load, traceur) {                                                             // 1124
                    var options = this.traceurOptions || {};                                                           // 1125
                    options.modules = 'instantiate';                                                                   // 1126
                    options.script = false;                                                                            // 1127
                    if (options.sourceMaps === undefined) options.sourceMaps = 'inline';                               // 1128
                    options.filename = load.address;                                                                   // 1130
                    options.inputSourceMap = load.metadata.sourceMap;                                                  // 1131
                    options.moduleName = false;                                                                        // 1132
                                                                                                                       //
                    var compiler = new traceur.Compiler(options);                                                      // 1134
                                                                                                                       //
                    return doTraceurCompile(load.source, compiler, options.filename);                                  // 1136
                }                                                                                                      //
                function doTraceurCompile(source, compiler, filename) {                                                // 1138
                    try {                                                                                              // 1139
                        return compiler.compile(source, filename);                                                     // 1140
                    } catch (e) {                                                                                      //
                        // traceur throws an error array                                                               //
                        throw e[0];                                                                                    // 1144
                    }                                                                                                  //
                }                                                                                                      //
                                                                                                                       //
                function babelTranspile(load, babel) {                                                                 // 1148
                    var options = this.babelOptions || {};                                                             // 1149
                    options.modules = 'system';                                                                        // 1150
                    if (options.sourceMap === undefined) options.sourceMap = 'inline';                                 // 1151
                    options.inputSourceMap = load.metadata.sourceMap;                                                  // 1153
                    options.filename = load.address;                                                                   // 1154
                    options.code = true;                                                                               // 1155
                    options.ast = false;                                                                               // 1156
                                                                                                                       //
                    return babel.transform(load.source, options).code;                                                 // 1158
                }                                                                                                      //
                                                                                                                       //
                function typescriptTranspile(load, ts) {                                                               // 1161
                    var options = this.typescriptOptions || {};                                                        // 1162
                    options.target = options.target || ts.ScriptTarget.ES5;                                            // 1163
                    if (options.sourceMap === undefined) options.sourceMap = true;                                     // 1164
                    if (options.sourceMap) options.inlineSourceMap = true;                                             // 1166
                                                                                                                       //
                    options.module = ts.ModuleKind.System;                                                             // 1169
                                                                                                                       //
                    return ts.transpile(load.source, options, load.address);                                           // 1171
                }                                                                                                      //
                                                                                                                       //
                return transpile;                                                                                      // 1174
            })();                                                                                                      //
            // we define a __exec for globally-scoped execution                                                        //
            // used by module format implementations                                                                   //
            var __exec;                                                                                                // 1178
                                                                                                                       //
            (function () {                                                                                             // 1180
                                                                                                                       //
                // System clobbering protection (mostly for Traceur)                                                   //
                var curSystem;                                                                                         // 1183
                function preExec(loader) {                                                                             // 1184
                    curSystem = __global.System;                                                                       // 1185
                    __global.System = loader;                                                                          // 1186
                }                                                                                                      //
                function postExec() {                                                                                  // 1188
                    __global.System = curSystem;                                                                       // 1189
                }                                                                                                      //
                                                                                                                       //
                var hasBtoa = typeof btoa != 'undefined';                                                              // 1192
                                                                                                                       //
                function getSource(load) {                                                                             // 1194
                    var lastLineIndex = load.source.lastIndexOf('\n');                                                 // 1195
                                                                                                                       //
                    return load.source                                                                                 // 1197
                    // adds the sourceURL comment if not already present                                               //
                     + (load.source.substr(lastLineIndex, 15) != '\n//# sourceURL=' ? '\n//# sourceURL=' + load.address + (load.metadata.sourceMap ? '!transpiled' : '') : '')
                    // add sourceMappingURL if load.metadata.sourceMap is set                                          //
                     + (load.metadata.sourceMap && hasBtoa && '\n//# sourceMappingURL=data:application/json;base64,' + btoa(unescape(encodeURIComponent(load.metadata.sourceMap))) || '');
                }                                                                                                      //
                                                                                                                       //
                // Web Worker and Chrome Extensions use original ESML eval                                             //
                // this may lead to some global module execution differences (eg var not defining onto global)         //
                if (isWorker || isBrowser && window.chrome && window.chrome.extension) {                               // 1208
                    __exec = function (load) {                                                                         // 1209
                        if (load.metadata.integrity) throw new Error('Subresource integrity checking is not supported in Web Workers or Chrome Extensions.');
                        try {                                                                                          // 1212
                            preExec(this);                                                                             // 1213
                            new Function(getSource(load)).call(__global);                                              // 1214
                            postExec();                                                                                // 1215
                        } catch (e) {                                                                                  //
                            throw addToError(e, 'Evaluating ' + load.address);                                         // 1218
                        }                                                                                              //
                    };                                                                                                 //
                }                                                                                                      //
                                                                                                                       //
                // use script injection eval to get identical global script behaviour                                  //
                else if (typeof document != 'undefined') {                                                             //
                        var head;                                                                                      // 1225
                                                                                                                       //
                        var scripts = document.getElementsByTagName('script');                                         // 1227
                        $__curScript = scripts[scripts.length - 1];                                                    // 1228
                                                                                                                       //
                        __exec = function (load) {                                                                     // 1230
                            if (!head) head = document.head || document.body || document.documentElement;              // 1231
                                                                                                                       //
                            var script = document.createElement('script');                                             // 1234
                            script.text = getSource(load);                                                             // 1235
                            var onerror = window.onerror;                                                              // 1236
                            var e;                                                                                     // 1237
                            window.onerror = function (_e) {                                                           // 1238
                                e = addToError(_e, 'Evaluating ' + load.address);                                      // 1239
                            };                                                                                         //
                            preExec(this);                                                                             // 1241
                                                                                                                       //
                            if (load.metadata.integrity) script.setAttribute('integrity', load.metadata.integrity);    // 1243
                            if (load.metadata.nonce) script.setAttribute('nonce', load.metadata.nonce);                // 1245
                                                                                                                       //
                            head.appendChild(script);                                                                  // 1248
                            head.removeChild(script);                                                                  // 1249
                            postExec();                                                                                // 1250
                            window.onerror = onerror;                                                                  // 1251
                            if (e) throw e;                                                                            // 1252
                        };                                                                                             //
                    } else {                                                                                           //
                        // global scoped eval for node                                                                 //
                        var vmModule = 'vm';                                                                           // 1258
                        var vm = require(vmModule);                                                                    // 1259
                        __exec = function (load) {                                                                     // 1260
                            if (load.metadata.integrity) throw new Error('Subresource integrity checking is unavailable in Node.');
                            try {                                                                                      // 1263
                                preExec(this);                                                                         // 1264
                                vm.runInThisContext(getSource(load));                                                  // 1265
                                postExec();                                                                            // 1266
                            } catch (e) {                                                                              //
                                throw addToError(e.toString(), 'Evaluating ' + load.address);                          // 1269
                            }                                                                                          //
                        };                                                                                             //
                    }                                                                                                  //
            })(); // SystemJS Loader Class and Extension helpers                                                       //
                                                                                                                       //
            function SystemJSLoader() {                                                                                // 1276
                SystemLoader.call(this);                                                                               // 1277
                                                                                                                       //
                systemJSConstructor.call(this);                                                                        // 1279
            }                                                                                                          //
                                                                                                                       //
            // inline Object.create-style class extension                                                              //
            function SystemProto() {};                                                                                 // 1283
            SystemProto.prototype = SystemLoader.prototype;                                                            // 1284
            SystemJSLoader.prototype = new SystemProto();                                                              // 1285
            SystemJSLoader.prototype.constructor = SystemJSLoader;                                                     // 1286
                                                                                                                       //
            var systemJSConstructor;                                                                                   // 1288
                                                                                                                       //
            function hook(name, hook) {                                                                                // 1290
                SystemJSLoader.prototype[name] = hook(SystemJSLoader.prototype[name]);                                 // 1291
            }                                                                                                          //
            function hookConstructor(hook) {                                                                           // 1293
                systemJSConstructor = hook(systemJSConstructor || function () {});                                     // 1294
            }                                                                                                          //
                                                                                                                       //
            function dedupe(deps) {                                                                                    // 1297
                var newDeps = [];                                                                                      // 1298
                for (var i = 0, l = deps.length; i < l; i++) if (indexOf.call(newDeps, deps[i]) == -1) newDeps.push(deps[i]);
                return newDeps;                                                                                        // 1302
            }                                                                                                          //
                                                                                                                       //
            function group(deps) {                                                                                     // 1305
                var names = [];                                                                                        // 1306
                var indices = [];                                                                                      // 1307
                for (var i = 0, l = deps.length; i < l; i++) {                                                         // 1308
                    var index = indexOf.call(names, deps[i]);                                                          // 1309
                    if (index === -1) {                                                                                // 1310
                        names.push(deps[i]);                                                                           // 1311
                        indices.push([i]);                                                                             // 1312
                    } else {                                                                                           //
                        indices[index].push(i);                                                                        // 1315
                    }                                                                                                  //
                }                                                                                                      //
                return { names: names, indices: indices };                                                             // 1318
            }                                                                                                          //
                                                                                                                       //
            var getOwnPropertyDescriptor = true;                                                                       // 1321
            try {                                                                                                      // 1322
                Object.getOwnPropertyDescriptor({ a: 0 }, 'a');                                                        // 1323
            } catch (e) {                                                                                              //
                getOwnPropertyDescriptor = false;                                                                      // 1326
            }                                                                                                          //
                                                                                                                       //
            // converts any module.exports object into an object ready for System.newModule                            //
            function getESModule(exports) {                                                                            // 1330
                var esModule = {};                                                                                     // 1331
                // don't trigger getters/setters in environments that support them                                     //
                if (typeof exports == 'object' || typeof exports == 'function') {                                      // 1333
                    if (getOwnPropertyDescriptor) {                                                                    // 1334
                        var d;                                                                                         // 1335
                        for (var p in babelHelpers.sanitizeForInObject(exports)) if (d = Object.getOwnPropertyDescriptor(exports, p)) defineProperty(esModule, p, d);
                    } else {                                                                                           //
                        var hasOwnProperty = exports && exports.hasOwnProperty;                                        // 1341
                        for (var p in babelHelpers.sanitizeForInObject(exports)) {                                     // 1342
                            if (!hasOwnProperty || exports.hasOwnProperty(p)) esModule[p] = exports[p];                // 1343
                        }                                                                                              //
                    }                                                                                                  //
                }                                                                                                      //
                esModule['default'] = exports;                                                                         // 1348
                defineProperty(esModule, '__useDefault', {                                                             // 1349
                    value: true                                                                                        // 1350
                });                                                                                                    //
                return esModule;                                                                                       // 1352
            }                                                                                                          //
                                                                                                                       //
            function extend(a, b, prepend) {                                                                           // 1355
                for (var p in babelHelpers.sanitizeForInObject(b)) {                                                   // 1356
                    if (!prepend || !(p in a)) a[p] = b[p];                                                            // 1357
                }                                                                                                      //
                return a;                                                                                              // 1360
            }                                                                                                          //
                                                                                                                       //
            // package configuration options                                                                           //
            var packageProperties = ['main', 'format', 'defaultExtension', 'meta', 'map', 'basePath', 'depCache'];     // 1364
                                                                                                                       //
            // meta first-level extends where:                                                                         //
            // array + array appends                                                                                   //
            // object + object extends                                                                                 //
            // other properties replace                                                                                //
            function extendMeta(a, b, prepend) {                                                                       // 1370
                for (var p in babelHelpers.sanitizeForInObject(b)) {                                                   // 1371
                    var val = b[p];                                                                                    // 1372
                    if (!(p in a)) a[p] = val;else if (val instanceof Array && a[p] instanceof Array) a[p] = [].concat(prepend ? val : a[p]).concat(prepend ? a[p] : val);else if (typeof val == 'object' && typeof a[p] == 'object') a[p] = extend(extend({}, a[p]), val, prepend);else if (!prepend) a[p] = val;
                }                                                                                                      //
            }                                                                                                          //
                                                                                                                       //
            function warn(msg) {                                                                                       // 1384
                if (this.warnings && typeof console != 'undefined' && console.warn) console.warn(msg);                 // 1385
            } /*                                                                                                       //
              SystemJS map support                                                                                     //
               Provides map configuration through                                                                      //
              System.map['jquery'] = 'some/module/map'                                                                 //
               Note that this applies for subpaths, just like RequireJS:                                               //
               jquery      -> 'some/module/map'                                                                        //
              jquery/path -> 'some/module/map/path'                                                                    //
              bootstrap   -> 'bootstrap'                                                                               //
               The most specific map is always taken, as longest path length                                           //
              */                                                                                                       //
            hookConstructor(function (constructor) {                                                                   // 1401
                return function () {                                                                                   // 1402
                    constructor.call(this);                                                                            // 1403
                    this.map = {};                                                                                     // 1404
                };                                                                                                     //
            });                                                                                                        //
                                                                                                                       //
            hook('normalize', function () {                                                                            // 1408
                return function (name, parentName) {                                                                   // 1409
                    if (name.substr(0, 1) != '.' && name.substr(0, 1) != '/' && !name.match(absURLRegEx)) {            // 1410
                        var bestMatch,                                                                                 // 1411
                            bestMatchLength = 0;                                                                       //
                                                                                                                       //
                        // now do the global map                                                                       //
                        for (var p in babelHelpers.sanitizeForInObject(this.map)) {                                    // 1414
                            if (name.substr(0, p.length) == p && (name.length == p.length || name[p.length] == '/')) {
                                var curMatchLength = p.split('/').length;                                              // 1416
                                if (curMatchLength <= bestMatchLength) continue;                                       // 1417
                                bestMatch = p;                                                                         // 1419
                                bestMatchLength = curMatchLength;                                                      // 1420
                            }                                                                                          //
                        }                                                                                              //
                                                                                                                       //
                        if (bestMatch) name = this.map[bestMatch] + name.substr(bestMatch.length);                     // 1424
                    }                                                                                                  //
                                                                                                                       //
                    // map is the first normalizer                                                                     //
                    return name;                                                                                       // 1429
                };                                                                                                     //
            });                                                                                                        //
            var absURLRegEx = /^[^\/]+:\/\//;                                                                          // 1432
                                                                                                                       //
            function readMemberExpression(p, value) {                                                                  // 1434
                var pParts = p.split('.');                                                                             // 1435
                while (pParts.length) value = value[pParts.shift()];                                                   // 1436
                return value;                                                                                          // 1438
            }                                                                                                          //
                                                                                                                       //
            var baseURLCache = {};                                                                                     // 1441
            function getBaseURLObj() {                                                                                 // 1442
                if (baseURLCache[this.baseURL]) return baseURLCache[this.baseURL];                                     // 1443
                                                                                                                       //
                // normalize baseURL if not already                                                                    //
                if (this.baseURL[this.baseURL.length - 1] != '/') this.baseURL += '/';                                 // 1447
                                                                                                                       //
                var baseURL = new URL(this.baseURL, baseURI);                                                          // 1450
                                                                                                                       //
                this.baseURL = baseURL.href;                                                                           // 1452
                                                                                                                       //
                return baseURLCache[this.baseURL] = baseURL;                                                           // 1454
            }                                                                                                          //
                                                                                                                       //
            var baseURIObj = new URL(baseURI);                                                                         // 1457
                                                                                                                       //
            hookConstructor(function (constructor) {                                                                   // 1459
                return function () {                                                                                   // 1460
                    constructor.call(this);                                                                            // 1461
                                                                                                                       //
                    // support baseURL                                                                                 //
                    this.baseURL = baseURI.substr(0, baseURI.lastIndexOf('/') + 1);                                    // 1464
                                                                                                                       //
                    // support the empty module, as a concept                                                          //
                    this.set('@empty', this.newModule({}));                                                            // 1467
                                                                                                                       //
                    // include the node require since we're overriding it                                              //
                    if (typeof require != 'undefined' && require.resolve && typeof process != 'undefined') this._nodeRequire = require;
                };                                                                                                     //
            });                                                                                                        //
                                                                                                                       //
            /*                                                                                                         //
             Normalization                                                                                             //
              If a name is relative, we apply URL normalization to the page                                            //
             If a name is an absolute URL, we leave it as-is                                                           //
              Plain names (neither of the above) run through the map and package                                       //
             normalization phases (applying before and after this one).                                                //
              The paths normalization phase applies last (paths extension), which                                      //
             defines the `normalizeSync` function and normalizes everything into                                       //
             a URL.                                                                                                    //
              The final normalization                                                                                  //
             */                                                                                                        //
                                                                                                                       //
            hook('normalize', function (normalize) {                                                                   // 1491
                return function (name, parentName) {                                                                   // 1492
                    // dynamically load node-core modules when requiring `@node/fs` for example                        //
                    if (name.substr(0, 6) == '@node/') {                                                               // 1494
                        if (!this._nodeRequire) throw new TypeError('Can only load node core modules in Node.');       // 1495
                        this.set(name, this.newModule(getESModule(this._nodeRequire(name.substr(6)))));                // 1497
                    }                                                                                                  //
                                                                                                                       //
                    // first run map config                                                                            //
                    name = normalize.apply(this, arguments);                                                           // 1501
                                                                                                                       //
                    // relative URL-normalization                                                                      //
                    if (name[0] == '.' || name[0] == '/') return new URL(name, parentName || baseURIObj).href;         // 1504
                    return name;                                                                                       // 1506
                };                                                                                                     //
            });                                                                                                        //
                                                                                                                       //
            // percent encode just '#' in urls                                                                         //
            hook('locate', function (locate) {                                                                         // 1511
                return function (load) {                                                                               // 1512
                    return Promise.resolve(locate.call(this, load)).then(function (address) {                          // 1513
                        return address.replace(/#/g, '%23');                                                           // 1515
                    });                                                                                                //
                };                                                                                                     //
            });                                                                                                        //
                                                                                                                       //
            /*                                                                                                         //
             * Fetch with authorization                                                                                //
             */                                                                                                        //
            hook('fetch', function () {                                                                                // 1523
                return function (load) {                                                                               // 1524
                    return new Promise(function (resolve, reject) {                                                    // 1525
                        fetchTextFromURL(load.address, load.metadata.authorization, resolve, reject);                  // 1526
                    });                                                                                                //
                };                                                                                                     //
            });                                                                                                        //
                                                                                                                       //
            /*                                                                                                         //
             __useDefault                                                                                              //
              When a module object looks like:                                                                         //
             newModule(                                                                                                //
             __useDefault: true,                                                                                       //
             default: 'some-module'                                                                                    //
             })                                                                                                        //
              Then importing that module provides the 'some-module'                                                    //
             result directly instead of the full module.                                                               //
              Useful for eg module.exports = function() {}                                                             //
             */                                                                                                        //
            hook('import', function (systemImport) {                                                                   // 1545
                return function (name, parentName, parentAddress) {                                                    // 1546
                    if (parentName && parentName.name) warn.call(this, 'System.import(name, { name: parentName }) is deprecated for System.import(name, parentName), while importing ' + name + ' from ' + parentName.name);
                    return systemImport.call(this, name, parentName, parentAddress).then(function (module) {           // 1549
                        return module.__useDefault ? module['default'] : module;                                       // 1550
                    });                                                                                                //
                };                                                                                                     //
            });                                                                                                        //
                                                                                                                       //
            /*                                                                                                         //
             Extend config merging one deep only                                                                       //
              loader.config({                                                                                          //
             some: 'random',                                                                                           //
             config: 'here',                                                                                           //
             deep: {                                                                                                   //
             config: { too: 'too' }                                                                                    //
             }                                                                                                         //
             });                                                                                                       //
              <=>                                                                                                      //
              loader.some = 'random';                                                                                  //
             loader.config = 'here'                                                                                    //
             loader.deep = loader.deep || {};                                                                          //
             loader.deep.config = { too: 'too' };                                                                      //
               Normalizes meta and package configs allowing for:                                                       //
              System.config({                                                                                          //
             meta: {                                                                                                   //
             './index.js': {}                                                                                          //
             }                                                                                                         //
             });                                                                                                       //
              To become                                                                                                //
              System.meta['https://thissite.com/index.js'] = {};                                                       //
              For easy normalization canonicalization with latest URL support.                                         //
              */                                                                                                       //
            SystemJSLoader.prototype.warnings = false;                                                                 // 1589
            SystemJSLoader.prototype.config = function (cfg) {                                                         // 1590
                if ('warnings' in cfg) this.warnings = cfg.warnings;                                                   // 1591
                                                                                                                       //
                // always configure baseURL first                                                                      //
                if (cfg.baseURL) {                                                                                     // 1595
                    var hasConfig = false;                                                                             // 1596
                    function checkHasConfig(obj) {                                                                     // 1597
                        for (var p in babelHelpers.sanitizeForInObject(obj)) return true;                              // 1598
                    }                                                                                                  //
                    if (checkHasConfig(this.packages) || checkHasConfig(this.meta) || checkHasConfig(this.depCache) || checkHasConfig(this.bundles)) throw new TypeError('baseURL should only be configured once and must be configured first.');
                                                                                                                       //
                    this.baseURL = cfg.baseURL;                                                                        // 1604
                                                                                                                       //
                    // sanitize baseURL                                                                                //
                    getBaseURLObj.call(this);                                                                          // 1607
                }                                                                                                      //
                                                                                                                       //
                if (cfg.defaultJSExtensions) {                                                                         // 1610
                    this.defaultJSExtensions = cfg.defaultJSExtensions;                                                // 1611
                    warn.call(this, 'The defaultJSExtensions configuration option is deprecated, use packages configuration instead.');
                }                                                                                                      //
                                                                                                                       //
                if (cfg.pluginFirst) this.pluginFirst = cfg.pluginFirst;                                               // 1615
                                                                                                                       //
                if (cfg.paths) {                                                                                       // 1618
                    for (var p in babelHelpers.sanitizeForInObject(cfg.paths)) this.paths[p] = cfg.paths[p];           // 1619
                }                                                                                                      //
                                                                                                                       //
                if (cfg.map) {                                                                                         // 1623
                    var objMaps = '';                                                                                  // 1624
                    for (var p in babelHelpers.sanitizeForInObject(cfg.map)) {                                         // 1625
                        var v = cfg.map[p];                                                                            // 1626
                                                                                                                       //
                        // object map backwards-compat into packages configuration                                     //
                        if (typeof v !== 'string') {                                                                   // 1629
                            objMaps += (objMaps.length ? ', ' : '') + '"' + p + '"';                                   // 1630
                            var normalized = this.normalizeSync(p);                                                    // 1631
                                                                                                                       //
                            // if doing default js extensions, undo to get package name                                //
                            if (this.defaultJSExtensions && p.substr(p.length - 3, 3) != '.js') normalized = normalized.substr(0, normalized.length - 3);
                                                                                                                       //
                            // if a package main, revert it                                                            //
                            var pkgMatch = '';                                                                         // 1638
                            for (var pkg in babelHelpers.sanitizeForInObject(this.packages)) {                         // 1639
                                if (normalized.substr(0, pkg.length) == pkg && (!normalized[pkg.length] || normalized[pkg.length] == '/') && pkgMatch.split('/').length < pkg.split('/').length) pkgMatch = pkg;
                            }                                                                                          //
                            if (pkgMatch && this.packages[pkgMatch].main) normalized = normalized.substr(0, normalized.length - this.packages[pkgMatch].main.length - 1);
                                                                                                                       //
                            var pkg = this.packages[normalized] = this.packages[normalized] || {};                     // 1648
                            pkg.map = v;                                                                               // 1649
                        } else {                                                                                       //
                            this.map[p] = v;                                                                           // 1652
                        }                                                                                              //
                    }                                                                                                  //
                    if (objMaps) warn.call(this, 'The map configuration for ' + objMaps + ' uses object submaps, which is deprecated in global map.\nUpdate this to use package contextual map with configs like System.config({ packages: { "' + p + '": { map: {...} } } }).');
                }                                                                                                      //
                                                                                                                       //
                if (cfg.packageConfigPaths) {                                                                          // 1659
                    var packageConfigPaths = [];                                                                       // 1660
                    for (var i = 0; i < cfg.packageConfigPaths.length; i++) {                                          // 1661
                        var path = cfg.packageConfigPaths[i];                                                          // 1662
                        var packageLength = Math.max(path.lastIndexOf('*') + 1, path.lastIndexOf('/'));                // 1663
                        var normalized = this.normalizeSync(path.substr(0, packageLength) + '/');                      // 1664
                        if (this.defaultJSExtensions && path.substr(path.length - 3, 3) != '.js') normalized = normalized.substr(0, normalized.length - 3);
                        packageConfigPaths[i] = normalized.substr(0, normalized.length - 1) + path.substr(packageLength);
                    }                                                                                                  //
                    this.packageConfigPaths = packageConfigPaths;                                                      // 1669
                }                                                                                                      //
                                                                                                                       //
                if (cfg.packages) {                                                                                    // 1672
                    for (var p in babelHelpers.sanitizeForInObject(cfg.packages)) {                                    // 1673
                        if (p.match(/^([^\/]+:)?\/\/$/)) throw new TypeError('"' + p + '" is not a valid package name.');
                                                                                                                       //
                        // request with trailing "/" to get package name exactly                                       //
                        var prop = this.normalizeSync(p + (p[p.length - 1] != '/' ? '/' : ''));                        // 1678
                        prop = prop.substr(0, prop.length - 1);                                                        // 1679
                                                                                                                       //
                        // if doing default js extensions, undo to get package name                                    //
                        if (this.defaultJSExtensions && p.substr(p.length - 3, 3) != '.js') prop = prop.substr(0, prop.length - 3);
                                                                                                                       //
                        this.packages[prop] = this.packages[prop] || {};                                               // 1685
                        for (var q in babelHelpers.sanitizeForInObject(cfg.packages[p])) if (indexOf.call(packageProperties, q) == -1) warn.call(this, '"' + q + '" is not a valid package configuration option in package ' + p);
                                                                                                                       //
                        extendMeta(this.packages[prop], cfg.packages[p]);                                              // 1690
                    }                                                                                                  //
                }                                                                                                      //
                                                                                                                       //
                if (cfg.bundles) {                                                                                     // 1694
                    for (var p in babelHelpers.sanitizeForInObject(cfg.bundles)) {                                     // 1695
                        var bundle = [];                                                                               // 1696
                        for (var i = 0; i < cfg.bundles[p].length; i++) bundle.push(this.normalizeSync(cfg.bundles[p][i]));
                        this.bundles[p] = bundle;                                                                      // 1699
                    }                                                                                                  //
                }                                                                                                      //
                                                                                                                       //
                for (var c in babelHelpers.sanitizeForInObject(cfg)) {                                                 // 1703
                    var v = cfg[c];                                                                                    // 1704
                    var normalizeProp = false,                                                                         // 1705
                        normalizeValArray = false;                                                                     //
                                                                                                                       //
                    if (c == 'baseURL' || c == 'map' || c == 'packages' || c == 'bundles' || c == 'paths' || c == 'warnings' || c == 'packageConfigPaths') continue;
                                                                                                                       //
                    if (typeof v != 'object' || v instanceof Array) {                                                  // 1710
                        this[c] = v;                                                                                   // 1711
                    } else {                                                                                           //
                        this[c] = this[c] || {};                                                                       // 1714
                                                                                                                       //
                        if (c == 'meta' || c == 'depCache') normalizeProp = true;                                      // 1716
                                                                                                                       //
                        for (var p in babelHelpers.sanitizeForInObject(v)) {                                           // 1719
                            if (c == 'meta' && p[0] == '*') this[c][p] = v[p];else if (normalizeProp) this[c][this.normalizeSync(p)] = v[p];else this[c][p] = v[p];
                        }                                                                                              //
                    }                                                                                                  //
                }                                                                                                      //
            }; /*                                                                                                      //
               * Paths extension                                                                                       //
               *                                                                                                       //
               * Applies paths and normalizes to a full URL                                                            //
               */                                                                                                      //
            hook('normalize', function (normalize) {                                                                   // 1734
                return function (name, parentName) {                                                                   // 1735
                    var normalized = normalize.apply(this, arguments);                                                 // 1736
                                                                                                                       //
                    // if the module is in the registry already, use that                                              //
                    if (this.has(normalized)) return normalized;                                                       // 1739
                                                                                                                       //
                    if (normalized.match(absURLRegEx)) {                                                               // 1742
                        // defaultJSExtensions backwards compatibility                                                 //
                        if (this.defaultJSExtensions && normalized.substr(normalized.length - 3, 3) != '.js') normalized += '.js';
                        return normalized;                                                                             // 1746
                    }                                                                                                  //
                                                                                                                       //
                    // applyPaths implementation provided from ModuleLoader system.js source                           //
                    normalized = applyPaths(this.paths, normalized) || normalized;                                     // 1750
                                                                                                                       //
                    // defaultJSExtensions backwards compatibility                                                     //
                    if (this.defaultJSExtensions && normalized.substr(normalized.length - 3, 3) != '.js') normalized += '.js';
                                                                                                                       //
                    // ./x, /x -> page-relative                                                                        //
                    if (normalized[0] == '.' || normalized[0] == '/') return new URL(normalized, baseURIObj).href;     // 1757
                    // x -> baseURL-relative                                                                           //
                    else return new URL(normalized, getBaseURLObj.call(this)).href;                                    //
                };                                                                                                     //
            }); /*                                                                                                     //
                * Package Configuration Extension                                                                      //
                *                                                                                                      //
                * Example:                                                                                             //
                *                                                                                                      //
                * System.packages = {                                                                                  //
                *   jquery: {                                                                                          //
                *     basePath: 'lib', // optionally only use a subdirectory within the package                        //
                *     main: 'index.js', // when not set, package name is requested directly                            //
                *     format: 'amd',                                                                                   //
                *     defaultExtension: 'ts', // defaults to 'js', can be set to false                                 //
                *     meta: {                                                                                          //
                *       '*.ts': {                                                                                      //
                *         loader: 'typescript'                                                                         //
                *       },                                                                                             //
                *       'vendor/sizzle.js': {                                                                          //
                *         format: 'global'                                                                             //
                *       }                                                                                              //
                *     },                                                                                               //
                *     map: {                                                                                           //
                *        // map internal require('sizzle') to local require('./vendor/sizzle')                         //
                *        sizzle: './vendor/sizzle.js',                                                                 //
                *        // map any internal or external require of 'jquery/vendor/another' to 'another/index.js'      //
                *        './vendor/another.js': './another/index.js',                                                  //
                *        // test.js / test -> lib/test.js                                                              //
                *        './test.js': './lib/test.js',                                                                 //
                *                                                                                                      //
                *        // environment-specific map configurations                                                    //
                *        './index.js': {                                                                               //
                *          '~browser': './index-node.js'                                                               //
                *        }                                                                                             //
                *     },                                                                                               //
                *     // allows for setting package-prefixed depCache                                                  //
                *     // keys are normalized module names relative to the package itself                               //
                *     depCache: {                                                                                      //
                *       // import 'package/index.js' loads in parallel package/lib/test.js,package/vendor/sizzle.js    //
                *       './index.js': ['./test'],                                                                      //
                *       './test.js': ['sizzle']                                                                        //
                *     }                                                                                                //
                *   }                                                                                                  //
                * };                                                                                                   //
                *                                                                                                      //
                * Then:                                                                                                //
                *   import 'jquery'                       -> jquery/index.js                                           //
                *   import 'jquery/submodule'             -> jquery/submodule.js                                       //
                *   import 'jquery/submodule.ts'          -> jquery/submodule.ts loaded as typescript                  //
                *   import 'jquery/vendor/another'        -> another/index.js                                          //
                *                                                                                                      //
                * Detailed Behaviours                                                                                  //
                * - main can have a leading "./" can be added optionally                                               //
                * - map and defaultExtension are applied to the main                                                   //
                * - defaultExtension adds the extension only if no other extension is present                          //
                * - defaultJSExtensions applies after map when defaultExtension is not set                             //
                * - if a meta value is available for a module, map and defaultExtension are skipped                    //
                * - like global map, package map also applies to subpaths (sizzle/x, ./vendor/another/sub)             //
                * - condition module map is '@env' module in package or '@system-env' globally                         //
                *                                                                                                      //
                * In addition, the following meta properties will be allowed to be package                             //
                * -relative as well in the package meta config:                                                        //
                *                                                                                                      //
                *   - loader                                                                                           //
                *   - alias                                                                                            //
                *                                                                                                      //
                *                                                                                                      //
                * Package Configuration Loading                                                                        //
                *                                                                                                      //
                * Not all packages may already have their configuration present in the System config                   //
                * For these cases, a list of packageConfigPaths can be provided, which when matched against            //
                * a request, will first request a ".json" file by the package name to derive the package               //
                * configuration from. This allows dynamic loading of non-predetermined code, a key use                 //
                * case in SystemJS.                                                                                    //
                *                                                                                                      //
                * Example:                                                                                             //
                *                                                                                                      //
                *   System.packageConfigPaths = ['packages/test/package.json', 'packages/*.json'];                     //
                *                                                                                                      //
                *   // will first request 'packages/new-package/package.json' for the package config                   //
                *   // before completing the package request to 'packages/new-package/path'                            //
                *   System.import('packages/new-package/path');                                                        //
                *                                                                                                      //
                *   // will first request 'packages/test/package.json' before the main                                 //
                *   System.import('packages/test');                                                                    //
                *                                                                                                      //
                * When a package matches packageConfigPaths, it will always send a config request for                  //
                * the package configuration.                                                                           //
                * The package name itself is taken to be the match up to and including the last wildcard               //
                * or trailing slash.                                                                                   //
                * Package config paths are ordered - matching is done based on the first match found.                  //
                * Any existing package configurations for the package will deeply merge with the                       //
                * package config, with the existing package configurations taking preference.                          //
                * To opt-out of the package configuration request for a package that matches                           //
                * packageConfigPaths, use the { configured: true } package config option.                              //
                *                                                                                                      //
                */                                                                                                     //
            (function () {                                                                                             // 1857
                                                                                                                       //
                hookConstructor(function (constructor) {                                                               // 1859
                    return function () {                                                                               // 1860
                        constructor.call(this);                                                                        // 1861
                        this.packages = {};                                                                            // 1862
                        this.packageConfigPaths = {};                                                                  // 1863
                    };                                                                                                 //
                });                                                                                                    //
                                                                                                                       //
                function getPackage(name) {                                                                            // 1867
                    // use most specific package                                                                       //
                    var curPkg,                                                                                        // 1869
                        curPkgLen = 0,                                                                                 //
                        pkgLen;                                                                                        //
                    for (var p in babelHelpers.sanitizeForInObject(this.packages)) {                                   // 1870
                        if (name.substr(0, p.length) === p && (name.length === p.length || name[p.length] === '/')) {  // 1871
                            pkgLen = p.split('/').length;                                                              // 1872
                            if (pkgLen > curPkgLen) {                                                                  // 1873
                                curPkg = p;                                                                            // 1874
                                curPkgLen = pkgLen;                                                                    // 1875
                            }                                                                                          //
                        }                                                                                              //
                    }                                                                                                  //
                    return curPkg;                                                                                     // 1879
                }                                                                                                      //
                                                                                                                       //
                function applyMap(map, name) {                                                                         // 1882
                    var bestMatch,                                                                                     // 1883
                        bestMatchLength = 0;                                                                           //
                                                                                                                       //
                    for (var p in babelHelpers.sanitizeForInObject(map)) {                                             // 1885
                        if (name.substr(0, p.length) == p && (name.length == p.length || name[p.length] == '/')) {     // 1886
                            var curMatchLength = p.split('/').length;                                                  // 1887
                            if (curMatchLength <= bestMatchLength) continue;                                           // 1888
                            bestMatch = p;                                                                             // 1890
                            bestMatchLength = curMatchLength;                                                          // 1891
                        }                                                                                              //
                    }                                                                                                  //
                                                                                                                       //
                    return bestMatch;                                                                                  // 1895
                }                                                                                                      //
                                                                                                                       //
                function getBasePath(pkg) {                                                                            // 1898
                    // sanitize basePath                                                                               //
                    var basePath = pkg.basePath && pkg.basePath != '.' ? pkg.basePath : '';                            // 1900
                    if (basePath) {                                                                                    // 1901
                        if (basePath.substr(0, 2) == './') basePath = basePath.substr(2);                              // 1902
                        if (basePath[basePath.length - 1] != '/') basePath += '/';                                     // 1904
                    }                                                                                                  //
                    return basePath;                                                                                   // 1907
                }                                                                                                      //
                                                                                                                       //
                // given the package subpath, return the resultant combined path                                       //
                // defaultExtension is only added if the path does not have                                            //
                // loader package meta or exact package meta                                                           //
                // We also re-incorporate package-level conditional syntax at this point                               //
                // allowing package map and package mains to point to conditionals                                     //
                // when conditionals are present,                                                                      //
                function toPackagePath(loader, pkgName, pkg, basePath, subPath, sync, isPlugin) {                      // 1916
                    // skip if its a plugin call already, or we have boolean / interpolation conditional syntax in subPath
                    var skipExtension = !!(isPlugin || subPath.indexOf('#?') != -1 || subPath.match(interpolationRegEx));
                                                                                                                       //
                    // exact meta or meta with any content after the last wildcard skips extension                     //
                    if (!skipExtension && pkg.meta) getMetaMatches(pkg.meta, pkgName, subPath, function (metaPattern, matchMeta, matchDepth) {
                        if (matchDepth == 0 || metaPattern.lastIndexOf('*') != metaPattern.length - 1) skipExtension = true;
                    });                                                                                                //
                                                                                                                       //
                    var normalized = pkgName + '/' + basePath + subPath + (skipExtension ? '' : getDefaultExtension(pkg, subPath));
                                                                                                                       //
                    return sync ? normalized : booleanConditional.call(loader, normalized, pkgName + '/').then(function (name) {
                        return interpolateConditional.call(loader, name, pkgName + '/');                               // 1930
                    });                                                                                                //
                }                                                                                                      //
                                                                                                                       //
                function getDefaultExtension(pkg, subPath) {                                                           // 1934
                    // don't apply extensions to folders or if defaultExtension = false                                //
                    if (subPath[subPath.length - 1] != '/' && pkg.defaultExtension !== false) {                        // 1936
                        // work out what the defaultExtension is and add if not there already                          //
                        var defaultExtension = '.' + (pkg.defaultExtension || 'js');                                   // 1938
                        if (subPath.substr(subPath.length - defaultExtension.length) != defaultExtension) return defaultExtension;
                    }                                                                                                  //
                    return '';                                                                                         // 1942
                }                                                                                                      //
                                                                                                                       //
                function applyPackageConfig(normalized, pkgName, pkg, sync, isPlugin) {                                // 1945
                    var loader = this;                                                                                 // 1946
                                                                                                                       //
                    var basePath = getBasePath(pkg);                                                                   // 1948
                                                                                                                       //
                    // main                                                                                            //
                    // NB can add a default package main convention here                                               //
                    if (pkgName === normalized && pkg.main) normalized += '/' + (pkg.main.substr(0, 2) == './' ? pkg.main.substr(2) : pkg.main);
                                                                                                                       //
                    // allow for direct package name normalization with trailling "/" (no main)                        //
                    if (normalized.length == pkgName.length + 1 && normalized[pkgName.length] == '/') return normalized;
                                                                                                                       //
                    // no submap if name is package itself                                                             //
                    if (normalized.length == pkgName.length) return normalized + (loader.defaultJSExtensions && normalized.substr(normalized.length - 3, 3) != '.js' ? '.js' : '');
                                                                                                                       //
                    // apply map, checking without then with defaultExtension                                          //
                    if (pkg.map) {                                                                                     // 1964
                        var subPath = '.' + normalized.substr(pkgName.length);                                         // 1965
                        var map = applyMap(pkg.map, subPath) || !isPlugin && applyMap(pkg.map, subPath += getDefaultExtension(pkg, subPath.substr(2)));
                        var mapped = pkg.map[map];                                                                     // 1967
                    }                                                                                                  //
                                                                                                                       //
                    function doMap(mapped) {                                                                           // 1970
                        // '.' as a target is the package itself (with package main check)                             //
                        if (mapped == '.') return pkgName;                                                             // 1972
                        // internal package map                                                                        //
                        else if (mapped.substr(0, 2) == './') return toPackagePath(loader, pkgName, pkg, basePath, mapped.substr(2), sync, isPlugin);
                            // global package map                                                                      //
                            else return (sync ? loader.normalizeSync : loader.normalize).call(loader, mapped);         //
                    }                                                                                                  //
                                                                                                                       //
                    // apply non-environment map match                                                                 //
                    if (typeof mapped == 'string') return doMap(mapped + subPath.substr(map.length));                  // 1983
                                                                                                                       //
                    // sync normalize does not apply environment map                                                   //
                    if (sync || !mapped) return toPackagePath(loader, pkgName, pkg, basePath, normalized.substr(pkgName.length + 1), sync, isPlugin);
                                                                                                                       //
                    // environment map build support                                                                   //
                    // -> we return [package-name]#[conditional-map] ("jquery#:index.js" in example above)             //
                    //    to indicate this unique conditional branch to builder in all of its possibilities            //
                    if (loader.builder) return pkgName + '#:' + map.substr(2);                                         // 1993
                                                                                                                       //
                    // environment map                                                                                 //
                    return loader['import'](pkg.map['@env'] || '@system-env', pkgName).then(function (env) {           // 1997
                        // first map condition to match is used                                                        //
                        for (var e in babelHelpers.sanitizeForInObject(mapped)) {                                      // 2000
                            var negate = e[0] == '~';                                                                  // 2001
                                                                                                                       //
                            var value = readMemberExpression(negate ? e.substr(1) : e, env);                           // 2003
                                                                                                                       //
                            if (!negate && value || negate && !value) return mapped[e] + subPath.substr(map.length);   // 2005
                        }                                                                                              //
                    }).then(function (mapped) {                                                                        //
                        // no environment match                                                                        //
                        if (!mapped) return toPackagePath(loader, pkgName, pkg, basePath, normalized.substr(pkgName.length + 1), sync, isPlugin);else return doMap(mapped);
                    });                                                                                                //
                }                                                                                                      //
                                                                                                                       //
                function createPackageNormalize(normalize, sync) {                                                     // 2018
                    return function (name, parentName, isPlugin) {                                                     // 2019
                        isPlugin = isPlugin === true;                                                                  // 2020
                                                                                                                       //
                        // apply contextual package map first                                                          //
                        if (parentName) var parentPackage = getPackage.call(this, parentName) || this.defaultJSExtensions && parentName.substr(parentName.length - 3, 3) == '.js' && getPackage.call(this, parentName.substr(0, parentName.length - 3));
                                                                                                                       //
                        if (parentPackage) {                                                                           // 2028
                            // remove any parent package base path for normalization                                   //
                            var parentBasePath = getBasePath(this.packages[parentPackage]);                            // 2030
                            if (parentBasePath && parentName.substr(parentPackage.length + 1, parentBasePath.length) == parentBasePath) parentName = parentPackage + parentName.substr(parentPackage.length + parentBasePath.length);
                                                                                                                       //
                            if (name[0] !== '.') {                                                                     // 2034
                                var parentMap = this.packages[parentPackage].map;                                      // 2035
                                if (parentMap) {                                                                       // 2036
                                    var map = applyMap(parentMap, name);                                               // 2037
                                    if (map) {                                                                         // 2038
                                        name = parentMap[map] + name.substr(map.length);                               // 2039
                                        // relative maps are package-relative                                          //
                                        if (name[0] === '.') parentName = parentPackage + '/';                         // 2041
                                    }                                                                                  //
                                }                                                                                      //
                            }                                                                                          //
                        }                                                                                              //
                                                                                                                       //
                        var defaultJSExtension = this.defaultJSExtensions && name.substr(name.length - 3, 3) != '.js';
                                                                                                                       //
                        // apply map, core, paths                                                                      //
                        var normalized = normalize.call(this, name, parentName);                                       // 2051
                                                                                                                       //
                        // undo defaultJSExtension                                                                     //
                        if (defaultJSExtension && normalized.substr(normalized.length - 3, 3) != '.js') defaultJSExtension = false;
                        if (defaultJSExtension) normalized = normalized.substr(0, normalized.length - 3);              // 2056
                                                                                                                       //
                        // if we requested a relative path, and got the package name, remove the trailing '/' to apply main
                        // that is normalize('pkg/') does not apply main, while normalize('./', 'pkg/') does           //
                        if (parentPackage && name[0] == '.' && normalized == parentPackage + '/') normalized = parentPackage;
                                                                                                                       //
                        var loader = this;                                                                             // 2064
                                                                                                                       //
                        function packageResolution(normalized, pkgName, pkg) {                                         // 2066
                            // check if we are inside a package                                                        //
                            pkgName = pkgName || getPackage.call(loader, normalized);                                  // 2068
                            var pkg = pkg || pkgName && loader.packages[pkgName];                                      // 2069
                                                                                                                       //
                            if (pkg) return applyPackageConfig.call(loader, normalized, pkgName, pkg, sync, isPlugin);else return normalized + (defaultJSExtension ? '.js' : '');
                        }                                                                                              //
                                                                                                                       //
                        // do direct resolution if sync                                                                //
                        if (sync) return packageResolution(normalized);                                                // 2078
                                                                                                                       //
                        // first check if we are in a package                                                          //
                        var pkgName = getPackage.call(this, normalized);                                               // 2082
                        var pkg = pkgName && this.packages[pkgName];                                                   // 2083
                                                                                                                       //
                        // if so, and the package is configured, then do direct resolution                             //
                        if (pkg && pkg.configured) return packageResolution(normalized, pkgName, pkg);                 // 2086
                                                                                                                       //
                        var pkgConfigMatch = pkgConfigPathMatch(loader, normalized);                                   // 2089
                                                                                                                       //
                        if (!pkgConfigMatch.pkgName) return packageResolution(normalized, pkgName, pkg);               // 2091
                                                                                                                       //
                        // if we're within a known package path, then halt on                                          //
                        // further package configuration steps from bundles and config files                           //
                        return Promise.resolve(getBundleFor(loader, normalized))                                       // 2096
                                                                                                                       //
                        // ensure that any bundles in this package are triggered, and                                  //
                        // all that are triggered block any further loads in the package                               //
                        .then(function (bundle) {                                                                      //
                            if (bundle || pkgBundlePromises[pkgConfigMatch.pkgName]) {                                 // 2101
                                var pkgBundleLoads = pkgBundlePromises[pkgConfigMatch.pkgName] = pkgBundlePromises[pkgConfigMatch.pkgName] || { bundles: [], promise: Promise.resolve() };
                                if (bundle && indexOf.call(pkgBundleLoads.bundles, bundle) == -1) {                    // 2103
                                    pkgBundleLoads.bundles.push(bundle);                                               // 2104
                                    pkgBundleLoads.promise = Promise.all([pkgBundleLoads.promise, loader.load(bundle)]);
                                }                                                                                      //
                                return pkgBundleLoads.promise;                                                         // 2107
                            }                                                                                          //
                        })                                                                                             //
                                                                                                                       //
                        // having loaded any bundles, attempt a package resolution now                                 //
                        .then(function () {                                                                            //
                            return packageResolution(normalized, pkgConfigMatch.pkgName);                              // 2113
                        }).then(function (curResolution) {                                                             //
                            // if that resolution is defined in the registry use it                                    //
                            if (curResolution in loader.defined) return curResolution;                                 // 2118
                                                                                                                       //
                            // otherwise revert to loading configuration dynamically                                   //
                            return loadPackageConfigPaths(loader, pkgConfigMatch).then(function () {                   // 2122
                                // before doing a final resolution                                                     //
                                return packageResolution(normalized);                                                  // 2125
                            });                                                                                        //
                        });                                                                                            //
                    };                                                                                                 //
                }                                                                                                      //
                                                                                                                       //
                var pkgBundlePromises = {};                                                                            // 2131
                                                                                                                       //
                // check if the given normalized name matches a packageConfigPath                                      //
                // if so, loads the config                                                                             //
                var packageConfigPathsRegExps = {};                                                                    // 2135
                var pkgConfigPromises = {};                                                                            // 2136
                                                                                                                       //
                function pkgConfigPathMatch(loader, normalized) {                                                      // 2138
                    var pkgPath,                                                                                       // 2139
                        pkgConfigPaths = [];                                                                           //
                    for (var i = 0; i < loader.packageConfigPaths.length; i++) {                                       // 2140
                        var p = loader.packageConfigPaths[i];                                                          // 2141
                        var pPkgLen = Math.max(p.lastIndexOf('*') + 1, p.lastIndexOf('/'));                            // 2142
                        var match = normalized.match(packageConfigPathsRegExps[p] || (packageConfigPathsRegExps[p] = new RegExp('^(' + p.substr(0, pPkgLen).replace(/\*/g, '[^\\/]+') + ')(\/|$)')));
                        if (match && (!pkgPath || pkgPath == match[1])) {                                              // 2145
                            pkgPath = match[1];                                                                        // 2146
                            pkgConfigPaths.push(pkgPath + p.substr(pPkgLen));                                          // 2147
                        }                                                                                              //
                    }                                                                                                  //
                    return {                                                                                           // 2150
                        pkgName: pkgPath,                                                                              // 2151
                        configPaths: pkgConfigPaths                                                                    // 2152
                    };                                                                                                 //
                }                                                                                                      //
                                                                                                                       //
                function loadPackageConfigPaths(loader, pkgConfigMatch) {                                              // 2156
                    var curPkgConfig = loader.packages[pkgConfigMatch.pkgName];                                        // 2157
                                                                                                                       //
                    if (curPkgConfig && curPkgConfig.configured) return Promise.resolve();                             // 2159
                                                                                                                       //
                    return pkgConfigPromises[pkgConfigMatch.pkgName] || (pkgConfigPromises[pkgConfigMatch.pkgName] = Promise.resolve().then(function () {
                        var pkgConfigPromises = [];                                                                    // 2165
                        for (var i = 0; i < pkgConfigMatch.configPaths.length; i++) (function (pkgConfigPath) {        // 2166
                            pkgConfigPromises.push(loader['fetch']({ name: pkgConfigPath, address: pkgConfigPath, metadata: {} }).then(function (source) {
                                try {                                                                                  // 2169
                                    return JSON.parse(source);                                                         // 2170
                                } catch (e) {                                                                          //
                                    throw new Error('Invalid JSON in package configuration file ' + pkgConfigPath);    // 2173
                                }                                                                                      //
                            }).then(function (cfg) {                                                                   //
                                // support "systemjs" prefixing                                                        //
                                if (cfg.systemjs) cfg = cfg.systemjs;                                                  // 2178
                                                                                                                       //
                                // remove any non-system properties if generic config file (eg package.json)           //
                                for (var p in babelHelpers.sanitizeForInObject(cfg)) {                                 // 2182
                                    if (indexOf.call(packageProperties, p) == -1) delete cfg[p];                       // 2183
                                }                                                                                      //
                                                                                                                       //
                                // support main array                                                                  //
                                if (cfg.main instanceof Array) cfg.main = cfg.main[0];                                 // 2188
                                                                                                                       //
                                // deeply-merge (to first level) config with any existing package config               //
                                if (curPkgConfig) extendMeta(cfg, curPkgConfig);                                       // 2192
                                                                                                                       //
                                // support external depCache                                                           //
                                if (cfg.depCache) for (var d in babelHelpers.sanitizeForInObject(cfg.depCache)) {      // 2196
                                    if (d.substr(0, 2) == './') continue;                                              // 2198
                                                                                                                       //
                                    var dNormalized = loader.normalizeSync(d);                                         // 2201
                                    loader.depCache[dNormalized] = (loader.depCache[dNormalized] || []).concat(cfg.depCache[d]);
                                }                                                                                      //
                                                                                                                       //
                                curPkgConfig = loader.packages[pkgConfigMatch.pkgName] = cfg;                          // 2205
                            }));                                                                                       //
                        })(pkgConfigMatch.configPaths[i]);                                                             //
                                                                                                                       //
                        return Promise.all(pkgConfigPromises);                                                         // 2209
                    }));                                                                                               //
                }                                                                                                      //
                                                                                                                       //
                SystemJSLoader.prototype.normalizeSync = SystemJSLoader.prototype.normalize;                           // 2214
                                                                                                                       //
                hook('normalizeSync', function (normalize) {                                                           // 2216
                    return createPackageNormalize(normalize, true);                                                    // 2217
                });                                                                                                    //
                                                                                                                       //
                hook('normalize', function (normalize) {                                                               // 2220
                    return createPackageNormalize(normalize, false);                                                   // 2221
                });                                                                                                    //
                                                                                                                       //
                function getMetaMatches(pkgMeta, pkgName, subPath, matchFn) {                                          // 2224
                    // wildcard meta                                                                                   //
                    var meta = {};                                                                                     // 2226
                    var wildcardIndex;                                                                                 // 2227
                    for (var module in babelHelpers.sanitizeForInObject(pkgMeta)) {                                    // 2228
                        // allow meta to start with ./ for flexibility                                                 //
                        var dotRel = module.substr(0, 2) == './' ? './' : '';                                          // 2230
                        if (dotRel) module = module.substr(2);                                                         // 2231
                                                                                                                       //
                        wildcardIndex = module.indexOf('*');                                                           // 2234
                        if (wildcardIndex === -1) continue;                                                            // 2235
                                                                                                                       //
                        if (module.substr(0, wildcardIndex) == subPath.substr(0, wildcardIndex) && module.substr(wildcardIndex + 1) == subPath.substr(subPath.length - module.length + wildcardIndex + 1)) {
                            matchFn(module, pkgMeta[dotRel + module], module.split('/').length);                       // 2240
                        }                                                                                              //
                    }                                                                                                  //
                    // exact meta                                                                                      //
                    var exactMeta = pkgMeta[subPath] || pkgMeta['./' + subPath];                                       // 2244
                    if (exactMeta) matchFn(exactMeta, exactMeta, 0);                                                   // 2245
                }                                                                                                      //
                                                                                                                       //
                hook('locate', function (locate) {                                                                     // 2249
                    return function (load) {                                                                           // 2250
                        var loader = this;                                                                             // 2251
                        return Promise.resolve(locate.call(this, load)).then(function (address) {                      // 2252
                            var pkgName = getPackage.call(loader, load.name);                                          // 2254
                            if (pkgName) {                                                                             // 2255
                                var pkg = loader.packages[pkgName];                                                    // 2256
                                var basePath = getBasePath(pkg);                                                       // 2257
                                var subPath = load.name.substr(pkgName.length + basePath.length + 1);                  // 2258
                                                                                                                       //
                                // format                                                                              //
                                if (pkg.format) load.metadata.format = load.metadata.format || pkg.format;             // 2261
                                                                                                                       //
                                // depCache for packages                                                               //
                                if (pkg.depCache) {                                                                    // 2265
                                    for (var d in babelHelpers.sanitizeForInObject(pkg.depCache)) {                    // 2266
                                        if (d != './' + subPath) continue;                                             // 2267
                                                                                                                       //
                                        var deps = pkg.depCache[d];                                                    // 2270
                                        for (var i = 0; i < deps.length; i++) loader['import'](deps[i], pkgName + '/');
                                    }                                                                                  //
                                }                                                                                      //
                                                                                                                       //
                                var meta = {};                                                                         // 2276
                                if (pkg.meta) {                                                                        // 2277
                                    var bestDepth = 0;                                                                 // 2278
                                    getMetaMatches(pkg.meta, pkgName, subPath, function (metaPattern, matchMeta, matchDepth) {
                                        if (matchDepth > bestDepth) bestDepth = matchDepth;                            // 2280
                                        extendMeta(meta, matchMeta, matchDepth && bestDepth > matchDepth);             // 2282
                                    });                                                                                //
                                                                                                                       //
                                    // allow alias and loader to be package-relative                                   //
                                    if (meta.alias && meta.alias.substr(0, 2) == './') meta.alias = pkgName + meta.alias.substr(1);
                                    if (meta.loader && meta.loader.substr(0, 2) == './') meta.loader = pkgName + meta.loader.substr(1);
                                    extendMeta(load.metadata, meta);                                                   // 2290
                                }                                                                                      //
                            }                                                                                          //
                                                                                                                       //
                            return address;                                                                            // 2294
                        });                                                                                            //
                    };                                                                                                 //
                });                                                                                                    //
            })(); /*                                                                                                   //
                  * Script tag fetch                                                                                   //
                  *                                                                                                    //
                  * When load.metadata.scriptLoad is true, we load via script tag injection.                           //
                  */                                                                                                   //
            (function () {                                                                                             // 2304
                                                                                                                       //
                if (typeof document != 'undefined') var head = document.getElementsByTagName('head')[0];               // 2306
                                                                                                                       //
                // call this functione everytime a wrapper executes                                                    //
                var curSystem;                                                                                         // 2310
                // System clobbering protection for Traceur                                                            //
                SystemJSLoader.prototype.onScriptLoad = function () {                                                  // 2312
                    __global.System = curSystem;                                                                       // 2313
                };                                                                                                     //
                                                                                                                       //
                function webWorkerImport(loader, load) {                                                               // 2316
                    return new Promise(function (resolve, reject) {                                                    // 2317
                        if (load.metadata.integrity) reject(new Error('Subresource integrity checking is not supported in web workers.'));
                                                                                                                       //
                        try {                                                                                          // 2321
                            importScripts(load.address);                                                               // 2322
                        } catch (e) {                                                                                  //
                            reject(e);                                                                                 // 2325
                        }                                                                                              //
                                                                                                                       //
                        loader.onScriptLoad(load);                                                                     // 2328
                        // if nothing registered, then something went wrong                                            //
                        if (!load.metadata.registered) reject(load.address + ' did not call System.register or AMD define');
                                                                                                                       //
                        resolve('');                                                                                   // 2333
                    });                                                                                                //
                }                                                                                                      //
                                                                                                                       //
                // override fetch to use script injection                                                              //
                hook('fetch', function (fetch) {                                                                       // 2338
                    return function (load) {                                                                           // 2339
                        var loader = this;                                                                             // 2340
                                                                                                                       //
                        if (!load.metadata.scriptLoad || !isBrowser && !isWorker) return fetch.call(this, load);       // 2342
                                                                                                                       //
                        if (isWorker) return webWorkerImport(loader, load);                                            // 2345
                                                                                                                       //
                        return new Promise(function (resolve, reject) {                                                // 2348
                            var s = document.createElement('script');                                                  // 2349
                            s.async = true;                                                                            // 2350
                                                                                                                       //
                            function complete(evt) {                                                                   // 2352
                                if (s.readyState && s.readyState != 'loaded' && s.readyState != 'complete') return;    // 2353
                                cleanup();                                                                             // 2355
                                                                                                                       //
                                // this runs synchronously after execution                                             //
                                // we now need to tell the wrapper handlers that                                       //
                                // this load record has just executed                                                  //
                                loader.onScriptLoad(load);                                                             // 2360
                                                                                                                       //
                                // if nothing registered, then something went wrong                                    //
                                if (!load.metadata.registered) reject(load.address + ' did not call System.register or AMD define');
                                                                                                                       //
                                resolve('');                                                                           // 2366
                            }                                                                                          //
                                                                                                                       //
                            function error(evt) {                                                                      // 2369
                                cleanup();                                                                             // 2370
                                reject(new Error('Unable to load script ' + load.address));                            // 2371
                            }                                                                                          //
                                                                                                                       //
                            if (s.attachEvent) {                                                                       // 2374
                                s.attachEvent('onreadystatechange', complete);                                         // 2375
                            } else {                                                                                   //
                                s.addEventListener('load', complete, false);                                           // 2378
                                s.addEventListener('error', error, false);                                             // 2379
                            }                                                                                          //
                                                                                                                       //
                            curSystem = __global.System;                                                               // 2382
                            __global.System = loader;                                                                  // 2383
                            s.src = load.address;                                                                      // 2384
                                                                                                                       //
                            if (load.metadata.integrity) s.setAttribute('integrity', load.metadata.integrity);         // 2386
                                                                                                                       //
                            head.appendChild(s);                                                                       // 2389
                                                                                                                       //
                            function cleanup() {                                                                       // 2391
                                if (s.detachEvent) s.detachEvent('onreadystatechange', complete);else {                // 2392
                                    s.removeEventListener('load', complete, false);                                    // 2395
                                    s.removeEventListener('error', error, false);                                      // 2396
                                }                                                                                      //
                                head.removeChild(s);                                                                   // 2398
                            }                                                                                          //
                        });                                                                                            //
                    };                                                                                                 //
                });                                                                                                    //
            })();                                                                                                      //
            /*                                                                                                         //
             * Instantiate registry extension                                                                          //
             *                                                                                                         //
             * Supports Traceur System.register 'instantiate' output for loading ES6 as ES5.                           //
             *                                                                                                         //
             * - Creates the loader.register function                                                                  //
             * - Also supports metadata.format = 'register' in instantiate for anonymous register modules              //
             * - Also supports metadata.deps, metadata.execute and metadata.executingRequire                           //
             *     for handling dynamic modules alongside register-transformed ES6 modules                             //
             *                                                                                                         //
             *                                                                                                         //
             * The code here replicates the ES6 linking groups algorithm to ensure that                                //
             * circular ES6 compiled into System.register can work alongside circular AMD                              //
             * and CommonJS, identically to the actual ES6 loader.                                                     //
             *                                                                                                         //
             */                                                                                                        //
            (function () {                                                                                             // 2420
                                                                                                                       //
                /*                                                                                                     //
                 * There are two variations of System.register:                                                        //
                 * 1. System.register for ES6 conversion (2-3 params) - System.register([name, ]deps, declare)         //
                 *    see https://github.com/ModuleLoader/es6-module-loader/wiki/System.register-Explained             //
                 *                                                                                                     //
                 * 2. System.registerDynamic for dynamic modules (3-4 params) - System.registerDynamic([name, ]deps, executingRequire, execute)
                 * the true or false statement                                                                         //
                 *                                                                                                     //
                 * this extension implements the linking algorithm for the two variations identical to the spec        //
                 * allowing compiled ES6 circular references to work alongside AMD and CJS circular references.        //
                 *                                                                                                     //
                 */                                                                                                    //
                var anonRegister;                                                                                      // 2434
                var calledRegister = false;                                                                            // 2435
                function doRegister(loader, name, register) {                                                          // 2436
                    calledRegister = true;                                                                             // 2437
                                                                                                                       //
                    // named register                                                                                  //
                    if (name) {                                                                                        // 2440
                        // ideally wouldn't apply map config to bundle names but                                       //
                        // dependencies go through map regardless so we can't restrict                                 //
                        // could reconsider in shift to new spec                                                       //
                        name = (loader.normalizeSync || loader.normalize).call(loader, name);                          // 2444
                        register.name = name;                                                                          // 2445
                        if (!(name in loader.defined)) loader.defined[name] = register;                                // 2446
                    }                                                                                                  //
                    // anonymous register                                                                              //
                    else {                                                                                             //
                            if (anonRegister) throw new TypeError('Invalid anonymous System.register module load. If loading a single module, ensure anonymous System.register is loaded via System.import. If loading a bundle, ensure all the System.register calls are named.');
                            anonRegister = register;                                                                   // 2453
                        }                                                                                              //
                }                                                                                                      //
                SystemJSLoader.prototype.register = function (name, deps, declare) {                                   // 2456
                    if (typeof name != 'string') {                                                                     // 2457
                        declare = deps;                                                                                // 2458
                        deps = name;                                                                                   // 2459
                        name = null;                                                                                   // 2460
                    }                                                                                                  //
                                                                                                                       //
                    // dynamic backwards-compatibility                                                                 //
                    // can be deprecated eventually                                                                    //
                    if (typeof declare == 'boolean') return this.registerDynamic.apply(this, arguments);               // 2465
                                                                                                                       //
                    doRegister(this, name, {                                                                           // 2468
                        declarative: true,                                                                             // 2469
                        deps: deps,                                                                                    // 2470
                        declare: declare                                                                               // 2471
                    });                                                                                                //
                };                                                                                                     //
                SystemJSLoader.prototype.registerDynamic = function (name, deps, declare, execute) {                   // 2474
                    if (typeof name != 'string') {                                                                     // 2475
                        execute = declare;                                                                             // 2476
                        declare = deps;                                                                                // 2477
                        deps = name;                                                                                   // 2478
                        name = null;                                                                                   // 2479
                    }                                                                                                  //
                                                                                                                       //
                    // dynamic                                                                                         //
                    doRegister(this, name, {                                                                           // 2483
                        declarative: false,                                                                            // 2484
                        deps: deps,                                                                                    // 2485
                        execute: execute,                                                                              // 2486
                        executingRequire: declare                                                                      // 2487
                    });                                                                                                //
                };                                                                                                     //
                /*                                                                                                     //
                 * Registry side table - loader.defined                                                                //
                 * Registry Entry Contains:                                                                            //
                 *    - name                                                                                           //
                 *    - deps                                                                                           //
                 *    - declare for declarative modules                                                                //
                 *    - execute for dynamic modules, different to declarative execute on module                        //
                 *    - executingRequire indicates require drives execution for circularity of dynamic modules         //
                 *    - declarative optional boolean indicating which of the above                                     //
                 *                                                                                                     //
                 * Can preload modules directly on System.defined['my/module'] = { deps, execute, executingRequire }   //
                 *                                                                                                     //
                 * Then the entry gets populated with derived information during processing:                           //
                 *    - normalizedDeps derived from deps, created in instantiate                                       //
                 *    - groupIndex used by group linking algorithm                                                     //
                 *    - evaluated indicating whether evaluation has happend                                            //
                 *    - module the module record object, containing:                                                   //
                 *      - exports actual module exports                                                                //
                 *                                                                                                     //
                 *    For dynamic we track the es module with:                                                         //
                 *    - esModule actual es module value                                                                //
                 *    - esmExports whether to extend the esModule with named exports                                   //
                 *                                                                                                     //
                 *    Then for declarative only we track dynamic bindings with the 'module' records:                   //
                 *      - name                                                                                         //
                 *      - exports                                                                                      //
                 *      - setters declarative setter functions                                                         //
                 *      - dependencies, module records of dependencies                                                 //
                 *      - importers, module records of dependents                                                      //
                 *                                                                                                     //
                 * After linked and evaluated, entries are removed, declarative module records remain in separate      //
                 * module binding table                                                                                //
                 *                                                                                                     //
                 */                                                                                                    //
                hookConstructor(function (constructor) {                                                               // 2524
                    return function () {                                                                               // 2525
                        constructor.call(this);                                                                        // 2526
                                                                                                                       //
                        this.defined = {};                                                                             // 2528
                        this._loader.moduleRecords = {};                                                               // 2529
                    };                                                                                                 //
                });                                                                                                    //
                                                                                                                       //
                // script injection mode calls this function synchronously on load                                     //
                hook('onScriptLoad', function (onScriptLoad) {                                                         // 2534
                    return function (load) {                                                                           // 2535
                        onScriptLoad.call(this, load);                                                                 // 2536
                                                                                                                       //
                        if (calledRegister) {                                                                          // 2538
                            // anonymous define                                                                        //
                            if (anonRegister) load.metadata.entry = anonRegister;                                      // 2540
                                                                                                                       //
                            load.metadata.format = load.metadata.format || 'defined';                                  // 2543
                            load.metadata.registered = true;                                                           // 2544
                            calledRegister = false;                                                                    // 2545
                            anonRegister = null;                                                                       // 2546
                        }                                                                                              //
                    };                                                                                                 //
                });                                                                                                    //
                                                                                                                       //
                function buildGroups(entry, loader, groups) {                                                          // 2551
                    groups[entry.groupIndex] = groups[entry.groupIndex] || [];                                         // 2552
                                                                                                                       //
                    if (indexOf.call(groups[entry.groupIndex], entry) != -1) return;                                   // 2554
                                                                                                                       //
                    groups[entry.groupIndex].push(entry);                                                              // 2557
                                                                                                                       //
                    for (var i = 0, l = entry.normalizedDeps.length; i < l; i++) {                                     // 2559
                        var depName = entry.normalizedDeps[i];                                                         // 2560
                        var depEntry = loader.defined[depName];                                                        // 2561
                                                                                                                       //
                        // not in the registry means already linked / ES6                                              //
                        if (!depEntry || depEntry.evaluated) continue;                                                 // 2564
                                                                                                                       //
                        // now we know the entry is in our unlinked linkage group                                      //
                        var depGroupIndex = entry.groupIndex + (depEntry.declarative != entry.declarative);            // 2568
                                                                                                                       //
                        // the group index of an entry is always the maximum                                           //
                        if (depEntry.groupIndex === undefined || depEntry.groupIndex < depGroupIndex) {                // 2571
                                                                                                                       //
                            // if already in a group, remove from the old group                                        //
                            if (depEntry.groupIndex !== undefined) {                                                   // 2574
                                groups[depEntry.groupIndex].splice(indexOf.call(groups[depEntry.groupIndex], depEntry), 1);
                                                                                                                       //
                                // if the old group is empty, then we have a mixed depndency cycle                     //
                                if (groups[depEntry.groupIndex].length == 0) throw new TypeError("Mixed dependency cycle detected");
                            }                                                                                          //
                                                                                                                       //
                            depEntry.groupIndex = depGroupIndex;                                                       // 2582
                        }                                                                                              //
                                                                                                                       //
                        buildGroups(depEntry, loader, groups);                                                         // 2585
                    }                                                                                                  //
                }                                                                                                      //
                                                                                                                       //
                function link(name, loader) {                                                                          // 2589
                    var startEntry = loader.defined[name];                                                             // 2590
                                                                                                                       //
                    // skip if already linked                                                                          //
                    if (startEntry.module) return;                                                                     // 2593
                                                                                                                       //
                    startEntry.groupIndex = 0;                                                                         // 2596
                                                                                                                       //
                    var groups = [];                                                                                   // 2598
                                                                                                                       //
                    buildGroups(startEntry, loader, groups);                                                           // 2600
                                                                                                                       //
                    var curGroupDeclarative = !!startEntry.declarative == groups.length % 2;                           // 2602
                    for (var i = groups.length - 1; i >= 0; i--) {                                                     // 2603
                        var group = groups[i];                                                                         // 2604
                        for (var j = 0; j < group.length; j++) {                                                       // 2605
                            var entry = group[j];                                                                      // 2606
                                                                                                                       //
                            // link each group                                                                         //
                            if (curGroupDeclarative) linkDeclarativeModule(entry, loader);else linkDynamicModule(entry, loader);
                        }                                                                                              //
                        curGroupDeclarative = !curGroupDeclarative;                                                    // 2614
                    }                                                                                                  //
                }                                                                                                      //
                                                                                                                       //
                // module binding records                                                                              //
                function Module() {}                                                                                   // 2619
                defineProperty(Module, 'toString', {                                                                   // 2620
                    value: function () {                                                                               // 2621
                        return 'Module';                                                                               // 2622
                    }                                                                                                  //
                });                                                                                                    //
                                                                                                                       //
                function getOrCreateModuleRecord(name, moduleRecords) {                                                // 2626
                    return moduleRecords[name] || (moduleRecords[name] = {                                             // 2627
                        name: name,                                                                                    // 2628
                        dependencies: [],                                                                              // 2629
                        exports: new Module(), // start from an empty module and extend                                // 2630
                        importers: []                                                                                  // 2631
                    });                                                                                                //
                }                                                                                                      //
                                                                                                                       //
                function linkDeclarativeModule(entry, loader) {                                                        // 2635
                    // only link if already not already started linking (stops at circular)                            //
                    if (entry.module) return;                                                                          // 2637
                                                                                                                       //
                    var moduleRecords = loader._loader.moduleRecords;                                                  // 2640
                    var module = entry.module = getOrCreateModuleRecord(entry.name, moduleRecords);                    // 2641
                    var exports = entry.module.exports;                                                                // 2642
                                                                                                                       //
                    var declaration = entry.declare.call(__global, function (name, value) {                            // 2644
                        module.locked = true;                                                                          // 2645
                                                                                                                       //
                        if (typeof name == 'object') {                                                                 // 2647
                            for (var p in babelHelpers.sanitizeForInObject(name)) exports[p] = name[p];                // 2648
                        } else {                                                                                       //
                            exports[name] = value;                                                                     // 2652
                        }                                                                                              //
                                                                                                                       //
                        for (var i = 0, l = module.importers.length; i < l; i++) {                                     // 2655
                            var importerModule = module.importers[i];                                                  // 2656
                            if (!importerModule.locked) {                                                              // 2657
                                var importerIndex = indexOf.call(importerModule.dependencies, module);                 // 2658
                                importerModule.setters[importerIndex](exports);                                        // 2659
                            }                                                                                          //
                        }                                                                                              //
                                                                                                                       //
                        module.locked = false;                                                                         // 2663
                        return value;                                                                                  // 2664
                    });                                                                                                //
                                                                                                                       //
                    module.setters = declaration.setters;                                                              // 2667
                    module.execute = declaration.execute;                                                              // 2668
                                                                                                                       //
                    if (!module.setters || !module.execute) {                                                          // 2670
                        throw new TypeError('Invalid System.register form for ' + entry.name);                         // 2671
                    }                                                                                                  //
                                                                                                                       //
                    // now link all the module dependencies                                                            //
                    for (var i = 0, l = entry.normalizedDeps.length; i < l; i++) {                                     // 2675
                        var depName = entry.normalizedDeps[i];                                                         // 2676
                        var depEntry = loader.defined[depName];                                                        // 2677
                        var depModule = moduleRecords[depName];                                                        // 2678
                                                                                                                       //
                        // work out how to set depExports based on scenarios...                                        //
                        var depExports;                                                                                // 2681
                                                                                                                       //
                        if (depModule) {                                                                               // 2683
                            depExports = depModule.exports;                                                            // 2684
                        }                                                                                              //
                        // dynamic, already linked in our registry                                                     //
                        else if (depEntry && !depEntry.declarative) {                                                  //
                                depExports = depEntry.esModule;                                                        // 2688
                            }                                                                                          //
                            // in the loader registry                                                                  //
                            else if (!depEntry) {                                                                      //
                                    depExports = loader.get(depName);                                                  // 2692
                                }                                                                                      //
                                // we have an entry -> link                                                            //
                                else {                                                                                 //
                                        linkDeclarativeModule(depEntry, loader);                                       // 2696
                                        depModule = depEntry.module;                                                   // 2697
                                        depExports = depModule.exports;                                                // 2698
                                    }                                                                                  //
                                                                                                                       //
                        // only declarative modules have dynamic bindings                                              //
                        if (depModule && depModule.importers) {                                                        // 2702
                            depModule.importers.push(module);                                                          // 2703
                            module.dependencies.push(depModule);                                                       // 2704
                        } else {                                                                                       //
                            module.dependencies.push(null);                                                            // 2707
                        }                                                                                              //
                                                                                                                       //
                        // run setters for all entries with the matching dependency name                               //
                        var originalIndices = entry.originalIndices[i];                                                // 2711
                        for (var j = 0, len = originalIndices.length; j < len; ++j) {                                  // 2712
                            var index = originalIndices[j];                                                            // 2713
                            if (module.setters[index]) {                                                               // 2714
                                module.setters[index](depExports);                                                     // 2715
                            }                                                                                          //
                        }                                                                                              //
                    }                                                                                                  //
                }                                                                                                      //
                                                                                                                       //
                // An analog to loader.get covering execution of all three layers (real declarative, simulated declarative, simulated dynamic)
                function getModule(name, loader) {                                                                     // 2722
                    var exports;                                                                                       // 2723
                    var entry = loader.defined[name];                                                                  // 2724
                                                                                                                       //
                    if (!entry) {                                                                                      // 2726
                        exports = loader.get(name);                                                                    // 2727
                        if (!exports) throw new Error('Unable to load dependency ' + name + '.');                      // 2728
                    } else {                                                                                           //
                        if (entry.declarative) ensureEvaluated(name, [], loader);else if (!entry.evaluated) linkDynamicModule(entry, loader);
                                                                                                                       //
                        exports = entry.module.exports;                                                                // 2739
                    }                                                                                                  //
                                                                                                                       //
                    if ((!entry || entry.declarative) && exports && exports.__useDefault) return exports['default'];   // 2742
                                                                                                                       //
                    return exports;                                                                                    // 2745
                }                                                                                                      //
                                                                                                                       //
                function linkDynamicModule(entry, loader) {                                                            // 2748
                    if (entry.module) return;                                                                          // 2749
                                                                                                                       //
                    var exports = {};                                                                                  // 2752
                                                                                                                       //
                    var module = entry.module = { exports: exports, id: entry.name };                                  // 2754
                                                                                                                       //
                    // AMD requires execute the tree first                                                             //
                    if (!entry.executingRequire) {                                                                     // 2757
                        for (var i = 0, l = entry.normalizedDeps.length; i < l; i++) {                                 // 2758
                            var depName = entry.normalizedDeps[i];                                                     // 2759
                            // we know we only need to link dynamic due to linking algorithm                           //
                            var depEntry = loader.defined[depName];                                                    // 2761
                            if (depEntry) linkDynamicModule(depEntry, loader);                                         // 2762
                        }                                                                                              //
                    }                                                                                                  //
                                                                                                                       //
                    // now execute                                                                                     //
                    entry.evaluated = true;                                                                            // 2768
                    var output = entry.execute.call(__global, function (name) {                                        // 2769
                        for (var i = 0, l = entry.deps.length; i < l; i++) {                                           // 2770
                            if (entry.deps[i] != name) continue;                                                       // 2771
                            return getModule(entry.normalizedDeps[i], loader);                                         // 2773
                        }                                                                                              //
                        throw new TypeError('Module ' + name + ' not declared as a dependency.');                      // 2775
                    }, exports, module);                                                                               //
                                                                                                                       //
                    if (output) module.exports = output;                                                               // 2778
                                                                                                                       //
                    // create the esModule object, which allows ES6 named imports of dynamics                          //
                    exports = module.exports;                                                                          // 2782
                                                                                                                       //
                    // __esModule flag treats as already-named                                                         //
                    if (exports && exports.__esModule) entry.esModule = exports;                                       // 2785
                    // set module as 'default' export, then fake named exports by iterating properties                 //
                    else if (entry.esmExports) entry.esModule = getESModule(exports);                                  //
                        // just use the 'default' export                                                               //
                        else entry.esModule = { 'default': exports };                                                  //
                }                                                                                                      //
                                                                                                                       //
                /*                                                                                                     //
                 * Given a module, and the list of modules for this current branch,                                    //
                 *  ensure that each of the dependencies of this module is evaluated                                   //
                 *  (unless one is a circular dependency already in the list of seen                                   //
                 *  modules, in which case we execute it)                                                              //
                 *                                                                                                     //
                 * Then we evaluate the module itself depth-first left to right                                        //
                 * execution to match ES6 modules                                                                      //
                 */                                                                                                    //
                function ensureEvaluated(moduleName, seen, loader) {                                                   // 2804
                    var entry = loader.defined[moduleName];                                                            // 2805
                                                                                                                       //
                    // if already seen, that means it's an already-evaluated non circular dependency                   //
                    if (!entry || entry.evaluated || !entry.declarative) return;                                       // 2808
                                                                                                                       //
                    // this only applies to declarative modules which late-execute                                     //
                                                                                                                       //
                    seen.push(moduleName);                                                                             // 2813
                                                                                                                       //
                    for (var i = 0, l = entry.normalizedDeps.length; i < l; i++) {                                     // 2815
                        var depName = entry.normalizedDeps[i];                                                         // 2816
                        if (indexOf.call(seen, depName) == -1) {                                                       // 2817
                            if (!loader.defined[depName]) loader.get(depName);else ensureEvaluated(depName, seen, loader);
                        }                                                                                              //
                    }                                                                                                  //
                                                                                                                       //
                    if (entry.evaluated) return;                                                                       // 2825
                                                                                                                       //
                    entry.evaluated = true;                                                                            // 2828
                    entry.module.execute.call(__global);                                                               // 2829
                }                                                                                                      //
                                                                                                                       //
                // override the delete method to also clear the register caches                                        //
                hook('delete', function (del) {                                                                        // 2833
                    return function (name) {                                                                           // 2834
                        delete this._loader.moduleRecords[name];                                                       // 2835
                        delete this.defined[name];                                                                     // 2836
                        return del.call(this, name);                                                                   // 2837
                    };                                                                                                 //
                });                                                                                                    //
                                                                                                                       //
                var leadingCommentAndMetaRegEx = /^\s*(\/\*[^\*]*(\*(?!\/)[^\*]*)*\*\/|\s*\/\/[^\n]*|\s*"[^"]+"\s*;?|\s*'[^']+'\s*;?)*\s*/;
                function detectRegisterFormat(source) {                                                                // 2842
                    var leadingCommentAndMeta = source.match(leadingCommentAndMetaRegEx);                              // 2843
                    return leadingCommentAndMeta && source.substr(leadingCommentAndMeta[0].length, 15) == 'System.register';
                }                                                                                                      //
                                                                                                                       //
                hook('fetch', function (fetch) {                                                                       // 2847
                    return function (load) {                                                                           // 2848
                        if (this.defined[load.name]) {                                                                 // 2849
                            load.metadata.format = 'defined';                                                          // 2850
                            return '';                                                                                 // 2851
                        }                                                                                              //
                                                                                                                       //
                        // this is the synchronous chain for onScriptLoad                                              //
                        anonRegister = null;                                                                           // 2855
                        calledRegister = false;                                                                        // 2856
                                                                                                                       //
                        if (load.metadata.format == 'register' && !load.metadata.authorization) load.metadata.scriptLoad = true;
                                                                                                                       //
                        // NB remove when "deps " is deprecated                                                        //
                        load.metadata.deps = load.metadata.deps || [];                                                 // 2862
                                                                                                                       //
                        return fetch.call(this, load);                                                                 // 2864
                    };                                                                                                 //
                });                                                                                                    //
                                                                                                                       //
                hook('translate', function (translate) {                                                               // 2868
                    // we run the meta detection here (register is after meta)                                         //
                    return function (load) {                                                                           // 2870
                        return Promise.resolve(translate.call(this, load)).then(function (source) {                    // 2871
                                                                                                                       //
                            if (typeof load.metadata.deps === 'string') load.metadata.deps = load.metadata.deps.split(',');
                            load.metadata.deps = load.metadata.deps || [];                                             // 2875
                                                                                                                       //
                            // run detection for register format                                                       //
                            if (load.metadata.format == 'register' || !load.metadata.format && detectRegisterFormat(load.source)) load.metadata.format = 'register';
                            return source;                                                                             // 2880
                        });                                                                                            //
                    };                                                                                                 //
                });                                                                                                    //
                                                                                                                       //
                hook('instantiate', function (instantiate) {                                                           // 2885
                    return function (load) {                                                                           // 2886
                        var loader = this;                                                                             // 2887
                                                                                                                       //
                        var entry;                                                                                     // 2889
                                                                                                                       //
                        // first we check if this module has already been defined in the registry                      //
                        if (loader.defined[load.name]) {                                                               // 2892
                            entry = loader.defined[load.name];                                                         // 2893
                            entry.deps = entry.deps.concat(load.metadata.deps);                                        // 2894
                        }                                                                                              //
                                                                                                                       //
                        // picked up already by a script injection                                                     //
                        else if (load.metadata.entry) entry = load.metadata.entry;                                     //
                                                                                                                       //
                            // otherwise check if it is dynamic                                                        //
                            else if (load.metadata.execute) {                                                          //
                                    entry = {                                                                          // 2903
                                        declarative: false,                                                            // 2904
                                        deps: load.metadata.deps || [],                                                // 2905
                                        execute: load.metadata.execute,                                                // 2906
                                        executingRequire: load.metadata.executingRequire // NodeJS-style requires or not
                                    };                                                                                 //
                                }                                                                                      //
                                                                                                                       //
                                // Contains System.register calls                                                      //
                                // (dont run bundles in the builder)                                                   //
                                else if (!(loader.builder && load.metadata.bundle) && (load.metadata.format == 'register' || load.metadata.format == 'esm' || load.metadata.format == 'es6')) {
                                        anonRegister = null;                                                           // 2915
                                        calledRegister = false;                                                        // 2916
                                                                                                                       //
                                        if (typeof __exec != 'undefined') __exec.call(loader, load);                   // 2918
                                                                                                                       //
                                        if (!calledRegister && !load.metadata.registered) throw new TypeError(load.name + ' detected as System.register but didn\'t execute.');
                                                                                                                       //
                                        if (anonRegister) entry = anonRegister;else load.metadata.bundle = true;       // 2924
                                                                                                                       //
                                        if (!entry && loader.defined[load.name]) entry = loader.defined[load.name];    // 2929
                                                                                                                       //
                                        anonRegister = null;                                                           // 2932
                                        calledRegister = false;                                                        // 2933
                                    }                                                                                  //
                                                                                                                       //
                        // named bundles are just an empty module                                                      //
                        if (!entry) entry = {                                                                          // 2937
                            declarative: false,                                                                        // 2939
                            deps: load.metadata.deps,                                                                  // 2940
                            execute: function () {                                                                     // 2941
                                return loader.newModule({});                                                           // 2942
                            }                                                                                          //
                        };                                                                                             //
                                                                                                                       //
                        // place this module onto defined for circular references                                      //
                        loader.defined[load.name] = entry;                                                             // 2947
                                                                                                                       //
                        var grouped = group(entry.deps);                                                               // 2949
                                                                                                                       //
                        entry.deps = grouped.names;                                                                    // 2951
                        entry.originalIndices = grouped.indices;                                                       // 2952
                        entry.name = load.name;                                                                        // 2953
                        entry.esmExports = load.metadata.esmExports !== false;                                         // 2954
                                                                                                                       //
                        // first, normalize all dependencies                                                           //
                        var normalizePromises = [];                                                                    // 2957
                        for (var i = 0, l = entry.deps.length; i < l; i++) normalizePromises.push(Promise.resolve(loader.normalize(entry.deps[i], load.name)));
                                                                                                                       //
                        return Promise.all(normalizePromises).then(function (normalizedDeps) {                         // 2961
                                                                                                                       //
                            entry.normalizedDeps = normalizedDeps;                                                     // 2963
                                                                                                                       //
                            return {                                                                                   // 2965
                                deps: entry.deps,                                                                      // 2966
                                execute: function () {                                                                 // 2967
                                    // recursively ensure that the module and all its                                  //
                                    // dependencies are linked (with dependency group handling)                        //
                                    link(load.name, loader);                                                           // 2970
                                                                                                                       //
                                    // now handle dependency execution in correct order                                //
                                    ensureEvaluated(load.name, [], loader);                                            // 2973
                                                                                                                       //
                                    // remove from the registry                                                        //
                                    loader.defined[load.name] = undefined;                                             // 2976
                                                                                                                       //
                                    // return the defined module object                                                //
                                    return loader.newModule(entry.declarative ? entry.module.exports : entry.esModule);
                                }                                                                                      //
                            };                                                                                         //
                        });                                                                                            //
                    };                                                                                                 //
                });                                                                                                    //
            })();                                                                                                      //
            /*                                                                                                         //
             * Extension to detect ES6 and auto-load Traceur or Babel for processing                                   //
             */                                                                                                        //
            (function () {                                                                                             // 2989
                // good enough ES6 module detection regex - format detections not designed to be accurate, but to handle the 99% use case
                var esmRegEx = /(^\s*|[}\);\n]\s*)(import\s+(['"]|(\*\s+as\s+)?[^"'\(\)\n;]+\s+from\s+['"]|\{)|export\s+\*\s+from\s+["']|export\s+(\{|default|function|class|var|const|let|async\s+function))/;
                                                                                                                       //
                var traceurRuntimeRegEx = /\$traceurRuntime\s*\./;                                                     // 2993
                var babelHelpersRegEx = /babelHelpers\s*\./;                                                           // 2994
                                                                                                                       //
                hook('translate', function (translate) {                                                               // 2996
                    return function (load) {                                                                           // 2997
                        var loader = this;                                                                             // 2998
                        return translate.call(loader, load).then(function (source) {                                   // 2999
                            // detect & transpile ES6                                                                  //
                            if (load.metadata.format == 'esm' || load.metadata.format == 'es6' || !load.metadata.format && source.match(esmRegEx)) {
                                if (load.metadata.format == 'es6') warn.call(loader, 'Module ' + load.name + ' has metadata setting its format to "es6", which is deprecated.\nThis should be updated to "esm".');
                                load.metadata.format = 'esm';                                                          // 3005
                                                                                                                       //
                                if (loader.transpiler === false) throw new TypeError('Unable to dynamically transpile ES module as System.transpiler set to false.');
                                                                                                                       //
                                // setting _loadedTranspiler = false tells the next block to                           //
                                // do checks for setting transpiler metadata                                           //
                                loader._loadedTranspiler = loader._loadedTranspiler || false;                          // 3012
                                if (loader.pluginLoader) loader.pluginLoader._loadedTranspiler = loader._loadedTranspiler || false;
                                                                                                                       //
                                // builder support                                                                     //
                                if (loader.builder) load.metadata.originalSource = load.source;                        // 3017
                                                                                                                       //
                                // defined in es6-module-loader/src/transpile.js                                       //
                                return transpile.call(loader, load).then(function (source) {                           // 3021
                                    // clear sourceMap as transpiler embeds it                                         //
                                    load.metadata.sourceMap = undefined;                                               // 3024
                                    return source;                                                                     // 3025
                                });                                                                                    //
                            }                                                                                          //
                                                                                                                       //
                            // load the transpiler correctly                                                           //
                            if (loader._loadedTranspiler === false && load.name == loader.normalizeSync(loader.transpiler)) {
                                // always load transpiler as a global                                                  //
                                if (source.length > 100) {                                                             // 3032
                                    load.metadata.format = load.metadata.format || 'global';                           // 3033
                                                                                                                       //
                                    if (loader.transpiler === 'traceur') load.metadata.exports = 'traceur';            // 3035
                                    if (loader.transpiler === 'typescript') load.metadata.exports = 'ts';              // 3037
                                }                                                                                      //
                                                                                                                       //
                                loader._loadedTranspiler = true;                                                       // 3041
                            }                                                                                          //
                                                                                                                       //
                            // load the transpiler runtime correctly                                                   //
                            if (loader._loadedTranspilerRuntime === false) {                                           // 3045
                                if (load.name == loader.normalizeSync('traceur-runtime') || load.name == loader.normalizeSync('babel/external-helpers*')) {
                                    if (source.length > 100) load.metadata.format = load.metadata.format || 'global';  // 3048
                                                                                                                       //
                                    loader._loadedTranspilerRuntime = true;                                            // 3051
                                }                                                                                      //
                            }                                                                                          //
                                                                                                                       //
                            // detect transpiler runtime usage to load runtimes                                        //
                            if (load.metadata.format == 'register' && loader._loadedTranspilerRuntime !== true) {      // 3056
                                if (!__global.$traceurRuntime && load.source.match(traceurRuntimeRegEx)) {             // 3057
                                    loader._loadedTranspilerRuntime = loader._loadedTranspilerRuntime || false;        // 3058
                                    return loader['import']('traceur-runtime').then(function () {                      // 3059
                                        return source;                                                                 // 3060
                                    });                                                                                //
                                }                                                                                      //
                                if (!__global.babelHelpers && load.source.match(babelHelpersRegEx)) {                  // 3063
                                    loader._loadedTranspilerRuntime = loader._loadedTranspilerRuntime || false;        // 3064
                                    return loader['import']('babel/external-helpers').then(function () {               // 3065
                                        return source;                                                                 // 3066
                                    });                                                                                //
                                }                                                                                      //
                            }                                                                                          //
                                                                                                                       //
                            return source;                                                                             // 3071
                        });                                                                                            //
                    };                                                                                                 //
                });                                                                                                    //
            })();                                                                                                      //
            /*                                                                                                         //
             SystemJS Global Format                                                                                    //
              Supports                                                                                                 //
             metadata.deps                                                                                             //
             metadata.globals                                                                                          //
             metadata.exports                                                                                          //
              Without metadata.exports, detects writes to the global object.                                           //
             */                                                                                                        //
            var __globalName = typeof self != 'undefined' ? 'self' : 'global';                                         // 3087
                                                                                                                       //
            hook('onScriptLoad', function (onScriptLoad) {                                                             // 3089
                return function (load) {                                                                               // 3090
                    if (load.metadata.format == 'global') {                                                            // 3091
                        load.metadata.registered = true;                                                               // 3092
                        var globalValue = readMemberExpression(load.metadata.exports, __global);                       // 3093
                        load.metadata.execute = function () {                                                          // 3094
                            return globalValue;                                                                        // 3095
                        };                                                                                             //
                    }                                                                                                  //
                    return onScriptLoad.call(this, load);                                                              // 3098
                };                                                                                                     //
            });                                                                                                        //
                                                                                                                       //
            hook('fetch', function (fetch) {                                                                           // 3102
                return function (load) {                                                                               // 3103
                    if (load.metadata.exports) load.metadata.format = 'global';                                        // 3104
                                                                                                                       //
                    // A global with exports, no globals and no deps                                                   //
                    // can be loaded via a script tag                                                                  //
                    if (load.metadata.format == 'global' && !load.metadata.authorization && load.metadata.exports && !load.metadata.globals && (!load.metadata.deps || load.metadata.deps.length == 0)) load.metadata.scriptLoad = true;
                                                                                                                       //
                    return fetch.call(this, load);                                                                     // 3114
                };                                                                                                     //
            });                                                                                                        //
                                                                                                                       //
            // ideally we could support script loading for globals, but the issue with that is that                    //
            // we can't do it with AMD support side-by-side since AMD support means defining the                       //
            // global define, and global support means not definining it, yet we don't have any hook                   //
            // into the "pre-execution" phase of a script tag being loaded to handle both cases                        //
                                                                                                                       //
            hook('instantiate', function (instantiate) {                                                               // 3124
                return function (load) {                                                                               // 3125
                    var loader = this;                                                                                 // 3126
                                                                                                                       //
                    if (!load.metadata.format) load.metadata.format = 'global';                                        // 3128
                                                                                                                       //
                    // globals shorthand support for:                                                                  //
                    // globals = ['Buffer'] where we just require 'Buffer' in the current context                      //
                    if (load.metadata.globals) {                                                                       // 3133
                        if (load.metadata.globals instanceof Array) {                                                  // 3134
                            var globals = {};                                                                          // 3135
                            for (var i = 0; i < load.metadata.globals.length; i++) globals[load.metadata.globals[i]] = load.metadata.globals[i];
                            load.metadata.globals = globals;                                                           // 3138
                        }                                                                                              //
                    }                                                                                                  //
                                                                                                                       //
                    // global is a fallback module format                                                              //
                    if (load.metadata.format == 'global' && !load.metadata.registered) {                               // 3143
                                                                                                                       //
                        for (var g in babelHelpers.sanitizeForInObject(load.metadata.globals)) load.metadata.deps.push(load.metadata.globals[g]);
                                                                                                                       //
                        load.metadata.execute = function (require, exports, module) {                                  // 3148
                                                                                                                       //
                            var globals;                                                                               // 3150
                            if (load.metadata.globals) {                                                               // 3151
                                globals = {};                                                                          // 3152
                                for (var g in babelHelpers.sanitizeForInObject(load.metadata.globals)) globals[g] = require(load.metadata.globals[g]);
                            }                                                                                          //
                                                                                                                       //
                            var exportName = load.metadata.exports;                                                    // 3157
                                                                                                                       //
                            if (exportName) load.source += '\n' + __globalName + '["' + exportName + '"] = ' + exportName + ';';
                                                                                                                       //
                            var retrieveGlobal = loader.get('@@global-helpers').prepareGlobal(module.id, exportName, globals);
                                                                                                                       //
                            __exec.call(loader, load);                                                                 // 3164
                                                                                                                       //
                            return retrieveGlobal();                                                                   // 3166
                        };                                                                                             //
                    }                                                                                                  //
                    return instantiate.call(this, load);                                                               // 3169
                };                                                                                                     //
            });                                                                                                        //
            hookConstructor(function (constructor) {                                                                   // 3172
                return function () {                                                                                   // 3173
                    var loader = this;                                                                                 // 3174
                    constructor.call(loader);                                                                          // 3175
                                                                                                                       //
                    var hasOwnProperty = Object.prototype.hasOwnProperty;                                              // 3177
                                                                                                                       //
                    // bare minimum ignores for IE8                                                                    //
                    var ignoredGlobalProps = ['_g', 'sessionStorage', 'localStorage', 'clipboardData', 'frames', 'external', 'mozAnimationStartTime', 'webkitStorageInfo', 'webkitIndexedDB'];
                                                                                                                       //
                    var globalSnapshot;                                                                                // 3182
                                                                                                                       //
                    function forEachGlobal(callback) {                                                                 // 3184
                        if (Object.keys) Object.keys(__global).forEach(callback);else for (var g in babelHelpers.sanitizeForInObject(__global)) {
                            if (!hasOwnProperty.call(__global, g)) continue;                                           // 3189
                            callback(g);                                                                               // 3191
                        }                                                                                              //
                    }                                                                                                  //
                                                                                                                       //
                    function forEachGlobalValue(callback) {                                                            // 3195
                        forEachGlobal(function (globalName) {                                                          // 3196
                            if (indexOf.call(ignoredGlobalProps, globalName) != -1) return;                            // 3197
                            try {                                                                                      // 3199
                                var value = __global[globalName];                                                      // 3200
                            } catch (e) {                                                                              //
                                ignoredGlobalProps.push(globalName);                                                   // 3203
                            }                                                                                          //
                            callback(globalName, value);                                                               // 3205
                        });                                                                                            //
                    }                                                                                                  //
                                                                                                                       //
                    loader.set('@@global-helpers', loader.newModule({                                                  // 3209
                        prepareGlobal: function (moduleName, exportName, globals) {                                    // 3210
                            // disable module detection                                                                //
                            var curDefine = __global.define;                                                           // 3212
                                                                                                                       //
                            __global.define = undefined;                                                               // 3214
                            __global.exports = undefined;                                                              // 3215
                            if (__global.module && __global.module.exports) __global.module = undefined;               // 3216
                                                                                                                       //
                            // set globals                                                                             //
                            var oldGlobals;                                                                            // 3220
                            if (globals) {                                                                             // 3221
                                oldGlobals = {};                                                                       // 3222
                                for (var g in babelHelpers.sanitizeForInObject(globals)) {                             // 3223
                                    oldGlobals[g] = globals[g];                                                        // 3224
                                    __global[g] = globals[g];                                                          // 3225
                                }                                                                                      //
                            }                                                                                          //
                                                                                                                       //
                            // store a complete copy of the global object in order to detect changes                   //
                            if (!exportName) {                                                                         // 3230
                                globalSnapshot = {};                                                                   // 3231
                                                                                                                       //
                                forEachGlobalValue(function (name, value) {                                            // 3233
                                    globalSnapshot[name] = value;                                                      // 3234
                                });                                                                                    //
                            }                                                                                          //
                                                                                                                       //
                            // return function to retrieve global                                                      //
                            return function () {                                                                       // 3239
                                var globalValue;                                                                       // 3240
                                                                                                                       //
                                if (exportName) {                                                                      // 3242
                                    globalValue = readMemberExpression(exportName, __global);                          // 3243
                                } else {                                                                               //
                                    var singleGlobal;                                                                  // 3246
                                    var multipleExports;                                                               // 3247
                                    var exports = {};                                                                  // 3248
                                                                                                                       //
                                    forEachGlobalValue(function (name, value) {                                        // 3250
                                        if (globalSnapshot[name] === value) return;                                    // 3251
                                        if (typeof value == 'undefined') return;                                       // 3253
                                        exports[name] = value;                                                         // 3255
                                                                                                                       //
                                        if (typeof singleGlobal != 'undefined') {                                      // 3257
                                            if (!multipleExports && singleGlobal !== value) multipleExports = true;    // 3258
                                        } else {                                                                       //
                                            singleGlobal = value;                                                      // 3262
                                        }                                                                              //
                                    });                                                                                //
                                    globalValue = multipleExports ? exports : singleGlobal;                            // 3265
                                }                                                                                      //
                                                                                                                       //
                                // revert globals                                                                      //
                                if (oldGlobals) {                                                                      // 3269
                                    for (var g in babelHelpers.sanitizeForInObject(oldGlobals)) __global[g] = oldGlobals[g];
                                }                                                                                      //
                                __global.define = curDefine;                                                           // 3273
                                                                                                                       //
                                return globalValue;                                                                    // 3275
                            };                                                                                         //
                        }                                                                                              //
                    }));                                                                                               //
                };                                                                                                     //
            });                                                                                                        //
            /*                                                                                                         //
             SystemJS CommonJS Format                                                                                  //
             */                                                                                                        //
            (function () {                                                                                             // 3284
                // CJS Module Format                                                                                   //
                // require('...') || exports[''] = ... || exports.asd = ... || module.exports = ...                    //
                var cjsExportsRegEx = /(?:^\uFEFF?|[^$_a-zA-Z\xA0-\uFFFF.]|module\.)exports\s*(\[['"]|\.)|(?:^\uFEFF?|[^$_a-zA-Z\xA0-\uFFFF.])module\.exports\s*[=,]/;
                // RegEx adjusted from https://github.com/jbrantly/yabble/blob/master/lib/yabble.js#L339               //
                var cjsRequireRegEx = /(?:^\uFEFF?|[^$_a-zA-Z\xA0-\uFFFF."'])require\s*\(\s*("[^"\\]*(?:\\.[^"\\]*)*"|'[^'\\]*(?:\\.[^'\\]*)*')\s*\)/g;
                var commentRegEx = /(\/\*([\s\S]*?)\*\/|([^:]|^)\/\/(.*)$)/mg;                                         // 3290
                                                                                                                       //
                function getCJSDeps(source) {                                                                          // 3292
                    cjsRequireRegEx.lastIndex = commentRegEx.lastIndex = 0;                                            // 3293
                                                                                                                       //
                    var deps = [];                                                                                     // 3295
                                                                                                                       //
                    // track comments in the source                                                                    //
                    var match;                                                                                         // 3298
                                                                                                                       //
                    var commentLocations = [];                                                                         // 3300
                    if (source.length / source.split('\n').length < 200) {                                             // 3301
                        while (match = commentRegEx.exec(source)) commentLocations.push([match.index, match.index + match[0].length]);
                    }                                                                                                  //
                                                                                                                       //
                    while (match = cjsRequireRegEx.exec(source)) {                                                     // 3306
                        // ensure we're not in a comment location                                                      //
                        var inComment = false;                                                                         // 3308
                        for (var i = 0; i < commentLocations.length; i++) {                                            // 3309
                            if (commentLocations[i][0] < match.index && commentLocations[i][1] > match.index + match[0].length) inComment = true;
                        }                                                                                              //
                        if (!inComment) deps.push(match[1].substr(1, match[1].length - 2));                            // 3313
                    }                                                                                                  //
                                                                                                                       //
                    return deps;                                                                                       // 3317
                }                                                                                                      //
                                                                                                                       //
                if (typeof window != 'undefined' && typeof document != 'undefined' && window.location) var windowOrigin = location.protocol + '//' + location.hostname + (location.port ? ':' + location.port : '');
                                                                                                                       //
                hook('instantiate', function (instantiate) {                                                           // 3323
                    return function (load) {                                                                           // 3324
                        var loader = this;                                                                             // 3325
                        if (!load.metadata.format) {                                                                   // 3326
                            cjsExportsRegEx.lastIndex = 0;                                                             // 3327
                            cjsRequireRegEx.lastIndex = 0;                                                             // 3328
                            if (cjsRequireRegEx.exec(load.source) || cjsExportsRegEx.exec(load.source)) load.metadata.format = 'cjs';
                        }                                                                                              //
                                                                                                                       //
                        if (load.metadata.format == 'cjs') {                                                           // 3333
                            var metaDeps = load.metadata.deps || [];                                                   // 3334
                            load.metadata.deps = metaDeps.concat(getCJSDeps(load.source));                             // 3335
                                                                                                                       //
                            for (var g in babelHelpers.sanitizeForInObject(load.metadata.globals)) load.metadata.deps.push(load.metadata.globals[g]);
                                                                                                                       //
                            load.metadata.executingRequire = true;                                                     // 3340
                                                                                                                       //
                            load.metadata.execute = function (require, exports, module) {                              // 3342
                                // ensure meta deps execute first                                                      //
                                for (var i = 0; i < metaDeps.length; i++) require(metaDeps[i]);                        // 3344
                                var address = load.address || '';                                                      // 3346
                                                                                                                       //
                                var dirname = address.split('/');                                                      // 3348
                                dirname.pop();                                                                         // 3349
                                dirname = dirname.join('/');                                                           // 3350
                                                                                                                       //
                                if (address.substr(0, 8) == 'file:///') {                                              // 3352
                                    address = address.substr(7);                                                       // 3353
                                    dirname = dirname.substr(7);                                                       // 3354
                                                                                                                       //
                                    // on windows remove leading '/'                                                   //
                                    if (isWindows) {                                                                   // 3357
                                        address = address.substr(1);                                                   // 3358
                                        dirname = dirname.substr(1);                                                   // 3359
                                    }                                                                                  //
                                } else if (windowOrigin && address.substr(0, windowOrigin.length) === windowOrigin) {  //
                                    address = address.substr(windowOrigin.length);                                     // 3363
                                    dirname = dirname.substr(windowOrigin.length);                                     // 3364
                                }                                                                                      //
                                                                                                                       //
                                // disable AMD detection                                                               //
                                var define = __global.define;                                                          // 3368
                                __global.define = undefined;                                                           // 3369
                                                                                                                       //
                                __global.__cjsWrapper = {                                                              // 3371
                                    exports: exports,                                                                  // 3372
                                    args: [require, exports, module, address, dirname, __global, __global]             // 3373
                                };                                                                                     //
                                                                                                                       //
                                var globals = '';                                                                      // 3376
                                if (load.metadata.globals) {                                                           // 3377
                                    for (var g in babelHelpers.sanitizeForInObject(load.metadata.globals)) globals += 'var ' + g + ' = require("' + load.metadata.globals[g] + '");';
                                }                                                                                      //
                                                                                                                       //
                                load.source = "(function(require, exports, module, __filename, __dirname, global, GLOBAL) {" + globals + load.source + "\n}).apply(__cjsWrapper.exports, __cjsWrapper.args);";
                                                                                                                       //
                                __exec.call(loader, load);                                                             // 3385
                                                                                                                       //
                                __global.__cjsWrapper = undefined;                                                     // 3387
                                __global.define = define;                                                              // 3388
                            };                                                                                         //
                        }                                                                                              //
                                                                                                                       //
                        return instantiate.call(loader, load);                                                         // 3392
                    };                                                                                                 //
                });                                                                                                    //
            })();                                                                                                      //
            /*                                                                                                         //
             * AMD Helper function module                                                                              //
             * Separated into its own file as this is the part needed for full AMD support in SFX builds               //
             *                                                                                                         //
             */                                                                                                        //
            hookConstructor(function (constructor) {                                                                   // 3401
                return function () {                                                                                   // 3402
                    var loader = this;                                                                                 // 3403
                    constructor.call(this);                                                                            // 3404
                                                                                                                       //
                    var commentRegEx = /(\/\*([\s\S]*?)\*\/|([^:]|^)\/\/(.*)$)/mg;                                     // 3406
                    var cjsRequirePre = '(?:^|[^$_a-zA-Z\\xA0-\\uFFFF.])';                                             // 3407
                    var cjsRequirePost = "\\s*\\(\\s*(\"([^\"]+)\"|'([^']+)')\\s*\\)";                                 // 3408
                    var fnBracketRegEx = /\(([^\)]*)\)/;                                                               // 3409
                    var wsRegEx = /^\s+|\s+$/g;                                                                        // 3410
                                                                                                                       //
                    var requireRegExs = {};                                                                            // 3412
                                                                                                                       //
                    function getCJSDeps(source, requireIndex) {                                                        // 3414
                                                                                                                       //
                        // remove comments                                                                             //
                        source = source.replace(commentRegEx, '');                                                     // 3417
                                                                                                                       //
                        // determine the require alias                                                                 //
                        var params = source.match(fnBracketRegEx);                                                     // 3420
                        var requireAlias = (params[1].split(',')[requireIndex] || 'require').replace(wsRegEx, '');     // 3421
                                                                                                                       //
                        // find or generate the regex for this requireAlias                                            //
                        var requireRegEx = requireRegExs[requireAlias] || (requireRegExs[requireAlias] = new RegExp(cjsRequirePre + requireAlias + cjsRequirePost, 'g'));
                                                                                                                       //
                        requireRegEx.lastIndex = 0;                                                                    // 3426
                                                                                                                       //
                        var deps = [];                                                                                 // 3428
                                                                                                                       //
                        var match;                                                                                     // 3430
                        while (match = requireRegEx.exec(source)) deps.push(match[2] || match[3]);                     // 3431
                                                                                                                       //
                        return deps;                                                                                   // 3434
                    }                                                                                                  //
                                                                                                                       //
                    /*                                                                                                 //
                     AMD-compatible require                                                                            //
                     To copy RequireJS, set window.require = window.requirejs = loader.amdRequire                      //
                     */                                                                                                //
                    function require(names, callback, errback, referer) {                                              // 3441
                        // in amd, first arg can be a config object... we just ignore                                  //
                        if (typeof names == 'object' && !(names instanceof Array)) return require.apply(null, Array.prototype.splice.call(arguments, 1, arguments.length - 1));
                                                                                                                       //
                        // amd require                                                                                 //
                        if (typeof names == 'string' && typeof callback == 'function') names = [names];                // 3447
                        if (names instanceof Array) {                                                                  // 3449
                            var dynamicRequires = [];                                                                  // 3450
                            for (var i = 0; i < names.length; i++) dynamicRequires.push(loader['import'](names[i], referer));
                            Promise.all(dynamicRequires).then(function (modules) {                                     // 3453
                                if (callback) callback.apply(null, modules);                                           // 3454
                            }, errback);                                                                               //
                        }                                                                                              //
                                                                                                                       //
                        // commonjs require                                                                            //
                        else if (typeof names == 'string') {                                                           //
                                var module = loader.get(loader.normalizeSync(names, referer));                         // 3461
                                if (!module) throw new Error('Module not already loaded loading "' + names + '" from "' + referer + '".');
                                return module.__useDefault ? module['default'] : module;                               // 3464
                            } else throw new TypeError('Invalid require');                                             //
                    }                                                                                                  //
                                                                                                                       //
                    function define(name, deps, factory) {                                                             // 3471
                        if (typeof name != 'string') {                                                                 // 3472
                            factory = deps;                                                                            // 3473
                            deps = name;                                                                               // 3474
                            name = null;                                                                               // 3475
                        }                                                                                              //
                        if (!(deps instanceof Array)) {                                                                // 3477
                            factory = deps;                                                                            // 3478
                            deps = ['require', 'exports', 'module'].splice(0, factory.length);                         // 3479
                        }                                                                                              //
                                                                                                                       //
                        if (typeof factory != 'function') factory = (function (factory) {                              // 3482
                            return function () {                                                                       // 3484
                                return factory;                                                                        // 3484
                            };                                                                                         //
                        })(factory);                                                                                   //
                                                                                                                       //
                        // in IE8, a trailing comma becomes a trailing undefined entry                                 //
                        if (deps[deps.length - 1] === undefined) deps.pop();                                           // 3488
                                                                                                                       //
                        // remove system dependencies                                                                  //
                        var requireIndex, exportsIndex, moduleIndex;                                                   // 3492
                                                                                                                       //
                        if ((requireIndex = indexOf.call(deps, 'require')) != -1) {                                    // 3494
                                                                                                                       //
                            deps.splice(requireIndex, 1);                                                              // 3496
                                                                                                                       //
                            // only trace cjs requires for non-named                                                   //
                            // named defines assume the trace has already been done                                    //
                            if (!name) deps = deps.concat(getCJSDeps(factory.toString(), requireIndex));               // 3500
                        }                                                                                              //
                                                                                                                       //
                        if ((exportsIndex = indexOf.call(deps, 'exports')) != -1) deps.splice(exportsIndex, 1);        // 3504
                                                                                                                       //
                        if ((moduleIndex = indexOf.call(deps, 'module')) != -1) deps.splice(moduleIndex, 1);           // 3507
                                                                                                                       //
                        var define = {                                                                                 // 3510
                            name: name,                                                                                // 3511
                            deps: deps,                                                                                // 3512
                            execute: function (req, exports, module) {                                                 // 3513
                                                                                                                       //
                                var depValues = [];                                                                    // 3515
                                for (var i = 0; i < deps.length; i++) depValues.push(req(deps[i]));                    // 3516
                                                                                                                       //
                                module.uri = module.id;                                                                // 3519
                                                                                                                       //
                                module.config = function () {};                                                        // 3521
                                                                                                                       //
                                // add back in system dependencies                                                     //
                                if (moduleIndex != -1) depValues.splice(moduleIndex, 0, module);                       // 3524
                                                                                                                       //
                                if (exportsIndex != -1) depValues.splice(exportsIndex, 0, exports);                    // 3527
                                                                                                                       //
                                if (requireIndex != -1) {                                                              // 3530
                                    function contextualRequire(names, callback, errback) {                             // 3531
                                        if (typeof names == 'string' && typeof callback != 'function') return req(names);
                                        return require.call(loader, names, callback, errback, module.id);              // 3534
                                    }                                                                                  //
                                    contextualRequire.toUrl = function (name) {                                        // 3536
                                        // normalize without defaultJSExtensions                                       //
                                        var defaultJSExtension = loader.defaultJSExtensions && name.substr(name.length - 3, 3) != '.js';
                                        var url = loader.normalizeSync(name, module.id);                               // 3539
                                        if (defaultJSExtension && url.substr(url.length - 3, 3) == '.js') url = url.substr(0, url.length - 3);
                                        return url;                                                                    // 3542
                                    };                                                                                 //
                                    depValues.splice(requireIndex, 0, contextualRequire);                              // 3544
                                }                                                                                      //
                                                                                                                       //
                                // set global require to AMD require                                                   //
                                var curRequire = __global.require;                                                     // 3548
                                __global.require = require;                                                            // 3549
                                                                                                                       //
                                var output = factory.apply(exportsIndex == -1 ? __global : exports, depValues);        // 3551
                                                                                                                       //
                                __global.require = curRequire;                                                         // 3553
                                                                                                                       //
                                if (typeof output == 'undefined' && module) output = module.exports;                   // 3555
                                                                                                                       //
                                if (typeof output != 'undefined') return output;                                       // 3558
                            }                                                                                          //
                        };                                                                                             //
                                                                                                                       //
                        // anonymous define                                                                            //
                        if (!name) {                                                                                   // 3564
                            // already defined anonymously -> throw                                                    //
                            if (lastModule.anonDefine) throw new TypeError('Multiple defines for anonymous module');   // 3566
                            lastModule.anonDefine = define;                                                            // 3568
                        }                                                                                              //
                        // named define                                                                                //
                        else {                                                                                         //
                                // if we don't have any other defines,                                                 //
                                // then let this be an anonymous define                                                //
                                // this is just to support single modules of the form:                                 //
                                // define('jquery')                                                                    //
                                // still loading anonymously                                                           //
                                // because it is done widely enough to be useful                                       //
                                if (!lastModule.anonDefine && !lastModule.isBundle) {                                  // 3578
                                    lastModule.anonDefine = define;                                                    // 3579
                                }                                                                                      //
                                // otherwise its a bundle only                                                         //
                                else {                                                                                 //
                                        // if there is an anonDefine already (we thought it could have had a single named define)
                                        // then we define it now                                                       //
                                        // this is to avoid defining named defines when they are actually anonymous    //
                                        if (lastModule.anonDefine && lastModule.anonDefine.name) loader.registerDynamic(lastModule.anonDefine.name, lastModule.anonDefine.deps, false, lastModule.anonDefine.execute);
                                                                                                                       //
                                        lastModule.anonDefine = null;                                                  // 3589
                                    }                                                                                  //
                                                                                                                       //
                                // note this is now a bundle                                                           //
                                lastModule.isBundle = true;                                                            // 3593
                                                                                                                       //
                                // define the module through the register registry                                     //
                                loader.registerDynamic(name, define.deps, false, define.execute);                      // 3596
                            }                                                                                          //
                    }                                                                                                  //
                    define.amd = {};                                                                                   // 3599
                                                                                                                       //
                    // adds define as a global (potentially just temporarily)                                          //
                    function createDefine(loader) {                                                                    // 3602
                        lastModule.anonDefine = null;                                                                  // 3603
                        lastModule.isBundle = false;                                                                   // 3604
                                                                                                                       //
                        // ensure no NodeJS environment detection                                                      //
                        var oldModule = __global.module;                                                               // 3607
                        var oldExports = __global.exports;                                                             // 3608
                        var oldDefine = __global.define;                                                               // 3609
                                                                                                                       //
                        __global.module = undefined;                                                                   // 3611
                        __global.exports = undefined;                                                                  // 3612
                        __global.define = define;                                                                      // 3613
                                                                                                                       //
                        return function () {                                                                           // 3615
                            __global.define = oldDefine;                                                               // 3616
                            __global.module = oldModule;                                                               // 3617
                            __global.exports = oldExports;                                                             // 3618
                        };                                                                                             //
                    }                                                                                                  //
                                                                                                                       //
                    var lastModule = {                                                                                 // 3622
                        isBundle: false,                                                                               // 3623
                        anonDefine: null                                                                               // 3624
                    };                                                                                                 //
                                                                                                                       //
                    loader.set('@@amd-helpers', loader.newModule({                                                     // 3627
                        createDefine: createDefine,                                                                    // 3628
                        require: require,                                                                              // 3629
                        define: define,                                                                                // 3630
                        lastModule: lastModule                                                                         // 3631
                    }));                                                                                               //
                    loader.amdDefine = define;                                                                         // 3633
                    loader.amdRequire = require;                                                                       // 3634
                };                                                                                                     //
            }); /*                                                                                                     //
                SystemJS AMD Format                                                                                    //
                Provides the AMD module format definition at System.format.amd                                         //
                as well as a RequireJS-style require on System.require                                                 //
                */                                                                                                     //
            (function () {                                                                                             // 3641
                // AMD Module Format Detection RegEx                                                                   //
                // define([.., .., ..], ...)                                                                           //
                // define(varName); || define(function(require, exports) {}); || define({})                            //
                var amdRegEx = /(?:^\uFEFF?|[^$_a-zA-Z\xA0-\uFFFF.])define\s*\(\s*("[^"]+"\s*,\s*|'[^']+'\s*,\s*)?\s*(\[(\s*(("[^"]+"|'[^']+')\s*,|\/\/.*\r?\n|\/\*(.|\s)*?\*\/))*(\s*("[^"]+"|'[^']+')\s*,?)?(\s*(\/\/.*\r?\n|\/\*(.|\s)*?\*\/))*\s*\]|function\s*|{|[_$a-zA-Z\xA0-\uFFFF][_$a-zA-Z0-9\xA0-\uFFFF]*\))/;
                                                                                                                       //
                // script injection mode calls this function synchronously on load                                     //
                hook('onScriptLoad', function (onScriptLoad) {                                                         // 3648
                    return function (load) {                                                                           // 3649
                        onScriptLoad.call(this, load);                                                                 // 3650
                                                                                                                       //
                        var lastModule = this.get('@@amd-helpers').lastModule;                                         // 3652
                        if (lastModule.anonDefine || lastModule.isBundle) {                                            // 3653
                            load.metadata.format = 'defined';                                                          // 3654
                            load.metadata.registered = true;                                                           // 3655
                            lastModule.isBundle = false;                                                               // 3656
                        }                                                                                              //
                                                                                                                       //
                        if (lastModule.anonDefine) {                                                                   // 3659
                            load.metadata.deps = load.metadata.deps ? load.metadata.deps.concat(lastModule.anonDefine.deps) : lastModule.anonDefine.deps;
                            load.metadata.execute = lastModule.anonDefine.execute;                                     // 3661
                            lastModule.anonDefine = null;                                                              // 3662
                        }                                                                                              //
                    };                                                                                                 //
                });                                                                                                    //
                                                                                                                       //
                hook('fetch', function (fetch) {                                                                       // 3667
                    return function (load) {                                                                           // 3668
                        if (load.metadata.format === 'amd' && !load.metadata.authorization) load.metadata.scriptLoad = true;
                        if (load.metadata.scriptLoad) this.get('@@amd-helpers').createDefine(this);                    // 3671
                        return fetch.call(this, load);                                                                 // 3673
                    };                                                                                                 //
                });                                                                                                    //
                                                                                                                       //
                hook('instantiate', function (instantiate) {                                                           // 3677
                    return function (load) {                                                                           // 3678
                        var loader = this;                                                                             // 3679
                                                                                                                       //
                        if (load.metadata.format == 'amd' || !load.metadata.format && load.source.match(amdRegEx)) {   // 3681
                            load.metadata.format = 'amd';                                                              // 3682
                                                                                                                       //
                            if (!loader.builder && loader.execute !== false) {                                         // 3684
                                var removeDefine = this.get('@@amd-helpers').createDefine(loader);                     // 3685
                                                                                                                       //
                                __exec.call(loader, load);                                                             // 3687
                                                                                                                       //
                                removeDefine(loader);                                                                  // 3689
                                                                                                                       //
                                var lastModule = this.get('@@amd-helpers').lastModule;                                 // 3691
                                                                                                                       //
                                if (!lastModule.anonDefine && !lastModule.isBundle) throw new TypeError('AMD module ' + load.name + ' did not define');
                                                                                                                       //
                                if (lastModule.anonDefine) {                                                           // 3696
                                    load.metadata.deps = load.metadata.deps ? load.metadata.deps.concat(lastModule.anonDefine.deps) : lastModule.anonDefine.deps;
                                    load.metadata.execute = lastModule.anonDefine.execute;                             // 3698
                                }                                                                                      //
                                                                                                                       //
                                lastModule.isBundle = false;                                                           // 3701
                                lastModule.anonDefine = null;                                                          // 3702
                            } else {                                                                                   //
                                load.metadata.execute = function () {                                                  // 3705
                                    return load.metadata.builderExecute.apply(this, arguments);                        // 3706
                                };                                                                                     //
                            }                                                                                          //
                                                                                                                       //
                            return instantiate.call(loader, load);                                                     // 3710
                        }                                                                                              //
                                                                                                                       //
                        return instantiate.call(loader, load);                                                         // 3713
                    };                                                                                                 //
                });                                                                                                    //
            })();                                                                                                      //
            /*                                                                                                         //
             SystemJS Loader Plugin Support                                                                            //
              Supports plugin loader syntax with "!", or via metadata.loader                                           //
              The plugin name is loaded as a module itself, and can override standard loader hooks                     //
             for the plugin resource. See the plugin section of the systemjs readme.                                   //
             */                                                                                                        //
            (function () {                                                                                             // 3726
                                                                                                                       //
                // sync or async plugin normalize function                                                             //
                function normalizePlugin(normalize, name, parentName, isPlugin, sync) {                                // 3729
                    var loader = this;                                                                                 // 3730
                    // if parent is a plugin, normalize against the parent plugin argument only                        //
                    if (parentName) {                                                                                  // 3732
                        var parentPluginIndex;                                                                         // 3733
                        if (loader.pluginFirst) {                                                                      // 3734
                            if ((parentPluginIndex = parentName.lastIndexOf('!')) != -1) parentName = parentName.substr(parentPluginIndex + 1);
                        } else {                                                                                       //
                            if ((parentPluginIndex = parentName.indexOf('!')) != -1) parentName = parentName.substr(0, parentPluginIndex);
                        }                                                                                              //
                    }                                                                                                  //
                                                                                                                       //
                    // if this is a plugin, normalize the plugin name and the argument                                 //
                    var pluginIndex = name.lastIndexOf('!');                                                           // 3745
                    if (pluginIndex != -1) {                                                                           // 3746
                        var argumentName;                                                                              // 3747
                        var pluginName;                                                                                // 3748
                                                                                                                       //
                        if (loader.pluginFirst) {                                                                      // 3750
                            argumentName = name.substr(pluginIndex + 1);                                               // 3751
                            pluginName = name.substr(0, pluginIndex);                                                  // 3752
                        } else {                                                                                       //
                            argumentName = name.substr(0, pluginIndex);                                                // 3755
                            pluginName = name.substr(pluginIndex + 1) || argumentName.substr(argumentName.lastIndexOf('.') + 1);
                        }                                                                                              //
                                                                                                                       //
                        // note if normalize will add a default js extension                                           //
                        // if so, remove for backwards compat                                                          //
                        // this is strange and sucks, but will be deprecated                                           //
                        var defaultExtension = loader.defaultJSExtensions && argumentName.substr(argumentName.length - 3, 3) != '.js';
                                                                                                                       //
                        // put name back together after parts have been normalized                                     //
                        function normalizePluginParts(argumentName, pluginName) {                                      // 3765
                            if (defaultExtension && argumentName.substr(argumentName.length - 3, 3) == '.js') argumentName = argumentName.substr(0, argumentName.length - 3);
                                                                                                                       //
                            if (loader.pluginFirst) {                                                                  // 3769
                                return pluginName + '!' + argumentName;                                                // 3770
                            } else {                                                                                   //
                                return argumentName + '!' + pluginName;                                                // 3773
                            }                                                                                          //
                        }                                                                                              //
                                                                                                                       //
                        if (sync) {                                                                                    // 3777
                            argumentName = loader.normalizeSync(argumentName, parentName);                             // 3778
                            pluginName = loader.normalizeSync(pluginName, parentName);                                 // 3779
                                                                                                                       //
                            return normalizePluginParts(argumentName, pluginName);                                     // 3781
                        } else {                                                                                       //
                            // third argument represents that this is a plugin call                                    //
                            // which in turn will skip default extension adding within packages                        //
                            return Promise.all([loader.normalize(argumentName, parentName, true), loader.normalize(pluginName, parentName, true)]).then(function (normalized) {
                                return normalizePluginParts(normalized[0], normalized[1]);                             // 3791
                            });                                                                                        //
                        }                                                                                              //
                    } else {                                                                                           //
                        return normalize.call(loader, name, parentName, isPlugin);                                     // 3796
                    }                                                                                                  //
                }                                                                                                      //
                                                                                                                       //
                // async plugin normalize                                                                              //
                hook('normalize', function (normalize) {                                                               // 3801
                    return function (name, parentName, isPlugin) {                                                     // 3802
                        return normalizePlugin.call(this, normalize, name, parentName, isPlugin, false);               // 3803
                    };                                                                                                 //
                });                                                                                                    //
                                                                                                                       //
                hook('normalizeSync', function (normalizeSync) {                                                       // 3807
                    return function (name, parentName, isPlugin) {                                                     // 3808
                        return normalizePlugin.call(this, normalizeSync, name, parentName, isPlugin, true);            // 3809
                    };                                                                                                 //
                });                                                                                                    //
                                                                                                                       //
                hook('locate', function (locate) {                                                                     // 3813
                    return function (load) {                                                                           // 3814
                        var loader = this;                                                                             // 3815
                                                                                                                       //
                        var name = load.name;                                                                          // 3817
                                                                                                                       //
                        // plugin syntax                                                                               //
                        var pluginSyntaxIndex;                                                                         // 3820
                        if (loader.pluginFirst) {                                                                      // 3821
                            if ((pluginSyntaxIndex = name.indexOf('!')) != -1) {                                       // 3822
                                load.metadata.loader = name.substr(0, pluginSyntaxIndex);                              // 3823
                                load.name = name.substr(pluginSyntaxIndex + 1);                                        // 3824
                            }                                                                                          //
                        } else {                                                                                       //
                            if ((pluginSyntaxIndex = name.lastIndexOf('!')) != -1) {                                   // 3828
                                load.metadata.loader = name.substr(pluginSyntaxIndex + 1);                             // 3829
                                load.name = name.substr(0, pluginSyntaxIndex);                                         // 3830
                            }                                                                                          //
                        }                                                                                              //
                                                                                                                       //
                        return locate.call(loader, load).then(function (address) {                                     // 3834
                            var plugin = load.metadata.loader;                                                         // 3836
                                                                                                                       //
                            if (!plugin) return address;                                                               // 3838
                                                                                                                       //
                            // only fetch the plugin itself if this name isn't defined                                 //
                            if (loader.defined && loader.defined[name]) return address;                                // 3842
                                                                                                                       //
                            var pluginLoader = loader.pluginLoader || loader;                                          // 3845
                                                                                                                       //
                            // load the plugin module and run standard locate                                          //
                            return pluginLoader['import'](plugin).then(function (loaderModule) {                       // 3848
                                // store the plugin module itself on the metadata                                      //
                                load.metadata.loaderModule = loaderModule;                                             // 3851
                                                                                                                       //
                                load.address = address;                                                                // 3853
                                if (loaderModule.locate) return loaderModule.locate.call(loader, load);                // 3854
                                                                                                                       //
                                return address;                                                                        // 3857
                            });                                                                                        //
                        });                                                                                            //
                    };                                                                                                 //
                });                                                                                                    //
                                                                                                                       //
                hook('fetch', function (fetch) {                                                                       // 3863
                    return function (load) {                                                                           // 3864
                        var loader = this;                                                                             // 3865
                        if (load.metadata.loaderModule && load.metadata.loaderModule.fetch) {                          // 3866
                            load.metadata.scriptLoad = false;                                                          // 3867
                            return load.metadata.loaderModule.fetch.call(loader, load, function (load) {               // 3868
                                return fetch.call(loader, load);                                                       // 3869
                            });                                                                                        //
                        } else {                                                                                       //
                            return fetch.call(loader, load);                                                           // 3873
                        }                                                                                              //
                    };                                                                                                 //
                });                                                                                                    //
                                                                                                                       //
                hook('translate', function (translate) {                                                               // 3878
                    return function (load) {                                                                           // 3879
                        var loader = this;                                                                             // 3880
                        if (load.metadata.loaderModule && load.metadata.loaderModule.translate) return Promise.resolve(load.metadata.loaderModule.translate.call(loader, load)).then(function (result) {
                            if (typeof result == 'string') load.source = result;                                       // 3883
                            return translate.call(loader, load);                                                       // 3885
                        });else return translate.call(loader, load);                                                   //
                    };                                                                                                 //
                });                                                                                                    //
                                                                                                                       //
                hook('instantiate', function (instantiate) {                                                           // 3892
                    return function (load) {                                                                           // 3893
                        var loader = this;                                                                             // 3894
                                                                                                                       //
                        /*                                                                                             //
                         * Source map sanitization for load.metadata.sourceMap                                         //
                         * Used to set browser and build-level source maps for                                         //
                         * translated sources in a general way.                                                        //
                         */                                                                                            //
                        var sourceMap = load.metadata.sourceMap;                                                       // 3901
                                                                                                                       //
                        // if an object not a JSON string do sanitizing                                                //
                        if (sourceMap && typeof sourceMap == 'object') {                                               // 3904
                            var originalName = load.name.split('!')[0];                                                // 3905
                                                                                                                       //
                            // force set the filename of the original file                                             //
                            sourceMap.file = originalName + '!transpiled';                                             // 3908
                                                                                                                       //
                            // force set the sources list if only one source                                           //
                            if (!sourceMap.sources || sourceMap.sources.length == 1) sourceMap.sources = [originalName];
                            load.metadata.sourceMap = JSON.stringify(sourceMap);                                       // 3913
                        }                                                                                              //
                                                                                                                       //
                        if (load.metadata.loaderModule && load.metadata.loaderModule.instantiate) return Promise.resolve(load.metadata.loaderModule.instantiate.call(loader, load)).then(function (result) {
                            load.metadata.format = 'defined';                                                          // 3918
                            load.metadata.execute = function () {                                                      // 3919
                                return result;                                                                         // 3920
                            };                                                                                         //
                            return instantiate.call(loader, load);                                                     // 3922
                        });else return instantiate.call(loader, load);                                                 //
                    };                                                                                                 //
                });                                                                                                    //
            })();                                                                                                      //
            /*                                                                                                         //
             * Conditions Extension                                                                                    //
             *                                                                                                         //
             *   Allows a condition module to alter the resolution of an import via syntax:                            //
             *                                                                                                         //
             *     import $ from 'jquery/#{browser}';                                                                  //
             *                                                                                                         //
             *   Will first load the module 'browser' via `System.import('browser')` and                               //
             *   take the default export of that module.                                                               //
             *   If the default export is not a string, an error is thrown.                                            //
             *                                                                                                         //
             *   We then substitute the string into the require to get the conditional resolution                      //
             *   enabling environment-specific variations like:                                                        //
             *                                                                                                         //
             *     import $ from 'jquery/ie'                                                                           //
             *     import $ from 'jquery/firefox'                                                                      //
             *     import $ from 'jquery/chrome'                                                                       //
             *     import $ from 'jquery/safari'                                                                       //
             *                                                                                                         //
             *   It can be useful for a condition module to define multiple conditions.                                //
             *   This can be done via the `|` modifier to specify an export member expression:                         //
             *                                                                                                         //
             *     import 'jquery/#{./browser.js|grade.version}'                                                       //
             *                                                                                                         //
             *   Where the `grade` export `version` member in the `browser.js` module  is substituted.                 //
             *                                                                                                         //
             *                                                                                                         //
             * Boolean Conditionals                                                                                    //
             *                                                                                                         //
             *   For polyfill modules, that are used as imports but have no module value,                              //
             *   a binary conditional allows a module not to be loaded at all if not needed:                           //
             *                                                                                                         //
             *     import 'es5-shim#?./conditions.js|needs-es5shim'                                                    //
             *                                                                                                         //
             *   These conditions can also be negated via:                                                             //
             *                                                                                                         //
             *     import 'es5-shim#?~./conditions.js|es6'                                                             //
             *                                                                                                         //
             */                                                                                                        //
                                                                                                                       //
            function parseCondition(condition) {                                                                       // 3970
                var conditionExport, conditionModule, negation;                                                        // 3971
                                                                                                                       //
                var negation = condition[0] == '~';                                                                    // 3973
                var conditionExportIndex = condition.lastIndexOf('|');                                                 // 3974
                if (conditionExportIndex != -1) {                                                                      // 3975
                    conditionExport = condition.substr(conditionExportIndex + 1);                                      // 3976
                    conditionModule = condition.substr(negation, conditionExportIndex - negation) || '@system-env';    // 3977
                } else {                                                                                               //
                    conditionExport = null;                                                                            // 3980
                    conditionModule = condition.substr(negation);                                                      // 3981
                }                                                                                                      //
                                                                                                                       //
                return {                                                                                               // 3984
                    module: conditionModule,                                                                           // 3985
                    prop: conditionExport,                                                                             // 3986
                    negate: negation                                                                                   // 3987
                };                                                                                                     //
            }                                                                                                          //
                                                                                                                       //
            function serializeCondition(conditionObj) {                                                                // 3991
                return (conditionObj.negate ? '~' : '') + conditionObj.module + (conditionObj.prop ? '|' + conditionObj.prop : '');
            }                                                                                                          //
                                                                                                                       //
            function resolveCondition(conditionObj, parentName, bool) {                                                // 3995
                return this['import'](conditionObj.module, parentName).then(function (m) {                             // 3996
                    if (conditionObj.prop) m = readMemberExpression(conditionObj.prop, m);else if (typeof m == 'object' && m + '' == 'Module') m = m['default'];
                                                                                                                       //
                    return conditionObj.negate ? !m : m;                                                               // 4003
                });                                                                                                    //
            }                                                                                                          //
                                                                                                                       //
            var interpolationRegEx = /#\{[^\}]+\}/;                                                                    // 4007
            function interpolateConditional(name, parentName) {                                                        // 4008
                // first we normalize the conditional                                                                  //
                var conditionalMatch = name.match(interpolationRegEx);                                                 // 4010
                                                                                                                       //
                if (!conditionalMatch) return Promise.resolve(name);                                                   // 4012
                                                                                                                       //
                var conditionObj = parseCondition(conditionalMatch[0].substr(2, conditionalMatch[0].length - 3));      // 4015
                                                                                                                       //
                // in builds, return normalized conditional                                                            //
                if (this.builder) return this['normalize'](conditionObj.module, parentName).then(function (conditionModule) {
                    conditionObj.conditionModule = conditionModule;                                                    // 4021
                    return name.replace(interpolationRegEx, '#{' + serializeCondition(conditionObj) + '}');            // 4022
                });                                                                                                    //
                                                                                                                       //
                return resolveCondition.call(this, conditionObj, parentName, false).then(function (conditionValue) {   // 4025
                    if (typeof conditionValue !== 'string') throw new TypeError('The condition value for ' + name + ' doesn\'t resolve to a string.');
                                                                                                                       //
                    return name.replace(interpolationRegEx, conditionValue);                                           // 4030
                });                                                                                                    //
            }                                                                                                          //
                                                                                                                       //
            function booleanConditional(name, parentName) {                                                            // 4034
                // first we normalize the conditional                                                                  //
                var booleanIndex = name.lastIndexOf('#?');                                                             // 4036
                                                                                                                       //
                if (booleanIndex == -1) return Promise.resolve(name);                                                  // 4038
                                                                                                                       //
                var conditionObj = parseCondition(name.substr(booleanIndex + 2));                                      // 4041
                                                                                                                       //
                // in builds, return normalized conditional                                                            //
                if (this.builder) return this['normalize'](conditionObj.module, parentName).then(function (conditionModule) {
                    conditionObj.module = conditionModule;                                                             // 4047
                    return name.substr(0, booleanIndex) + '#?' + serializeCondition(conditionObj);                     // 4048
                });                                                                                                    //
                                                                                                                       //
                return resolveCondition.call(this, conditionObj, parentName, true).then(function (conditionValue) {    // 4051
                    return conditionValue ? name.substr(0, booleanIndex) : '@empty';                                   // 4053
                });                                                                                                    //
            }                                                                                                          //
                                                                                                                       //
            hookConstructor(function (constructor) {                                                                   // 4057
                return function () {                                                                                   // 4058
                    constructor.call(this);                                                                            // 4059
                                                                                                                       //
                    // standard environment module, starting small as backwards-compat matters!                        //
                    this.set('@system-env', this.newModule({                                                           // 4062
                        browser: isBrowser,                                                                            // 4063
                        node: !!this._nodeRequire                                                                      // 4064
                    }));                                                                                               //
                };                                                                                                     //
            });                                                                                                        //
                                                                                                                       //
            // no normalizeSync                                                                                        //
            hook('normalize', function (normalize) {                                                                   // 4070
                return function (name, parentName, parentAddress) {                                                    // 4071
                    var loader = this;                                                                                 // 4072
                    return booleanConditional.call(loader, name, parentName).then(function (name) {                    // 4073
                        return normalize.call(loader, name, parentName, parentAddress);                                // 4075
                    }).then(function (normalized) {                                                                    //
                        return interpolateConditional.call(loader, normalized, parentName);                            // 4078
                    });                                                                                                //
                };                                                                                                     //
            });                                                                                                        //
            /*                                                                                                         //
             * Alias Extension                                                                                         //
             *                                                                                                         //
             * Allows a module to be a plain copy of another module by module name                                     //
             *                                                                                                         //
             * System.meta['mybootstrapalias'] = { alias: 'bootstrap' };                                               //
             *                                                                                                         //
             */                                                                                                        //
            (function () {                                                                                             // 4090
                // aliases                                                                                             //
                hook('fetch', function (fetch) {                                                                       // 4092
                    return function (load) {                                                                           // 4093
                        var alias = load.metadata.alias;                                                               // 4094
                        var aliasDeps = load.metadata.deps || [];                                                      // 4095
                        if (alias) {                                                                                   // 4096
                            load.metadata.format = 'defined';                                                          // 4097
                            this.defined[load.name] = {                                                                // 4098
                                declarative: true,                                                                     // 4099
                                deps: aliasDeps.concat([alias]),                                                       // 4100
                                declare: function (_export) {                                                          // 4101
                                    return {                                                                           // 4102
                                        setters: [function (module) {                                                  // 4103
                                            for (var p in babelHelpers.sanitizeForInObject(module)) _export(p, module[p]);
                                        }],                                                                            //
                                        execute: function () {}                                                        // 4107
                                    };                                                                                 //
                                }                                                                                      //
                            };                                                                                         //
                            return '';                                                                                 // 4111
                        }                                                                                              //
                                                                                                                       //
                        return fetch.call(this, load);                                                                 // 4114
                    };                                                                                                 //
                });                                                                                                    //
            })(); /*                                                                                                   //
                  * Meta Extension                                                                                     //
                  *                                                                                                    //
                  * Sets default metadata on a load record (load.metadata) from                                        //
                  * loader.metadata via System.meta function.                                                          //
                  *                                                                                                    //
                  *                                                                                                    //
                  * Also provides an inline meta syntax for module meta in source.                                     //
                  *                                                                                                    //
                  * Eg:                                                                                                //
                  *                                                                                                    //
                  * loader.meta({                                                                                      //
                  *   'my/module': { deps: ['jquery'] }                                                                //
                  *   'my/*': { format: 'amd' }                                                                        //
                  * });                                                                                                //
                  *                                                                                                    //
                  * Which in turn populates loader.metadata.                                                           //
                  *                                                                                                    //
                  * load.metadata.deps and load.metadata.format will then be set                                       //
                  * for 'my/module'                                                                                    //
                  *                                                                                                    //
                  * The same meta could be set with a my/module.js file containing:                                    //
                  *                                                                                                    //
                  * my/module.js                                                                                       //
                  *   "format amd";                                                                                    //
                  *   "deps[] jquery";                                                                                 //
                  *   "globals.some value"                                                                             //
                  *   console.log('this is my/module');                                                                //
                  *                                                                                                    //
                  * Configuration meta always takes preference to inline meta.                                         //
                  *                                                                                                    //
                  * Multiple matches in wildcards are supported and ammend the meta.                                   //
                  *                                                                                                    //
                  *                                                                                                    //
                  * The benefits of the function form is that paths are URL-normalized                                 //
                  * supporting say                                                                                     //
                  *                                                                                                    //
                  * loader.meta({ './app': { format: 'cjs' } });                                                       //
                  *                                                                                                    //
                  * Instead of needing to set against the absolute URL (https://site.com/app.js)                       //
                  *                                                                                                    //
                  */                                                                                                   //
                                                                                                                       //
            (function () {                                                                                             // 4160
                                                                                                                       //
                hookConstructor(function (constructor) {                                                               // 4162
                    return function () {                                                                               // 4163
                        this.meta = {};                                                                                // 4164
                        constructor.call(this);                                                                        // 4165
                    };                                                                                                 //
                });                                                                                                    //
                                                                                                                       //
                hook('locate', function (locate) {                                                                     // 4169
                    return function (load) {                                                                           // 4170
                        var meta = this.meta;                                                                          // 4171
                        var name = load.name;                                                                          // 4172
                                                                                                                       //
                        // NB for perf, maybe introduce a fast-path wildcard lookup cache here                         //
                        // which is checked first                                                                      //
                                                                                                                       //
                        // apply wildcard metas                                                                        //
                        var bestDepth = 0;                                                                             // 4178
                        var wildcardIndex;                                                                             // 4179
                        for (var module in babelHelpers.sanitizeForInObject(meta)) {                                   // 4180
                            wildcardIndex = module.indexOf('*');                                                       // 4181
                            if (wildcardIndex === -1) continue;                                                        // 4182
                            if (module.substr(0, wildcardIndex) === name.substr(0, wildcardIndex) && module.substr(wildcardIndex + 1) === name.substr(name.length - module.length + wildcardIndex + 1)) {
                                var depth = module.split('/').length;                                                  // 4186
                                if (depth > bestDepth) bestDepth = depth;                                              // 4187
                                extendMeta(load.metadata, meta[module], bestDepth != depth);                           // 4189
                            }                                                                                          //
                        }                                                                                              //
                                                                                                                       //
                        // apply exact meta                                                                            //
                        if (meta[name]) extendMeta(load.metadata, meta[name]);                                         // 4194
                                                                                                                       //
                        return locate.call(this, load);                                                                // 4197
                    };                                                                                                 //
                });                                                                                                    //
                                                                                                                       //
                // detect any meta header syntax                                                                       //
                // only set if not already set                                                                         //
                var metaRegEx = /^(\s*\/\*[^\*]*(\*(?!\/)[^\*]*)*\*\/|\s*\/\/[^\n]*|\s*"[^"]+"\s*;?|\s*'[^']+'\s*;?)+/;
                var metaPartRegEx = /\/\*[^\*]*(\*(?!\/)[^\*]*)*\*\/|\/\/[^\n]*|"[^"]+"\s*;?|'[^']+'\s*;?/g;           // 4204
                                                                                                                       //
                function setMetaProperty(target, p, value) {                                                           // 4206
                    var pParts = p.split('.');                                                                         // 4207
                    var curPart;                                                                                       // 4208
                    while (pParts.length > 1) {                                                                        // 4209
                        curPart = pParts.shift();                                                                      // 4210
                        target = target[curPart] = target[curPart] || {};                                              // 4211
                    }                                                                                                  //
                    curPart = pParts.shift();                                                                          // 4213
                    if (!(curPart in target)) target[curPart] = value;                                                 // 4214
                }                                                                                                      //
                                                                                                                       //
                hook('translate', function (translate) {                                                               // 4218
                    return function (load) {                                                                           // 4219
                        // NB meta will be post-translate pending transpiler conversion to plugins                     //
                        var meta = load.source.match(metaRegEx);                                                       // 4221
                        if (meta) {                                                                                    // 4222
                            var metaParts = meta[0].match(metaPartRegEx);                                              // 4223
                                                                                                                       //
                            for (var i = 0; i < metaParts.length; i++) {                                               // 4225
                                var curPart = metaParts[i];                                                            // 4226
                                var len = curPart.length;                                                              // 4227
                                                                                                                       //
                                var firstChar = curPart.substr(0, 1);                                                  // 4229
                                if (curPart.substr(len - 1, 1) == ';') len--;                                          // 4230
                                                                                                                       //
                                if (firstChar != '"' && firstChar != "'") continue;                                    // 4233
                                                                                                                       //
                                var metaString = curPart.substr(1, curPart.length - 3);                                // 4236
                                var metaName = metaString.substr(0, metaString.indexOf(' '));                          // 4237
                                                                                                                       //
                                if (metaName) {                                                                        // 4239
                                    var metaValue = metaString.substr(metaName.length + 1, metaString.length - metaName.length - 1);
                                                                                                                       //
                                    if (metaName.substr(metaName.length - 2, 2) == '[]') {                             // 4242
                                        metaName = metaName.substr(0, metaName.length - 2);                            // 4243
                                        load.metadata[metaName] = load.metadata[metaName] || [];                       // 4244
                                        load.metadata[metaName].push(metaValue);                                       // 4245
                                    } else if (load.metadata[metaName] instanceof Array) {                             //
                                        // temporary backwards compat for previous "deps" syntax                       //
                                        warn.call(this, 'Module ' + load.name + ' contains deprecated "deps ' + metaValue + '" meta syntax.\nThis should be updated to "deps[] ' + metaValue + '" for pushing to array meta.');
                                        load.metadata[metaName].push(metaValue);                                       // 4250
                                    } else {                                                                           //
                                        setMetaProperty(load.metadata, metaName, metaValue);                           // 4253
                                    }                                                                                  //
                                } else {                                                                               //
                                    load.metadata[metaString] = true;                                                  // 4257
                                }                                                                                      //
                            }                                                                                          //
                        }                                                                                              //
                                                                                                                       //
                        return translate.call(this, load);                                                             // 4262
                    };                                                                                                 //
                });                                                                                                    //
            })();                                                                                                      //
            /*                                                                                                         //
             System bundles                                                                                            //
              Allows a bundle module to be specified which will be dynamically                                         //
             loaded before trying to load a given module.                                                              //
              For example:                                                                                             //
             System.bundles['mybundle'] = ['jquery', 'bootstrap/js/bootstrap']                                         //
              Will result in a load to "mybundle" whenever a load to "jquery"                                          //
             or "bootstrap/js/bootstrap" is made.                                                                      //
              In this way, the bundle becomes the request that provides the module                                     //
             */                                                                                                        //
            function getBundleFor(loader, name) {                                                                      // 4280
                // check if it is in an already-loaded bundle                                                          //
                for (var b in babelHelpers.sanitizeForInObject(loader.loadedBundles_)) if (indexOf.call(loader.bundles[b], name) != -1) return Promise.resolve(b);
                                                                                                                       //
                // check if it is a new bundle                                                                         //
                for (var b in babelHelpers.sanitizeForInObject(loader.bundles)) if (indexOf.call(loader.bundles[b], name) != -1) return loader.normalize(b).then(function (normalized) {
                    loader.bundles[normalized] = loader.bundles[b];                                                    // 4291
                    loader.loadedBundles_[normalized] = true;                                                          // 4292
                    return normalized;                                                                                 // 4293
                });                                                                                                    //
                                                                                                                       //
                return Promise.resolve();                                                                              // 4296
            }                                                                                                          //
                                                                                                                       //
            (function () {                                                                                             // 4299
                // bundles support (just like RequireJS)                                                               //
                // bundle name is module name of bundle itself                                                         //
                // bundle is array of modules defined by the bundle                                                    //
                // when a module in the bundle is requested, the bundle is loaded instead                              //
                // of the form System.bundles['mybundle'] = ['jquery', 'bootstrap/js/bootstrap']                       //
                hookConstructor(function (constructor) {                                                               // 4305
                    return function () {                                                                               // 4306
                        constructor.call(this);                                                                        // 4307
                        this.bundles = {};                                                                             // 4308
                        this.loadedBundles_ = {};                                                                      // 4309
                    };                                                                                                 //
                });                                                                                                    //
                                                                                                                       //
                // assign bundle metadata for bundle loads                                                             //
                hook('locate', function (locate) {                                                                     // 4314
                    return function (load) {                                                                           // 4315
                        var loader = this;                                                                             // 4316
                        if (load.name in loader.loadedBundles_ || load.name in loader.bundles) load.metadata.bundle = true;
                                                                                                                       //
                        // if not already defined, check if we need to load a bundle                                   //
                        if (!(load.name in loader.defined)) return getBundleFor(loader, load.name).then(function (bundleName) {
                            if (bundleName) return loader.load(bundleName);                                            // 4324
                        }).then(function () {                                                                          //
                            return locate.call(loader, load);                                                          // 4328
                        });                                                                                            //
                                                                                                                       //
                        return locate.call(this, load);                                                                // 4331
                    };                                                                                                 //
                });                                                                                                    //
            })();                                                                                                      //
            /*                                                                                                         //
             * Dependency Tree Cache                                                                                   //
             *                                                                                                         //
             * Allows a build to pre-populate a dependency trace tree on the loader of                                 //
             * the expected dependency tree, to be loaded upfront when requesting the                                  //
             * module, avoinding the n round trips latency of module loading, where                                    //
             * n is the dependency tree depth.                                                                         //
             *                                                                                                         //
             * eg:                                                                                                     //
             * System.depCache = {                                                                                     //
             *  'app': ['normalized', 'deps'],                                                                         //
             *  'normalized': ['another'],                                                                             //
             *  'deps': ['tree']                                                                                       //
             * };                                                                                                      //
             *                                                                                                         //
             * System.import('app')                                                                                    //
             * // simultaneously starts loading all of:                                                                //
             * // 'normalized', 'deps', 'another', 'tree'                                                              //
             * // before "app" source is even loaded                                                                   //
             */                                                                                                        //
                                                                                                                       //
            (function () {                                                                                             // 4356
                hookConstructor(function (constructor) {                                                               // 4357
                    return function () {                                                                               // 4358
                        constructor.call(this);                                                                        // 4359
                        this.depCache = {};                                                                            // 4360
                    };                                                                                                 //
                });                                                                                                    //
                                                                                                                       //
                hook('locate', function (locate) {                                                                     // 4364
                    return function (load) {                                                                           // 4365
                        var loader = this;                                                                             // 4366
                        // load direct deps, in turn will pick up their trace trees                                    //
                        var deps = loader.depCache[load.name];                                                         // 4368
                        if (deps) for (var i = 0; i < deps.length; i++) loader['import'](deps[i]);                     // 4369
                                                                                                                       //
                        return locate.call(loader, load);                                                              // 4373
                    };                                                                                                 //
                });                                                                                                    //
            })();                                                                                                      //
                                                                                                                       //
            System = new SystemJSLoader();                                                                             // 4378
            System.version = '0.19.0 Standard';                                                                        // 4379
            // -- exporting --                                                                                         //
                                                                                                                       //
            if (typeof exports === 'object') module.exports = Loader;                                                  // 4382
                                                                                                                       //
            __global.Reflect = __global.Reflect || {};                                                                 // 4385
            __global.Reflect.Loader = __global.Reflect.Loader || Loader;                                               // 4386
            __global.Reflect.global = __global.Reflect.global || __global;                                             // 4387
            __global.LoaderPolyfill = Loader;                                                                          // 4388
                                                                                                                       //
            if (!System) {                                                                                             // 4390
                System = new SystemLoader();                                                                           // 4391
                System.constructor = SystemLoader;                                                                     // 4392
            }                                                                                                          //
                                                                                                                       //
            if (typeof exports === 'object') module.exports = System;                                                  // 4395
                                                                                                                       //
            __global.System = System;                                                                                  // 4398
        })(typeof self != 'undefined' ? self : global);                                                                //
    }                                                                                                                  //
                                                                                                                       //
    // auto-load Promise and URL polyfills if needed in the browser                                                    //
    try {                                                                                                              // 4403
        var hasURL = typeof URLPolyfill != 'undefined' || new URL('test:///').protocol == 'test:';                     // 4404
    } catch (e) {}                                                                                                     //
                                                                                                                       //
    if (typeof Promise === 'undefined' || !hasURL) {                                                                   // 4408
        // document.write                                                                                              //
        if (typeof document !== 'undefined') {                                                                         // 4410
            var scripts = document.getElementsByTagName('script');                                                     // 4411
            $__curScript = scripts[scripts.length - 1];                                                                // 4412
            var curPath = $__curScript.src;                                                                            // 4413
            var basePath = curPath.substr(0, curPath.lastIndexOf('/') + 1);                                            // 4414
            window.systemJSBootstrap = bootstrap;                                                                      // 4415
            document.write('<' + 'script type="text/javascript" src="' + basePath + 'system-polyfills.js">' + '<' + '/script>');
        }                                                                                                              //
        // importScripts                                                                                               //
        else if (typeof importScripts !== 'undefined') {                                                               //
                var basePath = '';                                                                                     // 4422
                try {                                                                                                  // 4423
                    throw new Error('_');                                                                              // 4424
                } catch (e) {                                                                                          //
                    e.stack.replace(/(?:at|@).*(http.+):[\d]+:[\d]+/, function (m, url) {                              // 4426
                        basePath = url.replace(/\/[^\/]*$/, '/');                                                      // 4427
                    });                                                                                                //
                }                                                                                                      //
                importScripts(basePath + 'system-polyfills.js');                                                       // 4430
                bootstrap();                                                                                           // 4431
            } else {                                                                                                   //
                bootstrap();                                                                                           // 4434
            }                                                                                                          //
    } else {                                                                                                           //
        bootstrap();                                                                                                   // 4438
    }                                                                                                                  //
})();                                                                                                                  //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/universe_modules/loader.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// Keep reference to original SystemJS methods                                                                         //
var originalNormalize = System.normalize;                                                                              //
var originalNormalizeSync = System.normalizeSync;                                                                      //
var originalImport = System['import'];                                                                                 //
                                                                                                                       //
// Configure SystemJS to support our modules                                                                           //
System.config({                                                                                                        // 9
    meta: {                                                                                                            // 10
        '/_modules_/*': {                                                                                              // 11
            format: 'register',                                                                                        // 12
            loader: 'UniverseModulesLoader'                                                                            // 13
        }                                                                                                              //
    }                                                                                                                  //
});                                                                                                                    //
                                                                                                                       //
// Few useful regular expressions                                                                                      //
var appRegex = /^\{}\//;                                                                                               // 19
var packageRegex = /^{([\w-]*?):?([\w-]+)}/;                                                                           // 20
var onlyPackageRegex = /^{([\w-]*?):?([\w-]+)}$/;                                                                      // 21
var normalizedRegex = /^\/_modules_\//;                                                                                // 22
var assetsRegex = /^\/packages\//;                                                                                     // 23
var selectedPlatformRegex = /@(client|server)$/;                                                                       // 24
var endsWithSlashRegex = /\/$/;                                                                                        // 25
var endsWithImportRegex = /\.import$/;                                                                                 // 26
                                                                                                                       //
/**                                                                                                                    //
 * Convert Meteor-like friendly module name to real module name.                                                       //
 * The `/_modules_/packages/abc/xyz/` syntax in an internal implementation that is subject to change!                  //
 * You should never rely on it!                                                                                        //
 * @param {string} name - friendly module name with Meteor package syntax                                              //
 * @param {string} [parentName] - normalized calling module name                                                       //
 * @returns {string} - real module name                                                                                //
 */                                                                                                                    //
var normalizeModuleName = (function () {                                                                               // 37
    function normalizeModuleName(name, parentName) {                                                                   // 37
                                                                                                                       //
        name = name.replace(endsWithImportRegex, ''); // support for filename.import syntax (required for TypeScript support)
                                                                                                                       //
        if (name.charAt(0) === '/') {                                                                                  // 41
            // absolute path                                                                                           //
                                                                                                                       //
            if (normalizedRegex.test(name) || assetsRegex.test(name)) {                                                // 44
                // already normalized name or meteor asset, leave it as is                                             //
                return name;                                                                                           // 46
            }                                                                                                          //
                                                                                                                       //
            name = name.replace(endsWithSlashRegex, '/index'); // if name is a directory then load index module        // 49
                                                                                                                       //
            if (parentName) {                                                                                          // 51
                var _parentName$split = parentName.split('/');                                                         //
                                                                                                                       //
                var dir = _parentName$split[1];                                                                        //
                var type = _parentName$split[2];                                                                       //
                var author = _parentName$split[3];                                                                     //
                var packageName = _parentName$split[4];                                                                //
                                                                                                                       //
                if (dir !== '_modules_') {                                                                             // 55
                    // invalid parent name, not our module!                                                            //
                    throw new Error('[Universe Modules]: Invalid parent while loading module from absolute path: ' + name + ' - ' + parentName);
                }                                                                                                      //
                                                                                                                       //
                if (type === 'app') {                                                                                  // 60
                    // inside app                                                                                      //
                    return '/_modules_/app' + name;                                                                    // 62
                } else if (type === 'packages') {                                                                      //
                    // inside a package                                                                                //
                    return '/_modules_/packages/' + author + '/' + packageName + name;                                 // 65
                }                                                                                                      //
                                                                                                                       //
                // invalid type                                                                                        //
                throw new Error('[Universe Modules]: Cannot determine parent when loading module from absolute path: ' + name + ' - ' + parentName);
            } else {                                                                                                   //
                // no parent provided, treat it as an app module, default behaviour                                    //
                return '/_modules_/app' + name;                                                                        // 73
            }                                                                                                          //
        } else if (name.charAt(0) === '{') {                                                                           //
            // Meteor syntax                                                                                           //
                                                                                                                       //
            return name                                                                                                // 80
            // main app file                                                                                           //
            .replace(appRegex, '/_modules_/app/') // {}/foo -> /_modules_/app/foo                                      //
                                                                                                                       //
            // only package name, import index file                                                                    //
            .replace(onlyPackageRegex, '/_modules_/packages/$1/$2/index') // {author:package} -> /_modules_/packages/author/package/index
                                                                                                                       //
            // package file                                                                                            //
            .replace(packageRegex, '/_modules_/packages/$1/$2') // {author:package}/foo -> /_modules_/packages/author/package/foo
                                                                                                                       //
            // link to index if a directory                                                                            //
            .replace(endsWithSlashRegex, '/index'); // /_modules_/packages/author/package/foo/ -> /_modules_/packages/author/package/foo/index
        } else {                                                                                                       //
                // Other syntax, maybe relative path, leave it as is                                                   //
                return name;                                                                                           // 95
            }                                                                                                          //
    }                                                                                                                  //
                                                                                                                       //
    return normalizeModuleName;                                                                                        //
})();                                                                                                                  //
                                                                                                                       //
/* Add default error reporting to System.import */                                                                     //
//System.import = function (...args) {                                                                                 //
//    return originalImport.call(this, ...args).catch(console.error.bind(console));                                    //
//};                                                                                                                   //
                                                                                                                       //
/*                                                                                                                     //
 * Overwrite SystemJS normalize with our method                                                                        //
 *                                                                                                                     //
 * normalize : (string, NormalizedModuleName, ModuleAddress) -> Promise<stringable>                                    //
 *                                                                                                                     //
 * name: the unnormalized module name                                                                                  //
 * parentName: the canonical module name for the requesting module                                                     //
 * parentAddress: the address of the requesting module                                                                 //
 */                                                                                                                    //
System.normalize = function (name, parentName, parentAddress) {                                                        // 114
    if (selectedPlatformRegex.test(name)) {                                                                            // 115
        // load module only on selected platform                                                                       //
                                                                                                                       //
        var _selectedPlatformRegex$exec = selectedPlatformRegex.exec(name);                                            //
                                                                                                                       //
        var platform = _selectedPlatformRegex$exec[1];                                                                 //
                                                                                                                       //
        if (Meteor.isServer && platform === 'server' || Meteor.isClient && platform === 'client') {                    // 119
            // correct platform                                                                                        //
            name = name.replace(selectedPlatformRegex, '');                                                            // 121
        } else {                                                                                                       //
            // wrong platform, return empty module                                                                     //
            return 'emptyModule';                                                                                      // 124
        }                                                                                                              //
    }                                                                                                                  //
                                                                                                                       //
    return originalNormalize.call(this, normalizeModuleName(name, parentName), parentName, parentAddress);             // 129
};                                                                                                                     //
                                                                                                                       //
/*                                                                                                                     //
 * Overwrite SystemJS normalizeSync with our method                                                                    //
 *                                                                                                                     //
 * name: the unnormalized module name                                                                                  //
 * parentName: the canonical module name for the requesting module                                                     //
 */                                                                                                                    //
System.normalizeSync = function (name, parentName) {                                                                   // 138
    return originalNormalizeSync.call(this, normalizeModuleName(name, parentName), parentName);                        // 139
};                                                                                                                     //
                                                                                                                       //
// Our custom loader                                                                                                   //
/* globals UniverseModulesLoader:true */                                                                               //
UniverseModulesLoader = System.newModule({                                                                             // 145
    /*                                                                                                                 //
     * locate : ({ name: NormalizedModuleName,                                                                         //
     *             metadata: object })                                                                                 //
     *       -> Promise<ModuleAddress>                                                                                 //
     *                                                                                                                 //
     * load.name the canonical module name                                                                             //
     * load.metadata a metadata object that can be used to store                                                       //
     *   derived metadata for reference in other hooks                                                                 //
     */                                                                                                                //
    //locate (load) {},                                                                                                //
                                                                                                                       //
    /*                                                                                                                 //
     * fetch : ({ name: NormalizedModuleName,                                                                          //
     *            address: ModuleAddress,                                                                              //
     *            metadata: object })                                                                                  //
     *      -> Promise<ModuleSource>                                                                                   //
     *                                                                                                                 //
     * load.name: the canonical module name                                                                            //
     * load.address: the URL returned from locate                                                                      //
     * load.metadata: the same metadata object by reference, which can be modified                                     //
     */                                                                                                                //
    fetch: function (load) {                                                                                           // 167
        // Fetch will only occur when there is no such module.                                                         //
        // Because we do not support lazy loading yet, this means that module name is invalid.                         //
        return Promise.reject('[Universe Modules]: Trying to load module "' + load.name.replace(/\/_modules_\/[^\/]*/, '') + '" that doesn\'t exist!');
    }                                                                                                                  //
                                                                                                                       //
    /*                                                                                                                 //
     * translate : ({ name: NormalizedModuleName?,                                                                     //
     *                address: ModuleAddress?,                                                                         //
     *                source: ModuleSource,                                                                            //
     *                metadata: object })                                                                              //
     *          -> Promise<string>                                                                                     //
     *                                                                                                                 //
     * load.name                                                                                                       //
     * load.address                                                                                                    //
     * load.metadata                                                                                                   //
     * load.source: the fetched source                                                                                 //
     */                                                                                                                //
    //translate (load) {},                                                                                             //
                                                                                                                       //
    /*                                                                                                                 //
     * instantiate : ({ name: NormalizedModuleName?,                                                                   //
     *                  address: ModuleAddress?,                                                                       //
     *                  source: ModuleSource,                                                                          //
     *                  metadata: object })                                                                            //
     *            -> Promise<ModuleFactory?>                                                                           //
     *                                                                                                                 //
     * load identical to previous hooks, but load.source                                                               //
     * is now the translated source                                                                                    //
     */                                                                                                                //
    //instantiate (load) {}                                                                                            //
});                                                                                                                    //
                                                                                                                       //
// Register our loader                                                                                                 //
System.set('UniverseModulesLoader', UniverseModulesLoader);                                                            // 201
                                                                                                                       //
// Register empty module                                                                                               //
System.set('emptyModule', System.newModule({}));                                                                       // 204
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/universe_modules/extensions/exports.js                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/*                                                                                                                     //
 * Following script allows to import variables exported from Meteor packages                                           //
 * @example `import {UniCollection, UniUsers} from '{universe:collection}!exports'`                                    //
 * @example `import {DDP} from '{ddp}!exports'`                                                                        //
 */                                                                                                                    //
                                                                                                                       //
System.set('exports', System.newModule({                                                                               // 7
    locate: function (_ref) {                                                                                          // 8
        var name = _ref.name;                                                                                          //
        var metadata = _ref.metadata;                                                                                  //
                                                                                                                       //
        return new Promise(function (resolve, reject) {                                                                // 9
            var _name$split = name.split('/');                                                                         //
                                                                                                                       //
            var dir = _name$split[1];                                                                                  //
            var author = _name$split[3];                                                                               //
            var packageName = _name$split[4];                                                                          //
                                                                                                                       //
            // check if we're in valid namespace                                                                       //
            if (dir !== '_modules_') {                                                                                 // 13
                reject(new Error('[Universe Modules]: trying to get exported values from invalid package: ' + name));  // 14
                return;                                                                                                // 15
            }                                                                                                          //
                                                                                                                       //
            // construct package name in Meteor's format                                                               //
            var meteorPackageName = (author ? author + ':' : '') + packageName;                                        // 19
                                                                                                                       //
            if (!Package[meteorPackageName]) {                                                                         // 21
                // ups, there is no such package                                                                       //
                reject(new Error('[Universe Modules]: Cannot find Meteor package exports for {' + meteorPackageName + '}'));
                return;                                                                                                // 24
            }                                                                                                          //
                                                                                                                       //
            // everything is ok, proceed                                                                               //
            metadata.meteorPackageName = meteorPackageName;                                                            // 28
            resolve(name);                                                                                             // 29
        });                                                                                                            //
    },                                                                                                                 //
    fetch: function () {                                                                                               // 32
        // we don't need to fetch anything for this to work                                                            //
        return '';                                                                                                     // 34
    },                                                                                                                 //
    instantiate: function (_ref2) {                                                                                    // 36
        var metadata = _ref2.metadata;                                                                                 //
                                                                                                                       //
        return Package[metadata.meteorPackageName];                                                                    // 37
    }                                                                                                                  //
}));                                                                                                                   //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/universe_modules/extensions/autoLoader.js                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _this = this;                                                                                                      //
                                                                                                                       //
System.autoLoad = function (name, deps, fn) {                                                                          // 1
    deps = deps || [];                                                                                                 // 2
    deps = deps.map(function (n) {                                                                                     // 3
        return System.normalizeSync(n, name);                                                                          //
    });                                                                                                                //
    var loadedModules = [];                                                                                            // 4
    var mustWait = deps.some(function (mName) {                                                                        // 5
        var m = System.get(mName);                                                                                     // 6
        if (!m) {                                                                                                      // 7
            mustWait = true;                                                                                           // 8
            return true;                                                                                               // 9
        }                                                                                                              //
        loadedModules.push(m);                                                                                         // 11
    });                                                                                                                //
                                                                                                                       //
    if (mustWait) {                                                                                                    // 14
        System.register(name, deps, fn);                                                                               // 15
        var p = System['import'](name);                                                                                // 16
        p['catch'](console.error.bind(console));                                                                       // 17
        return p;                                                                                                      // 18
    }                                                                                                                  //
                                                                                                                       //
    try {                                                                                                              // 21
        var _ret = (function () {                                                                                      //
            var exports = {};                                                                                          // 22
            var registerExport = function (key, value) {                                                               // 23
                if (typeof key === 'object') {                                                                         // 24
                    Object.keys(key).forEach(function (k) {                                                            // 25
                        return exports[k] = key[k];                                                                    //
                    });                                                                                                //
                    return;                                                                                            // 26
                }                                                                                                      //
                exports[key] = value;                                                                                  // 28
            };                                                                                                         //
            var declaration = fn(registerExport, exports);                                                             // 30
            if (!declaration.setters || !declaration.execute) {                                                        // 31
                var msg = 'Invalid Module form for ' + name;                                                           // 32
                console.error(msg);                                                                                    // 33
                return {                                                                                               // 34
                    v: Promise.reject(new Error(msg))                                                                  //
                };                                                                                                     //
            }                                                                                                          //
            declaration.setters.forEach(function (setFn, index) {                                                      // 36
                setFn(loadedModules[index]);                                                                           // 37
            });                                                                                                        //
            var output = declaration.execute.call(_this);                                                              // 39
            if (output) {                                                                                              // 40
                declaration.exports = output;                                                                          // 41
            }                                                                                                          //
            var newModule = System.newModule(exports);                                                                 // 43
            System.set(name, newModule);                                                                               // 44
            return {                                                                                                   // 45
                v: Promise.resolve(newModule)                                                                          //
            };                                                                                                         //
        })();                                                                                                          //
                                                                                                                       //
        if (typeof _ret === 'object') return _ret.v;                                                                   //
    } catch (err) {                                                                                                    //
        console.error(err);                                                                                            // 47
        return Promise.reject(err);                                                                                    // 48
    }                                                                                                                  //
};                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['universe:modules'] = {};

})();

//# sourceMappingURL=universe_modules.js.map
